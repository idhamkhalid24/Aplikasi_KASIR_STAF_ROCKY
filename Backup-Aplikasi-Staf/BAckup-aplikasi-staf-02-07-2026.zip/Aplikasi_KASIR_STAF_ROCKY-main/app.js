import { createClient as createSupabaseClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm";

// === SUPABASE MIGRATION CONFIG ===
// Disamakan dengan Server Pusat. Jangan taruh service_role / sb_secret di frontend.
const SUPABASE_URL = "https://ismjupxoiywttkrekmfg.supabase.co";
const SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlzbWp1cHhvaXl3dHRrcmVrbWZnIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkyNzc4MDEsImV4cCI6MjA5NDg1MzgwMX0.WVwqEdkPQ_x9NWR8QXTm85mIAvN8d9V2FaMJ2NiAMC0";
const supabaseConfig = { projectId: "ismjupxoiywttkrekmfg" };
const supabase = createSupabaseClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const db = { type: "supabase", client: supabase };
const app = db;
const firebaseConfig = supabaseConfig; // alias lama agar logic lama tetap jalan.

// === FIRESTORE COMPAT LAYER DI ATAS SUPABASE ===
// Menjaga logic staff tetap sama: collection/doc/query/where/limit/getDoc/getDocs/setDoc/addDoc/onSnapshot/serverTimestamp.
const SUPABASE_FALLBACK_POLL_MS = 2 * 60 * 1000;
const SUPABASE_REALTIME_DEBOUNCE_MS = 450;
const SUPABASE_UNCHANGED_NOTIFY_MS = 60000;
const SERVER_TIMESTAMP_SENTINEL = { __supabaseServerTimestamp: true };
const serverTimestamp = () => SERVER_TIMESTAMP_SENTINEL;
const doc = (_db, collectionName, id) => ({
  kind: "doc",
  collectionName,
  id: String(id || ""),
});
const collection = (_db, collectionName) => ({
  kind: "collection",
  collectionName,
});
const where = (field, op, value) => ({ kind: "where", field, op, value });
const limit = (count) => ({ kind: "limit", count: Number(count || 0) });
const query = (base, ...constraints) => ({
  kind: "query",
  collectionName: base.collectionName,
  constraints,
});
function makeId(prefix = "") {
  return `${prefix}${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}
function deepCloneCompat(value) {
  if (value === null || value === undefined) return value;
  if (value === SERVER_TIMESTAMP_SENTINEL || value?.__supabaseServerTimestamp)
    return new Date().toISOString();
  if (value instanceof Date) return value.toISOString();
  if (Array.isArray(value)) return value.map(deepCloneCompat);
  if (typeof value === "object") {
    if (typeof value.toDate === "function") return value.toDate().toISOString();
    const out = {};
    Object.entries(value).forEach(([k, v]) => {
      if (v !== undefined) out[k] = deepCloneCompat(v);
    });
    return out;
  }
  return value;
}
function normalizeRow(row) {
  const data = row?.data && typeof row.data === "object" ? row.data : {};
  return { id: row?.id, ...data };
}
function docSnapshot(id, data) {
  return {
    id,
    exists: () => !!data,
    data: () => (data ? { ...data } : undefined),
  };
}
function querySnapshot(rows) {
  const docs = rows.map((row) => ({ id: row.id, data: () => ({ ...row }) }));
  return {
    docs,
    size: docs.length,
    empty: docs.length === 0,
    forEach(cb) {
      docs.forEach(cb);
    },
    docChanges() {
      return docs.map((doc) => ({ type: "added", doc }));
    },
  };
}
function snapshotSignature(snap) {
  try {
    if (snap && Array.isArray(snap.docs)) {
      return snap.docs
        .map((d) => `${d.id}:${JSON.stringify(d.data())}`)
        .join("|");
    }
    return `${snap?.exists?.() ? "1" : "0"}:${JSON.stringify(snap?.data?.() || null)}`;
  } catch (e) {
    return String(Date.now());
  }
}
function snapshotIds(snap) {
  try {
    if (snap && Array.isArray(snap.docs))
      return new Set(snap.docs.map((d) => String(d.id)));
    return snap?.id ? new Set([String(snap.id)]) : new Set();
  } catch (e) {
    return new Set();
  }
}
function getFieldValue(row, field) {
  return String(field || "")
    .split(".")
    .reduce((acc, key) => (acc == null ? undefined : acc[key]), row);
}
function compareWhere(row, c) {
  const a = getFieldValue(row, c.field),
    b = c.value;
  if (c.op === "==") return String(a) === String(b);
  if (c.op === "!=") return String(a) !== String(b);
  if (c.op === ">=") return String(a) >= String(b);
  if (c.op === "<=") return String(a) <= String(b);
  if (c.op === ">") return String(a) > String(b);
  if (c.op === "<") return String(a) < String(b);
  if (c.op === "in")
    return Array.isArray(b) && b.map(String).includes(String(a));
  return true;
}
function rowMatchesQuery(row, refOrQuery) {
  if (!row) return false;
  if (refOrQuery.kind === "doc")
    return String(row.id || "") === String(refOrQuery.id || "");
  const constraints = refOrQuery.constraints || [];
  return constraints
    .filter((c) => c.kind === "where")
    .every((c) => compareWhere(row, c));
}
function realtimePayloadRow(payload) {
  const raw =
    payload?.new && Object.keys(payload.new).length
      ? payload.new
      : payload?.old;
  return raw ? normalizeRow(raw) : null;
}
function realtimeChannelName(refOrQuery) {
  const table = String(refOrQuery.collectionName || "data").replace(
    /[^a-zA-Z0-9_]/g,
    "_",
  );
  const scope =
    refOrQuery.kind === "doc"
      ? String(refOrQuery.id || "doc")
      : Math.random().toString(36).slice(2, 10);
  return `staff_${table}_${scope.replace(/[^a-zA-Z0-9_]/g, "_")}_${Date.now().toString(36)}`;
}
function realtimeFilter(refOrQuery) {
  if (refOrQuery.kind !== "doc") return null;
  const id = String(refOrQuery.id || "");
  return id ? `id=eq.${id.replace(/[,()]/g, "")}` : null;
}
function isRealtimePayloadRelevant(refOrQuery, payload, lastIds) {
  const row = realtimePayloadRow(payload);
  if (!row) return true;
  if (refOrQuery.kind === "doc")
    return String(row.id || "") === String(refOrQuery.id || "");
  if (lastIds && lastIds.has(String(row.id || ""))) return true;
  return rowMatchesQuery(row, refOrQuery);
}
async function getDoc(ref) {
  const { data, error } = await supabase
    .from(ref.collectionName)
    .select("id,data")
    .eq("id", ref.id)
    .maybeSingle();
  if (error) throw error;
  return docSnapshot(ref.id, data ? normalizeRow(data) : null);
}
const getDocFromServer = getDoc;
async function getDocs(qy) {
  const collectionName = qy.collectionName;
  const constraints = qy.constraints || [];
  const hardLimit = constraints.find((c) => c.kind === "limit")?.count || 1000;
  const wheres = constraints.filter((c) => c.kind === "where");
  let req = supabase.from(collectionName).select("id,data");
  let canServerFilter = true;
  for (const c of wheres) {
    // Supabase menyimpan field aplikasi di kolom JSONB `data`.
    // Filter langsung di server supaya transaksi terbaru tidak hilang dari riwayat
    // saat tabel sudah ramai. Fallback filter browser tetap dipakai di bawah.
    const field = String(c.field || "");
    const safeField = /^[a-zA-Z0-9_]+$/.test(field);
    const path = `data->>${field}`;
    if (safeField && c.op === "==") {
      req = req.eq(path, String(c.value));
    } else if (safeField && c.op === "!=") {
      req = req.neq(path, String(c.value));
    } else if (safeField && c.op === ">=") {
      req = req.gte(path, String(c.value));
    } else if (safeField && c.op === "<=") {
      req = req.lte(path, String(c.value));
    } else if (safeField && c.op === ">") {
      req = req.gt(path, String(c.value));
    } else if (safeField && c.op === "<") {
      req = req.lt(path, String(c.value));
    } else if (safeField && c.op === "in" && Array.isArray(c.value)) {
      req = req.in(path, c.value.map(String));
    } else {
      canServerFilter = false;
    }
  }
  // Untuk transaksi, ambil buffer lebih besar dan urutkan id DESC karena id transaksi
  // mengandung timestamp: stafftx_user_171... Ini mencegah polling menimpa riwayat
  // dengan hasil query parsial ketika data server sudah banyak.
  const fetchLimit = canServerFilter
    ? hardLimit
    : collectionName === "transactions"
      ? Math.min(Math.max(hardLimit * 50, 1000), 5000)
      : Math.min(Math.max(hardLimit * 3, hardLimit), 5000);
  if (collectionName === "transactions")
    req = req.order("id", { ascending: false });
    
  let allData = [];
  let from = 0;
  const pageSize = 1000;
  let error = null;

  while (allData.length < fetchLimit) {
    let to = Math.min(from + pageSize - 1, fetchLimit - 1);
    let res = await req.range(from, to);
    if (res.error) {
      error = res.error;
      break;
    }
    if (res.data && res.data.length > 0) {
      allData.push(...res.data);
    }
    if (!res.data || res.data.length < (to - from + 1)) {
      break;
    }
    from += (to - from + 1);
  }

  if (error) throw error;
  let rows = (allData || []).map(normalizeRow);
  // Tetap filter ulang di browser untuk keamanan dan operator selain ==.
  wheres.forEach((c) => {
    rows = rows.filter((row) => compareWhere(row, c));
  });
  rows = sortDesc(rows);
  return querySnapshot(rows.slice(0, hardLimit));
}
const getDocsFromServer = getDocs;
async function setDoc(ref, payload, options = {}) {
  const nextData = deepCloneCompat(payload || {});
  let finalData = nextData;
  if (options?.merge) {
    const oldSnap = await getDoc(ref).catch(() => docSnapshot(ref.id, null));
    finalData = { ...(oldSnap.exists() ? oldSnap.data() : {}), ...nextData };
    delete finalData.id;
  }
  const { error } = await supabase
    .from(ref.collectionName)
    .upsert({ id: ref.id, data: finalData }, { onConflict: "id" });
  if (error) throw error;
  return ref;
}
async function addDoc(colRef, payload) {
  const ref = doc(db, colRef.collectionName, makeId());
  await setDoc(ref, payload || {});
  return ref;
}
async function deleteDoc(ref) {
  const { error } = await supabase
    .from(ref.collectionName)
    .delete()
    .eq("id", ref.id);
  if (error) throw error;
}
function onSnapshot(refOrQuery, next, errorCb) {
  let stopped = false;
  let lastSignature = "";
  let lastNotifyMs = 0;
  let lastIds = new Set();
  let realtimeChannel = null;
  let queuedTimer = 0;
  const run = async ({ force = false } = {}) => {
    try {
      const snap =
        refOrQuery.kind === "doc"
          ? await getDoc(refOrQuery)
          : await getDocs(refOrQuery);
      const sig = snapshotSignature(snap);
      const now = Date.now();
      lastIds = snapshotIds(snap);
      if (
        !force &&
        sig === lastSignature &&
        now - lastNotifyMs < SUPABASE_UNCHANGED_NOTIFY_MS
      )
        return;
      lastSignature = sig;
      lastNotifyMs = now;
      if (!stopped) next(snap);
    } catch (e) {
      lastSignature = "";
      console.warn("Supabase snapshot error:", e?.message || e);
      if (!stopped && errorCb) errorCb(e);
    }
  };
  const queueRun = () => {
    if (stopped) return;
    clearTimeout(queuedTimer);
    queuedTimer = setTimeout(() => run(), SUPABASE_REALTIME_DEBOUNCE_MS);
  };
  run({ force: true });
  try {
    const table = String(refOrQuery.collectionName || "");
    if (table && supabase?.channel) {
      const config = { event: "*", schema: "public", table };
      const filter = realtimeFilter(refOrQuery);
      if (filter) config.filter = filter;
      realtimeChannel = supabase
        .channel(realtimeChannelName(refOrQuery))
        .on("postgres_changes", config, (payload) => {
          if (isRealtimePayloadRelevant(refOrQuery, payload, lastIds))
            queueRun();
        })
        .subscribe((status) => {
          if (
            !stopped &&
            (status === "CHANNEL_ERROR" || status === "TIMED_OUT")
          ) {
            console.warn("Supabase realtime fallback:", table, status);
          }
        });
    }
  } catch (e) {
    console.warn("Supabase realtime init skipped:", e?.message || e);
  }
  const timer = setInterval(run, SUPABASE_FALLBACK_POLL_MS);
  return () => {
    stopped = true;
    clearInterval(timer);
    clearTimeout(queuedTimer);
    if (realtimeChannel) {
      try {
        supabase.removeChannel(realtimeChannel).catch(() => {});
      } catch (e) {}
    }
  };
}

const OFFICE_LOC = { lat: -6.786168, lng: 106.780918 };
const RADIUS_LIMIT = 200,
  MEMBER_URL = "https://idhamkhalid24.github.io/kode-khusus-member/";
const SESSION = "rocky_firebase_session_v1",
  LEGACY_SESSION = "rocky_staff_compact_manual_v1",
  PENDING_KEY = "rocky_staff_pending_sync_v2",
  MANUAL_BONUS_SEEN = "rocky_staff_manual_bonus_seen_v1",
  BONUS_WITHDRAWAL_SEEN = "rocky_staff_bonus_withdrawal_seen_v1",
  TARGET_NOTICE_SEEN = "rocky_staff_target_notice_seen_v1",
  FIRST_TX_PARTY_SEEN = "rocky_staff_first_tx_party_seen_v1",
  DEVICE_ID_KEY = "rocky_staff_device_id_v1",
  DEVICE_USER_KEY = "rocky_staff_device_user_v1",
  ADMIN = ["admin"];
const DEFAULT_BONUS = {
  transactionBonusRate: 0.015,
  transactionBonusPercent: 1.5,
  closingBonusPerMinute: 100,
  closingDeadlineTime: "18:00",
  closingDeadlineHour: 18,
  closingDeadlineMinute: 0,
  closingDeadlineMinutes: 1080,
};
const DAILY_TARGET_AMOUNT = 2500000;
const BONUS_TARGET_AMOUNT = 10000;
const TARGET_SETTINGS_TABLE = "targetSettings";
const DAILY_TARGETS_TABLE = "dailyTargets";
const TARGET_BONUS_REWARDS_TABLE = "targetBonusRewards";
const TARGET_NOTIFICATIONS_TABLE = "targetNotifications";
const BONUS_WITHDRAWAL_TYPE = "bonus_withdrawal";
const HEADER_GUIDE_NOTE_DOC_ID = "__header_icon_guide_note";
const DEFAULT_HEADER_GUIDE_NOTE =
  "Bonus adalah apresiasi tambahan dan dapat berubah sewaktu-waktu. Fokus utama tetap pada penjualan, kinerja, pelayanan, dan tanggung jawab kerja.";
const STAFF_DAILY_NOTE_DOC_ID = "__staff_daily_home_note";
const DEFAULT_STAFF_DAILY_NOTE =
  "Semangat bekerja hari ini. Pastikan transaksi dicatat dengan benar dan refresh jika data belum masuk.";
const RECEIPT_TEXT_DOC_ID = "__receipt_text_settings";
const DEFAULT_RECEIPT_TEXT_SETTINGS = {
  storeName: "ROCKY HIJAB",
  storeSubtext: "",
  dailyTitle: "TRANSAKSI HARI INI",
  dateLabel: "Tanggal",
  cashierLabel: "Kasir",
  productLabel: "Produk",
  totalLabel: "Total",
  countLabel: "Jumlah",
  footerText: "Terima kasih",
  bottomFeedLines: 6,
};
const STAFF_UNLOCK_TABLE = "staff_leave_requests";
const LIMITS = {
  txToday: 120,
  attMonth: 90,
  manualToday: 80,
  closingsToday: 80,
  unlockRequests: 160,
  txBonusAll: 2000,
  manualBonusAll: 1000,
  closingsAll: 1500,
  targetTxToday: 5000,
  targetUsers: 1000,
  targetAttToday: 2000,
};
const INITIAL_LEGACY_LIMITS = { tx: 300, att: 90, manual: 200 };
const ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL =
  "https://rocky-notif-worker.alfajrihanif24.workers.dev";
const ROCKY_ADMIN_NOTIFY_WORKER_URL =
  ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL + "/notify-transaction";
const ROCKY_ADMIN_NOTIFY_ATTENDANCE_URL =
  ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL + "/notify-attendance";
const ROCKY_ADMIN_NOTIFY_TRANSACTION_DELETE_URL =
  ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL + "/notify-transaction-delete";
const ROCKY_ADMIN_NOTIFY_UNLOCK_URL =
  ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL + "/notify-feature-unlock";
const ROCKY_ADMIN_NOTIFY_TARGET_URL =
  ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL + "/notify-target-achieved";
const ROCKY_STAFF_NOTIFY_MANUAL_BONUS_URL =
  ROCKY_ADMIN_NOTIFY_WORKER_BASE_URL + "/notify-staff-manual-bonus";
const ROCKY_ADMIN_NOTIFY_SECRET = "rockyNotifRahasia2026";
const REFRESH_COOLDOWN_MS = 30000;
const KAS_PRIBADI_SUPABASE_URL = "https://myxrvipyodadnldtomzs.supabase.co";
const KAS_PRIBADI_SUPABASE_ANON_KEY =
  "sb_publishable_aG-kyasJNCEk2U9fN5T4qg_GfY0FpPH";
const KAS_PRIBADI_OWNER_ID = "rocky-hijab";
const CASH_DRAWER_TABLE = "cash_drawer_audits";
const cashDrawerClient = createSupabaseClient(
  KAS_PRIBADI_SUPABASE_URL,
  KAS_PRIBADI_SUPABASE_ANON_KEY,
);

// Bridge ke aplikasi Belanjaku: staff bisa lapor barang kosong (nama barang + warna).
const BELANJAKU_BRIDGE_KEY = "stafku_to_belanjaku_barang_kosong_v1";
const BELANJAKU_SUPABASE_URL = "https://phuzgriglgovzcwgbehr.supabase.co";
const BELANJAKU_SUPABASE_ANON_KEY =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBodXpncmlnbGdvdnpjd2diZWhyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Nzg1OTQ3ODUsImV4cCI6MjA5NDE3MDc4NX0.gf-cfo8Vos8uYgZRHG0KUB4xMhXAld2oTYv-wNiKneE";
// Kunci di atas adalah anon-public Supabase untuk tabel Belanjaku, bukan service role.
const BELANJAKU_SUPABASE_ITEMS_TABLE = "belanja_items";

// HYBRID HEMAT READ: realtime tetap aktif, tapi polling cek device diperlambat.
const DEVICE_SESSION_CHECK_MS = 5 * 60 * 1000; // sebelumnya 15 detik, sekarang 5 menit
const DEVICE_SESSION_ACTION_CACHE_MS = 30 * 1000;
let lastManualRefreshAt = 0;
let lastDeviceSessionCheckAt = 0;
let staffRealtimeUnsubs = [];
let staffRealtimeStartedFor = "";
function defaultDailyTargetState(dateKey = todayKey()) {
  return {
    dateKey,
    targetAmount: DAILY_TARGET_AMOUNT,
    bonusAmount: BONUS_TARGET_AMOUNT,
    totalAmount: 0,
    progressPercent: 0,
    reached: false,
    bonusApplied: false,
    activeUsers: [],
    rewardedUsers: [],
    updatedAtMs: 0,
  };
}
const state = {
  user: null,
  page: "home",
  pos: null,
  busy: false,
  lastSyncMs: 0,
  syncing: false,
  syncError: "",
  data: {
    tx: [],
    att: [],
    closings: [],
    manual: [],
    unlockRequests: [],
    targetTx: [],
    targetUsers: [],
    targetAtt: [],
    targetSettings: {
      targetAmount: DAILY_TARGET_AMOUNT,
      bonusAmount: BONUS_TARGET_AMOUNT,
    },
    dailyTarget: defaultDailyTargetState(),
    targetNotification: null,
    bonus: { ...DEFAULT_BONUS },
    headerGuideNote: DEFAULT_HEADER_GUIDE_NOTE,
    staffDailyNote: { note: DEFAULT_STAFF_DAILY_NOTE, enabled: true },
    receiptSettings: { ...DEFAULT_RECEIPT_TEXT_SETTINGS },
    cashDrawer: null,
    drawerWithdrawals: [],
  },
};
let dailyTargetApplyTimer = 0;
let dailyTargetApplying = false;
let targetNoticeAnnounced = new Set();
let bonusWithdrawalAnnounced = new Set();
let clockInInFlight = false;
let deviceSessionTimer = null;
const $ = (id) => document.getElementById(id),
  page = $("page");

function updateVisualViewportForKeyboard() {
  const vv = window.visualViewport;
  const h = Math.max(260, Math.round(vv ? vv.height : window.innerHeight));
  const top = Math.max(0, Math.round(vv ? vv.offsetTop : 0));
  document.documentElement.style.setProperty("--app-vvh", h + "px");
  document.documentElement.style.setProperty("--app-vvtop", top + "px");
}
updateVisualViewportForKeyboard();
if (window.visualViewport) {
  window.visualViewport.addEventListener(
    "resize",
    updateVisualViewportForKeyboard,
  );
  window.visualViewport.addEventListener(
    "scroll",
    updateVisualViewportForKeyboard,
  );
}
window.addEventListener("resize", updateVisualViewportForKeyboard);
window.addEventListener("orientationchange", () =>
  setTimeout(updateVisualViewportForKeyboard, 120),
);
function keepLoginInputVisible() {
  setTimeout(() => {
    const el = document.activeElement;
    if (el && el.closest && el.closest(".login")) {
      try {
        el.scrollIntoView({
          block: "center",
          inline: "nearest",
          behavior: "smooth",
        });
      } catch (e) {
        el.scrollIntoView(false);
      }
    }
  }, 90);
}
document.addEventListener("focusin", keepLoginInputVisible, true);
if (window.visualViewport) {
  window.visualViewport.addEventListener("resize", () => {
    const el = document.activeElement;
    if (el && el.closest && el.closest(".login")) keepLoginInputVisible();
  });
}

function esc(v) {
  return String(v ?? "").replace(
    /[&<>'"]/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[
        c
      ],
  );
}
function escAttr(v) {
  return esc(v);
}
function normalizeStaffNoteUrl(rawUrl) {
  const url = String(rawUrl || "").trim();
  if (/^https?:\/\//i.test(url)) return url;
  if (/^www\./i.test(url)) return "https://" + url;
  return url;
}
function openStaffNoteLink(e, rawUrl) {
  if (e) e.preventDefault();
  const url = normalizeStaffNoteUrl(rawUrl);
  if (!/^https?:\/\//i.test(url)) return false;
  try {
    const bridge = window.Android,
      methods = [
        "openExternalUrl",
        "openExternalLink",
        "openUrl",
        "openBrowser",
      ];
    if (bridge) {
      for (const m of methods) {
        if (typeof bridge[m] === "function") {
          bridge[m](url);
          return false;
        }
      }
    }
  } catch (err) {
    console.warn("open external link bridge failed", err);
  }
  const opened = window.open(url, "_blank", "noopener,noreferrer");
  if (!opened) window.location.href = url;
  return false;
}
function shortStaffNoteLinkLabel(rawUrl) {
  let clean = String(rawUrl || "").trim(),
    label = clean.replace(/^https?:\/\//i, "").replace(/^www\./i, "");
  try {
    const u = new URL(normalizeStaffNoteUrl(clean));
    const host = u.hostname.replace(/^www\./i, ""),
      path = u.pathname.replace(/\/+$/, "");
    const last = decodeURIComponent(
      path.split("/").filter(Boolean).pop() || "",
    ).replace(/[-_]+/g, " ");
    label = last ? `${host}/…/${last}` : host;
  } catch (e) {}
  return label.length > 42
    ? label.slice(0, 25) + "…" + label.slice(-12)
    : label;
}
function linkText(v) {
  const text = String(v || ""),
    rx = /((?:https?:\/\/|www\.)[^\s<>"']+)/gi;
  let html = "",
    last = 0;
  text.replace(rx, (match, url, offset) => {
    html += esc(text.slice(last, offset));
    let raw = url,
      trailing = "";
    const tm = raw.match(/[),.;!?]+$/);
    if (tm) {
      trailing = tm[0];
      raw = raw.slice(0, -trailing.length);
    }
    const href = normalizeStaffNoteUrl(raw);
    if (/^https?:\/\//i.test(href)) {
      const label = shortStaffNoteLinkLabel(raw);
      html += `<a class="staff-note-link" href="${esc(href)}" title="${esc(href)}" target="_blank" rel="noopener noreferrer" onclick="return openStaffNoteLink(event, this.href)">${esc(label)}</a>${esc(trailing)}`;
    } else {
      html += esc(match);
    }
    last = offset + match.length;
    return match;
  });
  html += esc(text.slice(last));
  return html;
}
function key(v) {
  return String(v || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_\-.]/g, "");
}
function getDeviceId() {
  let id = localStorage.getItem(DEVICE_ID_KEY) || "";
  if (!id) {
    const rnd = crypto?.randomUUID
      ? crypto.randomUUID()
      : Date.now().toString(36) + "_" + Math.random().toString(36).slice(2);
    id =
      "dev_" +
      String(rnd)
        .replace(/[^a-zA-Z0-9_-]/g, "")
        .slice(0, 48);
    localStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}
function localDeviceUser() {
  return key(localStorage.getItem(DEVICE_USER_KEY) || "");
}
function bindLocalDeviceUser(username) {
  try {
    localStorage.setItem(DEVICE_USER_KEY, key(username));
  } catch (e) {}
}
function clearLocalDeviceUser() {
  try {
    localStorage.removeItem(DEVICE_USER_KEY);
  } catch (e) {}
}
function shortDevice(id) {
  return (
    String(id || "")
      .slice(-6)
      .toUpperCase() || "-"
  );
}
async function isLocalDeviceStillOwnedBy(boundUser, deviceId) {
  const bound = key(boundUser);
  if (!bound) return false;
  try {
    const snap = await getDocFromServer(doc(db, "users", bound));
    if (!snap.exists()) return false;
    const raw = snap.data() || {};
    const data = { id: snap.id, username: raw.username || snap.id, ...raw };
    if (isDeviceFreeUser(data) || data.active === false || deleted(data))
      return false;
    return (
      String(data.deviceId || "").trim() === deviceId &&
      data.deviceLocked !== false
    );
  } catch (e) {
    console.warn("device owner check skipped", e?.code || e?.message || e);
    return true;
  }
}
async function verifyDeviceLockForLogin(userData, username) {
  const u = key(username || userData?.username || userData?.id),
    deviceId = getDeviceId(),
    bound = localDeviceUser();
  if (isDeviceFreeUser(userData)) {
    const deviceLabel = isTrialUser(userData)
      ? "Dummy bebas login"
      : isRismaSpecialUser(userData)
        ? "Risma bebas login"
        : "Harian bebas login";
    try {
      await setDoc(
        doc(db, "users", u),
        {
          deviceId: "",
          deviceLocked: false,
          deviceUser: "",
          deviceApp: "staff",
          deviceLabel,
          devicePolicy: "open_any_device",
          deviceLastLoginAt: serverTimestamp(),
          deviceLastLoginAtMs: Date.now(),
        },
        { merge: true },
      );
    } catch (e) {
      console.warn("open device free update skipped", e?.code || e);
    }
    if (isTrialUser(userData)) clearLocalDeviceUser();
    return { ok: true, deviceId: "", exempt: true };
  }
  if (bound && bound !== u) {
    const stillOwned = await isLocalDeviceStillOwnedBy(bound, deviceId);
    if (stillOwned)
      return {
        ok: false,
        msg: `Perangkat ini masih terdaftar untuk user ${bound}. Reset device user tersebut dulu dari admin.`,
      };
    clearLocalDeviceUser();
  }
  const serverDeviceId = String(userData?.deviceId || "").trim();
  if (serverDeviceId && serverDeviceId !== deviceId)
    return {
      ok: false,
      msg: "Akun ini sudah terdaftar di perangkat lain. Hubungi admin untuk reset device.",
    };
  try {
    await setDoc(
      doc(db, "users", u),
      {
        deviceId,
        deviceLocked: true,
        deviceUser: u,
        deviceApp: "staff",
        deviceLabel: "Staff App " + shortDevice(deviceId),
        deviceUserAgent: String(navigator.userAgent || "").slice(0, 180),
        devicePlatform: String(navigator.platform || "").slice(0, 80),
        deviceLastLoginAt: serverTimestamp(),
        deviceLastLoginAtMs: Date.now(),
        deviceLockedAt: serverDeviceId
          ? userData?.deviceLockedAt || serverTimestamp()
          : serverTimestamp(),
        deviceLockedAtMs: Number(userData?.deviceLockedAtMs || Date.now()),
      },
      { merge: true },
    );
    bindLocalDeviceUser(u);
    return { ok: true, deviceId };
  } catch (e) {
    console.error("device lock failed", e);
    return {
      ok: false,
      msg: isPermissionError(e)
        ? "Akses Firebase menolak kunci perangkat. Hubungi admin."
        : "Gagal mengunci perangkat. Pastikan internet aktif.",
    };
  }
}

function clearSessionAndRender(msg) {
  try {
    localStorage.removeItem(SESSION);
    localStorage.removeItem(LEGACY_SESSION);
  } catch (e) {}
  stopDeviceSessionWatch();
  clearStaffRealtime();
  clearAndroidStaffSession();
  targetNoticeAnnounced = new Set();
  bonusWithdrawalAnnounced = new Set();
  state.user = null;
  state.pos = null;
  state.syncError = "";
  state.lastSyncMs = 0;
  state.data = {
    tx: [],
    att: [],
    closings: [],
    manual: [],
    unlockRequests: [],
    targetTx: [],
    targetUsers: [],
    targetAtt: [],
    targetSettings: {
      targetAmount: DAILY_TARGET_AMOUNT,
      bonusAmount: BONUS_TARGET_AMOUNT,
    },
    dailyTarget: defaultDailyTargetState(),
    targetNotification: null,
    bonus: { ...DEFAULT_BONUS },
    headerGuideNote: DEFAULT_HEADER_GUIDE_NOTE,
    staffDailyNote: { note: DEFAULT_STAFF_DAILY_NOTE, enabled: true },
    receiptSettings: { ...DEFAULT_RECEIPT_TEXT_SETTINGS },
    cashDrawer: null,
  };
  if (msg) toast(msg);
  renderLogin();
}
function isDeviceSessionInvalid(fresh) {
  if (!fresh || isDeviceFreeUser(fresh) || isDeviceFreeUser(state.user))
    return "";
  const serverReset = Number(fresh.deviceResetAtMs || 0),
    localReset = Number(state.user?.deviceResetAtMs || 0);
  if (serverReset && serverReset > localReset)
    return "Device akun ini sudah direset admin. Silakan login ulang.";
  const serverDeviceId = String(fresh.deviceId || "").trim(),
    localDeviceId = getDeviceId();
  if (serverDeviceId && serverDeviceId !== localDeviceId)
    return "Akun ini sudah pindah ke perangkat lain. Silakan hubungi admin.";
  return "";
}
async function validateCurrentDeviceSession({
  silent = true,
  force = false,
} = {}) {
  if (!state.user || isDeviceFreeUser(state.user)) return true;
  const nowMs = Date.now();
  if (
    !force &&
    lastDeviceSessionCheckAt &&
    nowMs - lastDeviceSessionCheckAt < DEVICE_SESSION_ACTION_CACHE_MS
  )
    return true;
  try {
    const u = key(state.user.username),
      snap = await getDocFromServer(doc(db, "users", u));
    lastDeviceSessionCheckAt = Date.now();
    if (!snap.exists()) {
      clearSessionAndRender("Akun sudah tidak valid");
      return false;
    }
    const raw = snap.data() || {},
      fresh = { id: snap.id, username: raw.username || snap.id, ...raw };
    if (isAdmin(fresh) || fresh.active === false || deleted(fresh)) {
      clearSessionAndRender("Akun sudah nonaktif / tidak valid");
      return false;
    }
    const reason = isDeviceSessionInvalid(fresh);
    if (reason) {
      clearSessionAndRender(reason);
      return false;
    }
    return true;
  } catch (e) {
    lastDeviceSessionCheckAt = Date.now();
    if (!silent)
      console.warn("device session check skipped", e?.code || e?.message || e);
    return true;
  }
}
function startDeviceSessionWatch() {
  stopDeviceSessionWatch();
  if (!state.user || isDeviceFreeUser(state.user)) return;
  deviceSessionTimer = setInterval(
    () => validateCurrentDeviceSession({ silent: true }),
    DEVICE_SESSION_CHECK_MS,
  );
}
function stopDeviceSessionWatch() {
  if (deviceSessionTimer) {
    clearInterval(deviceSessionTimer);
    deviceSessionTimer = null;
  }
}
function rp(v) {
  return Number(v || 0).toLocaleString("id-ID");
}
function parts(d = new Date()) {
  return Object.fromEntries(
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Asia/Jakarta",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hourCycle: "h23",
    })
      .formatToParts(d)
      .map((p) => [p.type, p.value]),
  );
}
function todayKey(d = new Date()) {
  const p = parts(d);
  return `${p.year}-${p.month}-${p.day}`;
}
function monthKey(d = new Date()) {
  return todayKey(d).slice(0, 7);
}
function monthStartKey(m = monthKey()) {
  return `${String(m || monthKey()).slice(0, 7)}-01`;
}
function monthEndKey(m = monthKey()) {
  const [y, mo] = String(m || monthKey())
    .slice(0, 7)
    .split("-")
    .map(Number);
  const last = new Date(Date.UTC(y, mo, 0)).getUTCDate();
  return `${String(y).padStart(4, "0")}-${String(mo).padStart(2, "0")}-${String(last).padStart(2, "0")}`;
}
function timeNow() {
  const p = parts();
  return `${p.hour}:${p.minute}`;
}
function dateID(k) {
  if (!k) return "-";
  const [y, m, d] = String(k).split("-");
  return `${d}/${m}/${y}`;
}
function monthID(k) {
  if (!k) return "-";
  const [y, m] = String(k).split("-");
  return `${m}/${y}`;
}
function ms(r) {
  const n = Number(r?.createdAtMs || r?.updatedAtMs || r?.deletedAtMs || 0);
  if (n) return n;
  const t = r?.createdAt || r?.updatedAt || r?.deletedAt;
  if (t?.toMillis) return t.toMillis();
  if (t?.seconds) return t.seconds * 1000;
  return 0;
}
function timeID(m) {
  if (!m) return "--:--";
  const p = parts(new Date(m));
  return `${p.hour}:${p.minute}`;
}
function deleted(x) {
  return x?.deleted === true || x?.deleted === "true";
}
function sortDesc(a) {
  return [...(a || [])].sort((x, y) => ms(y) - ms(x));
}
function isAdmin(u) {
  return key(u?.role) === "admin" || ADMIN.includes(key(u?.username || u?.id));
}
function isDailyUser(user = state.user) {
  const r = key(user?.role);
  return r === "harian" || r === "daily" || r === "karyawan_harian";
}
function isDaily() {
  return isDailyUser(state.user);
}
function truthyFlag(value) {
  return (
    value === true ||
    value === 1 ||
    String(value || "").toLowerCase() === "true" ||
    String(value || "") === "1"
  );
}
function isTrialUser(user = state.user) {
  const value = String(
      user?.accountType || user?.mode || user?.type || "",
    ).toLowerCase(),
    role = String(user?.role || "").toLowerCase(),
    username = key(user?.username || user?.id || user?.user || "");
  return (
    !!user &&
    (truthyFlag(user.isDummy) ||
      truthyFlag(user.trialMode) ||
      truthyFlag(user.dummy) ||
      truthyFlag(user.dummyMode) ||
      truthyFlag(user.isTrial) ||
      truthyFlag(user.trial) ||
      truthyFlag(user.excludeFromReports) ||
      truthyFlag(user.excludeFromReport) ||
      value === "dummy" ||
      value === "dumy" ||
      value === "trial" ||
      role === "dummy" ||
      role === "dumy" ||
      role === "trial" ||
      username === "dummy" ||
      username.startsWith("dummy_") ||
      username.includes("_dummy") ||
      username === "dumy" ||
      username.startsWith("dumy_") ||
      username.includes("_dumy") ||
      username === "trial" ||
      username.startsWith("trial_") ||
      username.includes("_trial"))
  );
}
function isRismaSpecialUser(user = state.user) {
  return key(user?.username || user?.id || user?.user) === "risma";
}
function isDeviceFreeUser(user = state.user) {
  return (
    !!user &&
    (isDailyUser(user) || isTrialUser(user) || isRismaSpecialUser(user))
  );
}
function isAttendanceFreeUser(user = state.user) {
  return (
    !!user &&
    (isDailyUser(user) || isTrialUser(user) || isRismaSpecialUser(user))
  );
}
function trialRecordFlags(user = state.user) {
  return isTrialUser(user)
    ? {
        isDummy: true,
        trialMode: true,
        accountType: "dummy",
        excludeFromReports: true,
      }
    : {
        isDummy: false,
        trialMode: false,
        accountType: "normal",
        excludeFromReports: false,
      };
}
function isTrialRecord(rec) {
  if (!rec) return false;
  if (
    truthyFlag(rec.isDummy) ||
    truthyFlag(rec.trialMode) ||
    truthyFlag(rec.excludeFromReports) ||
    String(rec.accountType || "").toLowerCase() === "dummy"
  )
    return true;
  const u = key(rec.user || rec.username || rec.targetUsername || "");
  if (!u) return false;
  if (key(state.user?.username) === u) return isTrialUser(state.user);
  const found = (state.data.targetUsers || []).find(
    (x) => key(x.username || x.id) === u,
  );
  return isTrialUser(found);
}
function recordMatchesCurrentAccount(rec) {
  return isTrialUser() ? isTrialRecord(rec) : !isTrialRecord(rec);
}
function trialSessionFields(data = {}) {
  const dummy = isTrialUser(data);
  return {
    isDummy: dummy,
    trialMode: dummy,
    accountType: dummy ? "dummy" : "normal",
    excludeFromReports: dummy,
    trialTargetAmount: dummy ? Number(data.trialTargetAmount || 10000) : 0,
    trialBonusAmount: dummy ? Number(data.trialBonusAmount || 1000) : 0,
  };
}
function hasBonusValue(value) {
  return value !== undefined && value !== null && String(value).trim() !== "";
}
function globalTransactionBonusRate() {
  const r = Number(state.data.bonus?.transactionBonusRate);
  return Number.isFinite(r) && r >= 0 ? r : DEFAULT_BONUS.transactionBonusRate;
}
function globalClosingBonusPerMinute() {
  const n = Number(state.data.bonus?.closingBonusPerMinute);
  return Number.isFinite(n) && n >= 0 ? n : DEFAULT_BONUS.closingBonusPerMinute;
}
function normalizeClosingDeadlineParts(
  value = null,
  fallback = { hour: 18, minute: 0 },
) {
  const fb = fallback || { hour: 18, minute: 0 };
  if (value && typeof value === "object") {
    const direct =
      value.deadlineTime ??
      value.closingDeadlineTime ??
      value.deadline ??
      value.jamClosing ??
      value.jam_closing ??
      value.label ??
      null;
    if (direct !== null && direct !== undefined && String(direct).trim() !== "")
      return normalizeClosingDeadlineParts(direct, fb);
    const h = Number(
        value.deadlineHour ?? value.closingDeadlineHour ?? value.hour,
      ),
      m = Number(
        value.deadlineMinute ?? value.closingDeadlineMinute ?? value.minute,
      );
    if (
      Number.isInteger(h) &&
      Number.isInteger(m) &&
      h >= 0 &&
      h <= 23 &&
      m >= 0 &&
      m <= 59
    )
      return { hour: h, minute: m };
    const total = Number(
      value.deadlineMinutes ?? value.closingDeadlineMinutes ?? NaN,
    );
    if (Number.isFinite(total) && total >= 0)
      return {
        hour: Math.floor(total / 60) % 24,
        minute: Math.floor(total % 60),
      };
    return fb;
  }
  const raw = String(value ?? "")
    .trim()
    .replace(".", ":")
    .replace(/\s*WIB$/i, "");
  const match = raw.match(/^(\d{1,2}):(\d{2})/);
  if (match) {
    const h = Number(match[1]),
      m = Number(match[2]);
    if (
      Number.isInteger(h) &&
      Number.isInteger(m) &&
      h >= 0 &&
      h <= 23 &&
      m >= 0 &&
      m <= 59
    )
      return { hour: h, minute: m };
  }
  return fb;
}
function normalizeBonusSettings(data = {}) {
  const d = data || {},
    parts = normalizeClosingDeadlineParts(d, { hour: 18, minute: 0 }),
    label = `${String(parts.hour).padStart(2, "0")}:${String(parts.minute).padStart(2, "0")}`,
    rate = Number.isFinite(Number(d.transactionBonusRate))
      ? Number(d.transactionBonusRate)
      : DEFAULT_BONUS.transactionBonusRate,
    pct = Number.isFinite(Number(d.transactionBonusPercent))
      ? Number(d.transactionBonusPercent)
      : Number((rate * 100).toFixed(3)),
    closing = Number.isFinite(Number(d.closingBonusPerMinute))
      ? Number(d.closingBonusPerMinute)
      : DEFAULT_BONUS.closingBonusPerMinute;
  return {
    ...DEFAULT_BONUS,
    ...d,
    transactionBonusRate: rate,
    transactionBonusPercent: pct,
    closingBonusPerMinute: closing,
    closingDeadlineTime: label,
    closingDeadlineHour: parts.hour,
    closingDeadlineMinute: parts.minute,
    closingDeadlineMinutes: parts.hour * 60 + parts.minute,
  };
}
function closingDeadlineTimeLabel(source = null) {
  const parts = normalizeClosingDeadlineParts(
    source || state.data.bonus || DEFAULT_BONUS,
    { hour: 18, minute: 0 },
  );
  return `${String(parts.hour).padStart(2, "0")}:${String(parts.minute).padStart(2, "0")}`;
}
function closingDeadlineMinutes(source = null) {
  const parts = normalizeClosingDeadlineParts(
    source || state.data.bonus || DEFAULT_BONUS,
    { hour: 18, minute: 0 },
  );
  return parts.hour * 60 + parts.minute;
}
function userTransactionBonusRate(user = state.user) {
  const u = user || {};
  if (hasBonusValue(u.transactionBonusRate)) {
    const r = Number(u.transactionBonusRate);
    if (Number.isFinite(r) && r > 0) return r;
  }
  if (hasBonusValue(u.transactionBonusPercent)) {
    const p = Number(u.transactionBonusPercent);
    if (Number.isFinite(p) && p >= 0) return p / 100;
  }
  if (hasBonusValue(u.transactionBonusRate)) {
    const r = Number(u.transactionBonusRate);
    if (Number.isFinite(r) && r >= 0) return r;
  }
  if (isDailyUser(u)) {
    const hasDailyRate = hasBonusValue(u.dailyBonusRate),
      hasDailyPercent = hasBonusValue(u.dailyBonusPercent);
    if (hasDailyRate) {
      const r = Number(u.dailyBonusRate);
      if (Number.isFinite(r) && r > 0) return r;
    }
    if (hasDailyPercent) {
      const p = Number(u.dailyBonusPercent);
      if (Number.isFinite(p) && p >= 0) return p / 100;
    }
    if (hasDailyRate) {
      const r = Number(u.dailyBonusRate);
      if (Number.isFinite(r) && r >= 0) return r;
    }
  }
  return globalTransactionBonusRate();
}
function userTransactionBonusPercent(user = state.user) {
  return Number((userTransactionBonusRate(user) * 100).toFixed(3));
}
function userClosingBonusPerMinute(user = state.user) {
  const u = user || {};
  if (isDailyUser(u)) return 0;
  if (hasBonusValue(u.closingBonusPerMinute)) {
    const n = Number(u.closingBonusPerMinute);
    if (Number.isFinite(n) && n >= 0) return n;
  }
  return globalClosingBonusPerMinute();
}
function txBonusRate(t) {
  if (t) {
    if (hasBonusValue(t.bonusRate)) {
      const r = Number(t.bonusRate);
      if (Number.isFinite(r) && r >= 0) return r;
    }
    if (hasBonusValue(t.transactionBonusRate)) {
      const r = Number(t.transactionBonusRate);
      if (Number.isFinite(r) && r >= 0) return r;
    }
    if (hasBonusValue(t.bonusPercent)) {
      const p = Number(t.bonusPercent);
      if (Number.isFinite(p) && p >= 0) return p / 100;
    }
    if (hasBonusValue(t.transactionBonusPercent)) {
      const p = Number(t.transactionBonusPercent);
      if (Number.isFinite(p) && p >= 0) return p / 100;
    }
  }
  return userTransactionBonusRate();
}
function txBonusValue(t) {
  return Math.round(Number(t?.amount || 0) * txBonusRate(t));
}
function txBonusSum(list) {
  return (list || []).reduce((sum, t) => sum + txBonusValue(t), 0);
}
function roleLabel() {
  return isDaily() ? "Karyawan Harian" : "Karyawan Staff";
}
function roleCard() {
  const trial = isTrialUser(),
    free = isAttendanceFreeUser(),
    lock = free ? null : missedAttendanceLockForDate();
  const locked = trial
    ? false
    : !!lock || isClosedToday() || (!free && !todayAtt());
  const label = locked ? "Terkunci" : "Terbuka";
  const cls = trial ? "amber" : locked ? "red" : "green";
  const note = trial
    ? "mode trial siap transaksi"
    : lock
      ? `tidak absen ${dateID(lock.missedDate)}`
      : isClosedToday()
        ? "sudah closing"
        : isRismaSpecialUser()
          ? "risma bebas absen"
          : isDaily()
            ? "siap transaksi"
            : todayAtt()
              ? "sudah absen"
              : "belum absen";
  const ico = locked ? "!" : "OK";
  return `<div class="role-card ${locked ? "locked" : "open"}"><div class="between"><div><div class="role-title">Status Transaksi</div><div class="hint" style="margin-top:3px">${note}</div></div><div class="lock-status ${locked ? "locked" : "open"}"><span class="lock-ico">${ico}</span><span class="pill ${cls}">${label}</span></div></div></div>`;
}
function headerTxStatus() {
  if (!state.user) return "";
  const free = isAttendanceFreeUser();
  const locked = isTrialUser()
    ? false
    : !!missedAttendanceLockForDate() ||
      isClosedToday() ||
      (!free && !todayAtt());
  const label = locked ? "Terkunci" : "Terbuka";
  const ico = locked ? "!" : "OK";
  return `<span class="trx-head-status ${locked ? "locked" : "open"}"><span class="lock-ico">${ico}</span>${label}</span>`;
}
function txDate(t) {
  return String(t.dateKey || (ms(t) ? todayKey(new Date(ms(t))) : "")).slice(
    0,
    10,
  );
}
function txMonth(t) {
  return String(t.monthKey || txDate(t).slice(0, 7));
}
function attDate(a) {
  return String(a.dateKey || (ms(a) ? todayKey(new Date(ms(a))) : "")).slice(
    0,
    10,
  );
}
function attendanceDocId(user, dateKey = todayKey()) {
  return (
    "staffatt_" + key(user) + "_" + String(dateKey || todayKey()).slice(0, 10)
  );
}
function dedupeAttendanceRows(rows) {
  const map = new Map();
  sortDesc((rows || []).filter((a) => a && !deleted(a))).forEach((a) => {
    const u = key(a.user || state.user?.username),
      d = attDate(a),
      k = u + "_" + d;
    if (!u || !d) return;
    if (!map.has(k)) map.set(k, a);
  });
  return sortDesc([...map.values()]);
}
function showLoad(v) {
  state.busy = !!v;
  $("loading").style.display = v ? "flex" : "none";
}
function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.className = "toast show";
  setTimeout(() => (t.className = "toast"), 2100);
}
function manualSeenKey() {
  return MANUAL_BONUS_SEEN + "_" + key(state.user?.username || "guest");
}
function getManualSeen() {
  try {
    const raw = JSON.parse(localStorage.getItem(manualSeenKey()) || "[]");
    return new Set(Array.isArray(raw) ? raw.map(String) : []);
  } catch (e) {
    return new Set();
  }
}
function saveManualSeen(set) {
  try {
    localStorage.setItem(manualSeenKey(), JSON.stringify([...set].slice(-600)));
  } catch (e) {}
}
function manualBonusDate(b) {
  const raw = String(b?.dateKey || b?.bonusDate || b?.date || "").slice(0, 10);
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const fromId = String(
    b?.id || b?.docId || b?._docId || b?.clientId || "",
  ).match(/(\d{4}-\d{2}-\d{2})/);
  if (fromId) return fromId[1];
  const n = ms(b);
  // Jangan fallback ke hari ini, karena bonus lama tanpa dateKey bisa ikut muncul lagi saat hari/bulan berganti.
  return n ? todayKey(new Date(n)) : "";
}
function manualBonusMonth(b) {
  const raw = String(b?.monthKey || b?.bonusMonth || b?.month || "").slice(
    0,
    7,
  );
  if (/^\d{4}-\d{2}$/.test(raw)) return raw;
  const d = manualBonusDate(b);
  return d ? d.slice(0, 7) : "";
}
function manualBonusFallbackId(b) {
  return `${key(b?.user)}_${manualBonusDate(b)}_${Number(b?.amount || 0)}_${ms(b) || ""}`;
}
function manualBonusId(b) {
  return String(b?.id || b?.docId || b?.clientId || manualBonusFallbackId(b));
}
function manualBonusTargetUsername(b) {
  return key(
    b?.targetUsername ||
      b?.user ||
      b?.username ||
      b?.staffUsername ||
      b?.staff ||
      "",
  );
}
function manualBonusIsSeen(b, seen) {
  return seen.has(manualBonusId(b)) || seen.has(manualBonusFallbackId(b));
}
function markManualBonusesSeen(rows) {
  const seen = getManualSeen();
  (rows || []).forEach((b) => {
    seen.add(manualBonusId(b));
    seen.add(manualBonusFallbackId(b));
  });
  saveManualSeen(seen);
}
function unreadManualBonusRows() {
  if (!state.user) return [];
  const seen = getManualSeen(),
    d = todayKey();
  return sortDesc(
    (state.data.manual || []).filter((b) => {
      if (
        !b ||
        deleted(b) ||
        isTargetAutoBonusRow(b) ||
        isBonusWithdrawalRow(b) ||
        manualBonusDate(b) !== d ||
        Number(b.amount || 0) <= 0 ||
        !canReceiveManualBonusRow(b)
      )
        return false;
      return !manualBonusIsSeen(b, seen);
    }),
  );
}
function canReceiveManualBonusRow(b) {
  const current = key(state.user?.username || "");
  const target = manualBonusTargetUsername(b);
  return !!current && !!target && target === current;
}
function dismissManualBonusNotice() {
  markManualBonusesSeen(unreadManualBonusRows());
  closeModal();
  render();
}
function manualBonusDisplayNote(value, fallback = "") {
  const note = String(value || fallback || "").trim();
  return /bonus\s*manual/i.test(note) ? "" : note;
}
function manualBonusNoticeCard() {
  const rows = unreadManualBonusRows();
  if (!rows.length) return "";
  const latest = rows[0];
  const total = Number(latest.amount || 0);
  const note =
    manualBonusDisplayNote(
      latest.note || latest.description || latest.reason,
      "Bonus dari Mimin",
    ) || "Bonus dari Mimin";
  return `<div class="card manual-bonus-alert"><div class="between"><div style="display:flex;align-items:center;gap:9px;min-width:0"><span class="manual-bonus-ico">🎁</span><div style="min-width:0"><div class="label">Ada Bonus Masuk Nih</div><div class="stat-val">Rp ${rp(total)}</div><div class="hint" style="margin-top:2px">${esc(note)}</div></div></div><button class="btn success" onclick="dismissManualBonusNotice()">OK</button></div></div>`;
}
function notifyNewManualBonuses() {
  const rows = unreadManualBonusRows();
  if (!rows.length) return;
  const latest = rows[0];
  const total = Number(latest.amount || 0);
  const note = manualBonusDisplayNote(
    latest.note || latest.description || latest.reason,
    "",
  );
  // Tandai semua yang sudah kebaca supaya bonus lama hari ini tidak ikut ke popup berikutnya.
  markManualBonusesSeen(rows);
  render();
  try {
    if (navigator.vibrate) navigator.vibrate([80, 40, 80, 40, 110]);
  } catch (e) {}
  playBonusSound();
  toast(`Asik dapet bonus Rp ${rp(total)}`);
  showManualBonusParty(total, note, 1);
}

function bonusWithdrawalSeenKey() {
  return BONUS_WITHDRAWAL_SEEN + "_" + key(state.user?.username || "guest");
}
function getBonusWithdrawalSeen() {
  try {
    const raw = JSON.parse(localStorage.getItem(bonusWithdrawalSeenKey()) || "[]");
    return new Set(Array.isArray(raw) ? raw.map(String) : []);
  } catch (e) {
    return new Set();
  }
}
function saveBonusWithdrawalSeen(set) {
  try {
    localStorage.setItem(
      bonusWithdrawalSeenKey(),
      JSON.stringify([...set].slice(-600)),
    );
  } catch (e) {}
}
function bonusWithdrawalFallbackId(b) {
  return `${key(b?.user)}_${manualBonusDate(b)}_${bonusWithdrawalAmount(b)}_${ms(b) || ""}`;
}
function bonusWithdrawalId(b) {
  return String(b?.id || b?.docId || b?.clientId || bonusWithdrawalFallbackId(b));
}
function bonusWithdrawalIsSeen(b, seen) {
  return seen.has(bonusWithdrawalId(b)) || seen.has(bonusWithdrawalFallbackId(b));
}
function markBonusWithdrawalsSeen(rows) {
  const seen = getBonusWithdrawalSeen();
  (rows || []).forEach((b) => {
    seen.add(bonusWithdrawalId(b));
    seen.add(bonusWithdrawalFallbackId(b));
  });
  saveBonusWithdrawalSeen(seen);
}
function bonusWithdrawalEarned(row = {}) {
  const saved = Number(row.bonusEarned ?? row.earnedBonus ?? row.totalBonus);
  return Number.isFinite(saved) && saved > 0 ? saved : totalBonus();
}
function bonusWithdrawalWithdrawnAfter(row = {}) {
  const saved = Number(row.withdrawnAfter ?? row.bonusWithdrawnAfter);
  return Number.isFinite(saved) && saved >= 0 ? saved : bonusWithdrawn();
}
function bonusWithdrawalRemainingAfter(row = {}) {
  const saved = Number(row.remainingAfter ?? row.remainingBalance ?? row.sisaBonus);
  if (Number.isFinite(saved) && saved >= 0) return saved;
  return Math.max(0, bonusWithdrawalEarned(row) - bonusWithdrawalWithdrawnAfter(row));
}
function unreadBonusWithdrawalRows() {
  if (!state.user) return [];
  const seen = getBonusWithdrawalSeen(),
    d = todayKey();
  return sortDesc(
    (state.data.manual || []).filter((b) => {
      if (
        !b ||
        deleted(b) ||
        !isBonusWithdrawalRow(b) ||
        !recordMatchesCurrentAccount(b) ||
        manualBonusDate(b) !== d ||
        bonusWithdrawalAmount(b) <= 0 ||
        !canReceiveManualBonusRow(b)
      )
        return false;
      return !bonusWithdrawalIsSeen(b, seen);
    }),
  );
}
function dismissBonusWithdrawalNotice() {
  markBonusWithdrawalsSeen(unreadBonusWithdrawalRows());
  closeModal();
  render();
}
function bonusWithdrawalNoticeCard() {
  const rows = unreadBonusWithdrawalRows();
  if (!rows.length) return "";
  const latest = rows[0];
  const amount = bonusWithdrawalAmount(latest);
  const remaining = bonusWithdrawalRemainingAfter(latest);
  const note = String(latest.note || "Ambil bonus sebagian").trim();
  return `<div class="card bonus-withdrawal-alert" style="border-color:#fecdd3;background:#fffbfa"><div class="between" style="align-items:center"><div style="display:flex;align-items:center;gap:12px;min-width:0"><div style="background:#ffe4e6;color:#e11d48;width:38px;height:38px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-weight:900"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:22px;height:22px"><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/></svg></div><div style="min-width:0"><div class="label" style="color:#e11d48;font-size:11px;letter-spacing:0.5px">BONUS DIAMBIL</div><div class="stat-val" style="color:#111827;font-size:18px;margin-top:2px">Rp ${rp(amount)}</div><div class="hint" style="margin-top:3px;font-weight:600;color:#4b5563;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(note)}</div></div></div><div style="text-align:right;flex-shrink:0"><button class="btn" style="background:#e11d48;color:#fff;min-height:36px;padding:0 16px;border-radius:12px" onclick="dismissBonusWithdrawalNotice()">OK</button><div class="hint" style="margin-top:6px;font-size:10px;font-weight:800;color:#9ca3af">Sisa: Rp ${rp(remaining)}</div></div></div></div>`;
}
function showBonusWithdrawalParty(row) {
  document.querySelectorAll(".manual-bonus-party").forEach((el) => el.remove());
  const amount = bonusWithdrawalAmount(row);
  const remaining = bonusWithdrawalRemainingAfter(row);
  const note = String(row?.note || "Ambil bonus sebagian").trim();
  const wrap = document.createElement("div");
  wrap.className = "manual-bonus-party";
  wrap.innerHTML = `<div class="manual-bonus-box" style="background:linear-gradient(135deg,#e11d48,#be185d)"><div class="manual-bonus-emoji">💸</div><div class="manual-bonus-title" style="margin-top:8px">BONUS DIAMBIL</div><div class="manual-bonus-sub" style="opacity:0.9">Pengambilan bonus disetujui</div><div class="manual-bonus-amount" style="color:#ffe4e6;font-size:24px;margin:12px 0">- Rp ${rp(amount)}</div><div class="manual-bonus-note" style="background:rgba(255,255,255,0.15);padding:8px 14px;border-radius:12px;display:inline-block;margin:4px 0;font-weight:800">${esc(note)}</div><div style="margin-top:18px;display:flex;flex-direction:column;align-items:center;gap:14px"><div class="manual-bonus-count" style="margin:0;font-size:12px;padding:6px 16px;letter-spacing:0.3px">Sisa bonus: &nbsp;<b style="color:#fff">Rp ${rp(remaining)}</b></div><button class="manual-bonus-close" onclick="closeManualBonusParty()" type="button" style="color:#be185d;margin:0;width:100%">Tutup</button></div></div>`;
  (document.querySelector(".app") || document.body).appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add("show"));
}
function notifyNewBonusWithdrawals() {
  const rows = unreadBonusWithdrawalRows();
  if (!rows.length) return;
  const latest = rows[0];
  const id = bonusWithdrawalId(latest);
  if (bonusWithdrawalAnnounced.has(id)) return;
  bonusWithdrawalAnnounced.add(id);
  try {
    if (navigator.vibrate) navigator.vibrate([70, 40, 90]);
  } catch (e) {}
  playBonusSound();
  toast(`Bonus diambil Rp ${rp(bonusWithdrawalAmount(latest))}`);
  showBonusWithdrawalParty(latest);
}

function targetDailyDocId(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10);
  return isTrialUser()
    ? `trial_daily_target_${d}_${key(state.user?.username)}`
    : `daily_target_${d}`;
}
function targetBonusDocId(dateKey, username) {
  const d = String(dateKey || todayKey()).slice(0, 10),
    u = key(username);
  return isTrialUser()
    ? `trial_targetbonus_${d}_${u}`
    : `targetbonus_${d}_${u}`;
}
function targetRewardDocId(dateKey, username) {
  const d = String(dateKey || todayKey()).slice(0, 10),
    u = key(username);
  return isTrialUser()
    ? `trial_targetreward_${d}_${u}`
    : `targetreward_${d}_${u}`;
}
function targetNotificationDocId(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10);
  return isTrialUser()
    ? `trial_targetnotif_${d}_${key(state.user?.username)}`
    : `targetnotif_${d}`;
}
function targetNoticeSeenKey() {
  return TARGET_NOTICE_SEEN + "_" + key(state.user?.username || "guest");
}
function getTargetNoticeSeen() {
  try {
    const raw = JSON.parse(localStorage.getItem(targetNoticeSeenKey()) || "[]");
    return new Set(Array.isArray(raw) ? raw.map(String) : []);
  } catch (e) {
    return new Set();
  }
}
function saveTargetNoticeSeen(set) {
  try {
    localStorage.setItem(
      targetNoticeSeenKey(),
      JSON.stringify([...set].slice(-180)),
    );
  } catch (e) {}
}
function targetNoticeId(s = state.data.dailyTarget || {}) {
  const d = String(s.dateKey || todayKey()).slice(0, 10),
    u = key(state.user?.username || "");
  return `target_reached_${d}_${u}_${Number(s.targetAmount || 0)}`;
}
function currentUserTargetRewarded(s = state.data.dailyTarget || {}) {
  const u = key(state.user?.username || "");
  if (!u || isDailyUser(state.user)) return false;
  const d = String(s.dateKey || todayKey()).slice(0, 10);
  const savedRewarded = Array.isArray(s.rewardedUsers)
    ? s.rewardedUsers.map(key)
    : [];
  if (savedRewarded.includes(u)) return true;
  return dailyTargetRewardPlan(d).rewardedUsers.map(key).includes(u);
}
function unreadTargetNotice() {
  if (!state.user) return null;
  const s = syncDailyTargetState();
  if (
    String(s.dateKey || "").slice(0, 10) !== todayKey() ||
    !s.reached ||
    !currentUserTargetRewarded(s)
  )
    return null;
  const id = targetNoticeId(s);
  if (getTargetNoticeSeen().has(id)) return null;
  return {
    id,
    dateKey: s.dateKey,
    targetAmount: Number(s.targetAmount || 0),
    totalAmount: Number(s.totalAmount || 0),
    bonusAmount: Number(s.bonusAmount || 0),
  };
}
function markTargetNoticeSeen(notice = unreadTargetNotice()) {
  if (!notice) return;
  const seen = getTargetNoticeSeen();
  seen.add(notice.id);
  saveTargetNoticeSeen(seen);
}
function dismissTargetNotice() {
  markTargetNoticeSeen();
  closeModal();
  render();
}
function targetReachedNoticeCard() {
  const n = unreadTargetNotice();
  if (!n) return "";
  return `<div class="card target-reached-alert"><div class="between"><div style="display:flex;align-items:center;gap:9px;min-width:0"><span class="target-reached-ico">✓</span><div style="min-width:0"><div class="label">Target Hari Ini Tercapai</div><div class="stat-val">Rp ${rp(n.bonusAmount)}</div><div class="hint" style="margin-top:2px">Bonus target otomatis masuk.</div></div></div><button class="btn success" onclick="dismissTargetNotice()">OK</button></div></div>`;
}
function showTargetReachedParty(notice) {
  document.querySelectorAll(".manual-bonus-party").forEach((el) => el.remove());
  const wrap = document.createElement("div");
  wrap.className = "manual-bonus-party";
  const pieces = Array.from(
    { length: 34 },
    () =>
      `<i style="--x:${Math.round(Math.random() * 250 - 125)}px;--y:${Math.round(Math.random() * -190 - 45)}px;--r:${Math.round(Math.random() * 720 - 360)}deg;--d:${(Math.random() * 0.2).toFixed(2)}s"></i>`,
  ).join("");
  wrap.innerHTML = `<div class="manual-bonus-confetti">${pieces}</div><div class="manual-bonus-box"><div class="manual-bonus-emoji">✓</div><div class="manual-bonus-title">TARGET HARI INI TERCAPAI</div><div class="manual-bonus-sub">Bonus target otomatis masuk</div><div class="manual-bonus-amount">Rp ${rp(notice.bonusAmount || 0)}</div><button class="manual-bonus-close" onclick="closeManualBonusParty()" type="button">Tutup</button></div>`;
  (document.querySelector(".app") || document.body).appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add("show"));
}
function notifyTargetReachedInApp() {
  const notice = unreadTargetNotice();
  if (!notice || targetNoticeAnnounced.has(notice.id)) return;
  targetNoticeAnnounced.add(notice.id);
  render();
  try {
    if (navigator.vibrate) navigator.vibrate([90, 45, 90, 45, 130]);
  } catch (e) {}
  playBonusSound();
  toast("Target hari ini tercapai");
  showTargetReachedParty(notice);
}
function targetNumberSetting(data, keys, fallback) {
  for (const k of keys) {
    const n = Number(data?.[k]);
    if (Number.isFinite(n) && n >= 0) return n;
  }
  return fallback;
}
function normalizeTargetSettingDate(value, fallback = todayKey()) {
  const raw = String(value || "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw.slice(0, 10))) return raw.slice(0, 10);
  let m = raw.match(/^(\d{1,2})$/);
  if (m) {
    const day = Number(m[1]);
    if (day >= 1 && day <= 31)
      return `${todayKey().slice(0, 7)}-${String(day).padStart(2, "0")}`;
  }
  m = raw.match(/^(\d{1,2})[\/-](\d{1,2})$/);
  if (m) {
    const day = Number(m[1]),
      month = Number(m[2]);
    if (day >= 1 && day <= 31 && month >= 1 && month <= 12)
      return `${todayKey().slice(0, 4)}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
  }
  return fallback;
}
function targetSettingDocId(dateKey = todayKey()) {
  return `daily_target_${normalizeTargetSettingDate(dateKey, todayKey())}`;
}
function targetSettingDate(row = {}) {
  const idDate = String(row.id || "").match(
    /^daily_target_(\d{4}-\d{2}-\d{2})$/,
  );
  return normalizeTargetSettingDate(
    row.effectiveDate ||
      row.dateKey ||
      row.startDate ||
      row.targetDate ||
      (idDate ? idDate[1] : ""),
    "",
  );
}
function isDailyTargetSettingRow(row = {}) {
  const id = String(row.id || "");
  return (
    id === "daily_target" ||
    id === "__daily_target" ||
    id === "default" ||
    id.startsWith("daily_target_") ||
    String(row.type || "") === "daily_target_setting" ||
    String(row.targetSettingType || "") === "daily_target"
  );
}
function normalizeDailyTargetSettings(data = {}, fallbackDate = todayKey()) {
  const activeDate =
    targetSettingDate(data) ||
    normalizeTargetSettingDate(fallbackDate, todayKey());
  return {
    id: String(data.id || ""),
    dateKey: activeDate,
    effectiveDate: activeDate,
    targetAmount: targetNumberSetting(
      data,
      ["targetAmount", "dailyTargetAmount", "dailyOmzetTarget", "omzetTarget"],
      DAILY_TARGET_AMOUNT,
    ),
    bonusAmount: targetNumberSetting(
      data,
      [
        "bonusAmount",
        "bonusTargetAmount",
        "dailyTargetBonusAmount",
        "targetBonusAmount",
        "BONUS_TARGET_AMOUNT",
      ],
      BONUS_TARGET_AMOUNT,
    ),
    updatedAtMs: Number(data.updatedAtMs || 0),
  };
}
function pickDailyTargetSettings(rows = [], dateKey = todayKey()) {
  const targetDate = normalizeTargetSettingDate(dateKey, todayKey());
  let best = null,
    bestDate = "",
    bestUpdated = 0;
  rows.filter(isDailyTargetSettingRow).forEach((row) => {
    const rowDate = targetSettingDate(row);
    if (rowDate && rowDate > targetDate) return;
    const scoreDate = rowDate || "0000-00-00",
      updated = Number(row.updatedAtMs || 0);
    if (
      !best ||
      scoreDate > bestDate ||
      (scoreDate === bestDate && updated >= bestUpdated)
    ) {
      best = row;
      bestDate = scoreDate;
      bestUpdated = updated;
    }
  });
  return best ? normalizeDailyTargetSettings(best, targetDate) : null;
}
function dailyTargetSettings(dateKey = todayKey()) {
  const settings = normalizeDailyTargetSettings(
    state.data.targetSettings || {},
    dateKey,
  );
  if (isTrialUser()) {
    const target = Number(state.user?.trialTargetAmount || 0),
      bonus = Number(state.user?.trialBonusAmount || 0);
    return {
      targetAmount: target > 0 ? target : 10000,
      bonusAmount: bonus >= 0 ? bonus : 1000,
    };
  }
  return settings;
}
function targetUserKey(user) {
  return key(user?.username || user?.id || user?.user || "");
}
function isTargetDailyRole(user) {
  const r = key(user?.role);
  return r === "harian" || r === "daily" || r === "karyawan_harian";
}
function activeTargetUsers() {
  const rows = (state.data.targetUsers || [])
    .map((u) => ({
      id: u.id || targetUserKey(u),
      username: targetUserKey(u),
      name: u.name || targetUserKey(u),
      role: u.role || "staff",
      ...u,
    }))
    .filter(
      (u) => u.username && u.active !== false && !deleted(u) && !isAdmin(u),
    );
  if (isTrialUser()) {
    const current = {
      id: key(state.user?.username),
      username: key(state.user?.username),
      name: state.user?.name || key(state.user?.username),
      role: state.user?.role || "staff",
      ...state.user,
    };
    const trialRows = rows.filter(
      (u) => isTrialUser(u) && u.username === key(state.user?.username),
    );
    return trialRows.length ? trialRows : [current];
  }
  return rows.filter((u) => !isTrialUser(u));
}
function dailyTargetTransactions(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10);
  const active = activeTargetUsers(),
    activeSet = new Set(active.map((u) => u.username));
  return sortDesc(
    (state.data.targetTx || []).filter((t) => {
      if (!t || deleted(t) || txDate(t) !== d) return false;
      const user = key(t.user);
      if (isTrialUser())
        return isTrialRecord(t) && user === key(state.user?.username);
      return !isTrialRecord(t) && (!activeSet.size || activeSet.has(user));
    }),
  );
}
function dailyTargetSummary(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10),
    settings = dailyTargetSettings(d),
    targetAmount = Math.max(
      1,
      Number(settings.targetAmount || DAILY_TARGET_AMOUNT),
    );
  const rows = dailyTargetTransactions(d);
  const totalAmount = rows.reduce((sum, t) => sum + Number(t.amount || 0), 0);
  const rawPercent = (totalAmount / targetAmount) * 100;
  const progressPercent = Number.isFinite(rawPercent)
    ? Number(rawPercent.toFixed(2))
    : 0;
  return {
    dateKey: d,
    targetAmount,
    totalAmount,
    progressPercent,
    reached: totalAmount >= targetAmount,
    remainingAmount: Math.max(0, targetAmount - totalAmount),
    bonusAmount: Number(settings.bonusAmount || 0),
  };
}
function targetAttendanceUsers(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10),
    set = new Set();
  if (isTrialUser()) {
    const u = key(state.user?.username);
    if (u) set.add(u);
    return set;
  }
  dedupeAttendanceRows(state.data.targetAtt || []).forEach((a) => {
    if (!deleted(a) && attDate(a) === d) {
      if (isTrialUser()) {
        if (isTrialRecord(a) && key(a.user) === key(state.user?.username))
          set.add(key(a.user));
      } else if (!isTrialRecord(a)) set.add(key(a.user));
    }
  });
  return set;
}
function targetTransactionUsers(dateKey = todayKey()) {
  const set = new Set();
  dailyTargetTransactions(dateKey).forEach((t) => {
    const u = key(t.user);
    if (u) set.add(u);
  });
  return set;
}
function dailyTargetRewardPlan(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10),
    attendance = targetAttendanceUsers(d),
    users = activeTargetUsers();
  const activeUsers = users.map((u) => u.username);
  const txUsers = targetTransactionUsers(d);
  const rewardedUsers = users
    .filter((u) =>
      u.username === "risma"
        ? txUsers.has("risma")
        : !isTargetDailyRole(u) && attendance.has(u.username),
    )
    .map((u) => u.username);
  const userMap = new Map(users.map((u) => [u.username, u]));
  return {
    activeUsers,
    rewardedUsers,
    users: rewardedUsers.map((u) => userMap.get(u)).filter(Boolean),
  };
}
function syncDailyTargetState(extra = {}) {
  const summary = dailyTargetSummary();
  const current =
    state.data.dailyTarget || defaultDailyTargetState(summary.dateKey);
  state.data.dailyTarget = {
    ...defaultDailyTargetState(summary.dateKey),
    ...current,
    ...extra,
    ...summary,
    updatedAtMs: Date.now(),
  };
  return state.data.dailyTarget;
}
async function getDailyTargetSettingsFromServer(dateKey = todayKey()) {
  const d = normalizeTargetSettingDate(dateKey, todayKey());
  try {
    const snap = await getDocs(
      query(collection(db, TARGET_SETTINGS_TABLE), limit(1000)),
    );
    const rows = snap.docs.map((x) => ({ id: x.id, ...x.data() }));
    const picked = pickDailyTargetSettings(rows, d);
    if (picked) return picked;
  } catch (e) {
    console.warn(
      "jadwal target harian belum terbaca",
      e?.code || e?.message || e,
    );
  }
  const ids = ["daily_target", "__daily_target", "default"];
  for (const id of ids) {
    try {
      const snap = await getDocFromServer(doc(db, TARGET_SETTINGS_TABLE, id));
      if (snap.exists()) {
        const data = { id: snap.id, ...(snap.data() || {}) };
        const rowDate = targetSettingDate(data);
        if (!rowDate || rowDate <= d)
          return normalizeDailyTargetSettings(data, d);
      }
    } catch (e) {
      if (id === "daily_target")
        console.warn(
          "targetSettings belum terbaca",
          e?.code || e?.message || e,
        );
      break;
    }
  }
  return dailyTargetSettings(d);
}
async function loadDailyTargetData({ apply = true } = {}) {
  const d = todayKey();
  try {
    const [txSnap, userSnap, attSnap, targetSnap, settings] = await Promise.all(
      [
        getDocs(
          query(
            collection(db, "transactions"),
            where("dateKey", "==", d),
            limit(LIMITS.targetTxToday),
          ),
        ).catch(() => querySnapshot([])),
        getDocs(
          query(collection(db, "users"), limit(LIMITS.targetUsers)),
        ).catch(() => querySnapshot([])),
        getDocs(
          query(
            collection(db, "attendance"),
            where("dateKey", "==", d),
            limit(LIMITS.targetAttToday),
          ),
        ).catch(() => querySnapshot([])),
        getDocFromServer(
          doc(db, DAILY_TARGETS_TABLE, targetDailyDocId(d)),
        ).catch(() => null),
        getDailyTargetSettingsFromServer(d),
      ],
    );
    state.data.targetTx = sortDesc(
      txSnap.docs.map((x) => ({ id: x.id, ...x.data() })),
    );
    state.data.targetUsers = userSnap.docs.map((x) => ({
      id: x.id,
      username: key((x.data() || {}).username || x.id),
      ...x.data(),
    }));
    state.data.targetAtt = dedupeAttendanceRows(
      attSnap.docs.map((x) => ({ id: x.id, ...x.data() })),
    );
    state.data.targetSettings = settings;
    const serverTarget = targetSnap?.exists() ? targetSnap.data() : {};
    syncDailyTargetState(serverTarget || {});
    if (apply) scheduleDailyTargetCheck();
  } catch (e) {
    console.warn("target harian gagal dimuat", e?.code || e?.message || e);
    syncDailyTargetState();
  }
}
async function saveDailyTargetStatus(extra = {}) {
  const summary = dailyTargetSummary(),
    plan = dailyTargetRewardPlan(summary.dateKey),
    current = state.data.dailyTarget || {};
  const reachedAtMs = summary.reached
    ? Number(current.reachedAtMs || Date.now())
    : 0;
  const payload = {
    dateKey: summary.dateKey,
    targetAmount: summary.targetAmount,
    totalAmount: summary.totalAmount,
    progressPercent: summary.progressPercent,
    reached: summary.reached,
    reachedAt: summary.reached ? current.reachedAt || serverTimestamp() : null,
    reachedAtMs,
    bonusApplied: summary.reached
      ? Boolean(extra.bonusApplied ?? current.bonusApplied)
      : false,
    bonusAppliedAt: extra.bonusApplied
      ? current.bonusAppliedAt || serverTimestamp()
      : current.bonusAppliedAt || null,
    bonusAppliedAtMs: extra.bonusApplied
      ? Number(current.bonusAppliedAtMs || Date.now())
      : Number(current.bonusAppliedAtMs || 0),
    activeUsers: extra.activeUsers || plan.activeUsers,
    rewardedUsers: extra.rewardedUsers || current.rewardedUsers || [],
    updatedAt: serverTimestamp(),
    updatedAtMs: Date.now(),
  };
  state.data.dailyTarget = {
    ...defaultDailyTargetState(summary.dateKey),
    ...current,
    ...payload,
  };
  try {
    await setDoc(
      doc(db, DAILY_TARGETS_TABLE, targetDailyDocId(summary.dateKey)),
      payload,
      { merge: true },
    );
  } catch (e) {
    console.warn("dailyTargets gagal disimpan", e?.code || e?.message || e);
  }
  return state.data.dailyTarget;
}
async function insertDocIfAbsent(table, id, payload) {
  try {
    const { error } = await supabase
      .from(table)
      .insert({ id, data: deepCloneCompat(payload || {}) });
    if (error) {
      if (error.code === "23505" || /duplicate/i.test(error.message || ""))
        return false;
      throw error;
    }
    return true;
  } catch (e) {
    console.warn(`${table} insert dilewati`, e?.code || e?.message || e);
    return false;
  }
}
function notifyTargetAchievedOnce(summary, plan) {
  try {
    return fetch(ROCKY_ADMIN_NOTIFY_TARGET_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Notify-Secret": ROCKY_ADMIN_NOTIFY_SECRET,
      },
      body: JSON.stringify({
        secret: ROCKY_ADMIN_NOTIFY_SECRET,
        dateKey: summary.dateKey,
        targetAmount: summary.targetAmount,
        totalAmount: summary.totalAmount,
        bonusAmount: summary.bonusAmount,
        activeUsers: plan.activeUsers,
        rewardedUsers: plan.rewardedUsers,
      }),
    }).catch((e) => console.warn("Notif target gagal", e?.message || e));
  } catch (e) {
    console.warn("Notif target gagal", e?.message || e);
    return Promise.resolve(null);
  }
}
async function notifyStaffTargetBonus(row = {}, user = {}) {
  try {
    const username = key(row.user || row.username || user.username || "");
    const amount = Number(row.amount || 0);
    if (!username || amount <= 0) return null;
    const role = String(row.userRole || row.role || user.role || "staff");
    const res = await fetch(ROCKY_STAFF_NOTIFY_MANUAL_BONUS_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Notify-Secret": ROCKY_ADMIN_NOTIFY_SECRET,
      },
      body: JSON.stringify({
        secret: ROCKY_ADMIN_NOTIFY_SECRET,
        targetUsername: username,
        username,
        user: username,
        name: row.name || user.name || username,
        amount,
        note: row.note || "Bonus target omzet harian tercapai",
        action: "add",
        dateKey: String(row.dateKey || ""),
        monthKey: String(row.monthKey || ""),
        bonusId: String(row.id || row.docId || ""),
        type: "daily_target_bonus",
        source: "daily_target",
        role,
        userRole: role,
        actualRole: role,
        bonusGroup: "staff",
        isDaily: false,
        dailyMode: false,
        actualDaily: false,
        canReceiveStaffNotifications: true,
        notificationAudience: "staff",
        createdByName: "Target Otomatis Rocky",
      }),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || data?.ok === false) {
      console.warn("Notif bonus target staff gagal", data || res.status);
      return null;
    }
    return data || { ok: true };
  } catch (e) {
    console.warn("Notif bonus target staff gagal", e?.message || e);
    return null;
  }
}
function targetBonusPayload(summary, user, amount) {
  const username = targetUserKey(user);
  return {
    user: username,
    targetUsername: username,
    name: user.name || username,
    userRole: user.role || "staff",
    role: user.role || "staff",
    bonusGroup: "staff",
    amount,
    dateKey: summary.dateKey,
    monthKey: summary.dateKey.slice(0, 7),
    type: "daily_target_bonus",
    source: "daily_target",
    note: "Bonus target omzet harian tercapai",
    description: "Bonus otomatis karena target omzet harian gabungan tercapai",
    action: "add",
    ...trialRecordFlags(user),
    deleted: false,
    createdAt: serverTimestamp(),
    createdAtMs: Date.now(),
  };
}
async function ensureStaffTargetBonusNotification(
  bonusId,
  rewardId,
  row,
  user,
  options = {},
) {
  try {
    const force = options.force === true;
    const rewardSnap = await getDocFromServer(
      doc(db, TARGET_BONUS_REWARDS_TABLE, rewardId),
    ).catch(() => null);
    const reward = rewardSnap?.exists() ? rewardSnap.data() || {} : {};
    if (
      !force &&
      (reward.staffNotificationSent === true ||
        Number(reward.staffNotifiedAtMs || 0) > 0)
    )
      return false;

    if (!isTrialUser()) {
      const dedupId = "dedup_fcm_" + rewardId;
      const inserted = await insertDocIfAbsent(
        TARGET_NOTIFICATIONS_TABLE,
        dedupId,
        { type: "fcm_dedup" },
      );
      if (!inserted) return false;
    }

    const result = await notifyStaffTargetBonus(
      { id: bonusId, docId: bonusId, ...row },
      user,
    );
    if (!result) return false;
    await setDoc(
      doc(db, TARGET_BONUS_REWARDS_TABLE, rewardId),
      {
        staffNotificationSent: true,
        staffNotificationStatus: "sent",
        staffNotifiedAt: serverTimestamp(),
        staffNotifiedAtMs: Date.now(),
      },
      { merge: true },
    ).catch((e) =>
      console.warn(
        "target reward notif flag gagal",
        e?.code || e?.message || e,
      ),
    );
    return true;
  } catch (e) {
    console.warn("ensure notif bonus target gagal", e?.code || e?.message || e);
    return false;
  }
}
async function ensureDailyTargetBonusRows(summary, plan, amount) {
  const rewarded = [];
  if (Number(amount || 0) <= 0) return rewarded;
  for (const user of plan.users || []) {
    const username = targetUserKey(user);
    if (!username) continue;
    const bonusId = targetBonusDocId(summary.dateKey, username),
      rewardId = targetRewardDocId(summary.dateKey, username);
    const existingBonus = await getDocFromServer(
      doc(db, "manualBonuses", bonusId),
    ).catch(() => null);
    const existingData = existingBonus?.exists()
      ? existingBonus.data() || {}
      : null;
    const existingActive = !!existingData && !deleted(existingData);
    const payload = targetBonusPayload(summary, user, amount);
    if (!existingActive) {
      await setDoc(doc(db, "manualBonuses", bonusId), payload, {
        merge: false,
      });
      if (username === key(state.user?.username)) {
        state.data.manual = mergeRowsById(state.data.manual, [
          { id: bonusId, docId: bonusId, ...payload },
        ]).filter((b) => !deleted(b));
      }
    } else {
      const repair = {
        targetUsername: username,
        dateKey: summary.dateKey,
        monthKey: summary.dateKey.slice(0, 7),
        type: "daily_target_bonus",
        source: "daily_target",
        action: "add",
        deleted: false,
        amount,
      };
      await setDoc(doc(db, "manualBonuses", bonusId), repair, {
        merge: true,
      }).catch((e) =>
        console.warn("repair bonus target gagal", e?.code || e?.message || e),
      );
      if (username === key(state.user?.username)) {
        state.data.manual = mergeRowsById(state.data.manual, [
          { id: bonusId, docId: bonusId, ...existingData, ...repair },
        ]).filter((b) => !deleted(b));
      }
    }
    rewarded.push(username);
    const notified = await ensureStaffTargetBonusNotification(
      bonusId,
      rewardId,
      existingActive
        ? { ...existingData, ...payload, id: bonusId, docId: bonusId }
        : payload,
      user,
      { force: !existingActive },
    );
    await setDoc(
      doc(db, TARGET_BONUS_REWARDS_TABLE, rewardId),
      {
        id: rewardId,
        dateKey: summary.dateKey,
        user: username,
        targetUsername: username,
        amount,
        manualBonusId: bonusId,
        type: "daily_target_bonus",
        source: "daily_target",
        rewardedAt: serverTimestamp(),
        rewardedAtMs: Date.now(),
        ...(notified
          ? {
              staffNotificationSent: true,
              staffNotificationStatus: "sent",
              staffNotifiedAt: serverTimestamp(),
              staffNotifiedAtMs: Date.now(),
            }
          : {}),
      },
      { merge: true },
    ).catch((e) =>
      console.warn("targetBonusRewards gagal", e?.code || e?.message || e),
    );
  }
  return rewarded;
}
function mergeTargetRewardedUsers(...groups) {
  const set = new Set();
  groups.flat().forEach((u) => {
    const k = key(u);
    if (k) set.add(k);
  });
  return [...set];
}
function isTargetAutoBonusRow(row = {}) {
  return (
    String(row.source || "") === "daily_target" ||
    String(row.type || "") === "daily_target_bonus" ||
    String(row.id || row.docId || "").startsWith("targetbonus_") ||
    String(row.id || row.docId || "").startsWith("trial_targetbonus_")
  );
}
function isBonusWithdrawalRow(row = {}) {
  const type = String(row.type || row.bonusType || "").toLowerCase();
  const action = String(row.action || row.bonusAction || "").toLowerCase();
  const source = String(row.source || "").toLowerCase();
  return (
    type === BONUS_WITHDRAWAL_TYPE ||
    action === "withdraw" ||
    source === BONUS_WITHDRAWAL_TYPE ||
    String(row.id || row.docId || "").startsWith("bonuswd_")
  );
}
function bonusWithdrawalAmount(row = {}) {
  const raw = Number(row.withdrawalAmount ?? row.paidAmount ?? row.amount ?? 0);
  return Number.isFinite(raw) ? Math.abs(raw) : 0;
}
async function revokeDailyTargetBonuses(summary, plan, previous = {}) {
  const d = String(summary?.dateKey || todayKey()).slice(0, 10),
    nowMs = Date.now();
  const users = mergeTargetRewardedUsers(
    plan?.rewardedUsers || [],
    previous?.rewardedUsers || [],
    state.data.dailyTarget?.rewardedUsers || [],
    (plan?.users || []).map((u) => u?.username || u?.id),
  );
  for (const username of users) {
    const bonusId = targetBonusDocId(d, username),
      rewardId = targetRewardDocId(d, username);
    try {
      const snap = await getDocFromServer(
        doc(db, "manualBonuses", bonusId),
      ).catch(() => null);
      const row = snap?.exists()
        ? { id: bonusId, ...(snap.data() || {}) }
        : null;
      if (row && !deleted(row) && isTargetAutoBonusRow(row)) {
        await setDoc(
          doc(db, "manualBonuses", bonusId),
          {
            deleted: true,
            status: "deleted",
            deletedAt: serverTimestamp(),
            deletedAtMs: nowMs,
            deletedBy: "target_auto",
            deletedByName: "Target Otomatis Rocky",
            deleteReason: "Omzet turun di bawah target harian",
            updatedAt: serverTimestamp(),
            updatedAtMs: nowMs,
          },
          { merge: true },
        );
        state.data.manual = state.data.manual
          .map((b) =>
            String(b.id || b.docId) === bonusId
              ? { ...b, deleted: true, status: "deleted", deletedAtMs: nowMs }
              : b,
          )
          .filter((b) => !deleted(b));
      }
      await setDoc(
        doc(db, TARGET_BONUS_REWARDS_TABLE, rewardId),
        {
          deleted: true,
          resetAt: serverTimestamp(),
          resetAtMs: nowMs,
          resetBy: "target_auto",
          resetByName: "Target Otomatis Rocky",
          resetReason: "Omzet turun di bawah target harian",
          staffNotificationSent: false,
          staffNotificationStatus: "reset",
          staffNotifiedAtMs: 0,
          updatedAt: serverTimestamp(),
          updatedAtMs: nowMs,
        },
        { merge: true },
      ).catch(() => {});
    } catch (e) {
      console.warn(
        "rollback bonus target gagal",
        username,
        e?.code || e?.message || e,
      );
    }
  }
  await deleteDoc(
    doc(db, TARGET_NOTIFICATIONS_TABLE, targetNotificationDocId(d)),
  ).catch(() => {});
  state.data.targetNotification = null;
  await saveDailyTargetStatus({ bonusApplied: false, rewardedUsers: [] });
}
async function ensureStaffTargetBonusNotifications(summary, plan, amount) {
  if (Number(amount || 0) <= 0) return [];
  const sent = [];
  for (const user of plan.users || []) {
    const username = targetUserKey(user);
    if (!username) continue;
    const bonusId = targetBonusDocId(summary.dateKey, username),
      rewardId = targetRewardDocId(summary.dateKey, username);
    const fallback = targetBonusPayload(summary, user, amount);
    const existingBonus = await getDocFromServer(
      doc(db, "manualBonuses", bonusId),
    ).catch(() => null);
    const row = existingBonus?.exists()
      ? { ...fallback, ...(existingBonus.data() || {}) }
      : fallback;
    const ok = await ensureStaffTargetBonusNotification(
      bonusId,
      rewardId,
      row,
      user,
    );
    if (ok) sent.push(username);
  }
  return sent;
}
async function ensureTargetNotification(summary, plan) {
  const id = targetNotificationDocId(summary.dateKey),
    payload = {
      dateKey: summary.dateKey,
      type: "daily_target_reached",
      title: "Target omzet harian tercapai",
      message: `Target omzet harian sudah tercapai. Bonus target Rp ${rp(summary.bonusAmount)} otomatis masuk.`,
      targetAmount: summary.targetAmount,
      totalAmount: summary.totalAmount,
      bonusAmount: summary.bonusAmount,
      reachedAt: serverTimestamp(),
      reachedAtMs: Date.now(),
      read: false,
      createdAt: serverTimestamp(),
      createdAtMs: Date.now(),
    };
  const inserted = await insertDocIfAbsent(
    TARGET_NOTIFICATIONS_TABLE,
    id,
    payload,
  );
  if (inserted) state.data.targetNotification = { id, ...payload };
  if (inserted && !isTrialUser()) await notifyTargetAchievedOnce(summary, plan);
}
async function applyDailyTargetBonus() {
  if (dailyTargetApplying || !state.user) return;
  dailyTargetApplying = true;
  try {
    const summary = dailyTargetSummary();
    if (!summary.reached) {
      const plan = dailyTargetRewardPlan(summary.dateKey);
      const latest = await getDocFromServer(
        doc(db, DAILY_TARGETS_TABLE, targetDailyDocId(summary.dateKey)),
      ).catch(() => null);
      const latestData = latest?.exists()
        ? latest.data()
        : state.data.dailyTarget || {};
      await revokeDailyTargetBonuses(summary, plan, latestData);
      return;
    }
    const latest = await getDocFromServer(
      doc(db, DAILY_TARGETS_TABLE, targetDailyDocId(summary.dateKey)),
    ).catch(() => null);
    const latestData = latest?.exists()
      ? latest.data()
      : state.data.dailyTarget || {};
    if (latest?.exists())
      state.data.dailyTarget = { ...state.data.dailyTarget, ...latestData };
    const plan = dailyTargetRewardPlan(summary.dateKey),
      amount = Number(summary.bonusAmount || 0);
    if (latestData?.bonusApplied === true) {
      const rewarded = await ensureDailyTargetBonusRows(summary, plan, amount);
      await saveDailyTargetStatus({
        bonusApplied: true,
        rewardedUsers: mergeTargetRewardedUsers(
          latestData.rewardedUsers || [],
          rewarded,
        ),
      });
      return;
    }
    await saveDailyTargetStatus({});
    if (amount <= 0) {
      await saveDailyTargetStatus({
        activeUsers: plan.activeUsers,
        rewardedUsers: [],
        bonusApplied: false,
      });
      return;
    }
    const rewarded = await ensureDailyTargetBonusRows(summary, plan, amount);
    await saveDailyTargetStatus({
      activeUsers: plan.activeUsers,
      rewardedUsers: rewarded,
      bonusApplied: true,
    });
    await ensureTargetNotification(summary, {
      ...plan,
      rewardedUsers: rewarded,
    });
    notifyTargetReachedInApp();
    if (rewarded.includes(key(state.user?.username))) {
      render();
      notifyNewManualBonuses();
      notifyNewBonusWithdrawals();
    }
  } catch (e) {
    console.warn("bonus target harian gagal", e?.code || e?.message || e);
  } finally {
    dailyTargetApplying = false;
  }
}
function scheduleDailyTargetCheck() {
  clearTimeout(dailyTargetApplyTimer);
  syncDailyTargetState();
  dailyTargetApplyTimer = setTimeout(() => applyDailyTargetBonus(), 650);
}
function dailyTargetCard() {
  const s = syncDailyTargetState(),
    pct = Math.max(0, Math.min(100, s.progressPercent || 0)),
    pctText = (Math.round((s.progressPercent || 0) * 10) / 10).toLocaleString(
      "id-ID",
    ),
    reached = !!s.reached;
  return `<div class="daily-target-line ${reached ? "reached" : ""}"><div class="daily-target-progress"><span style="width:${pct}%"></span></div><span class="daily-target-percent">${pctText}%</span></div>`;
}
function trialModeCard() {
  if (!isTrialUser()) return "";
  return `<div class="card trial-mode-card"><div class="between"><div><div class="label">Mode Trial / Akun Dummy</div><div class="hint" style="margin-top:3px">Data percobaan tidak masuk laporan utama.</div></div><span class="pill amber">TRIAL</span></div></div>`;
}

function firstTxPartyKey() {
  return `${FIRST_TX_PARTY_SEEN}_${key(state.user?.username || "guest")}_${todayKey()}`;
}
function isFirstTxPartyDue() {
  if (!state.user) return false;
  try {
    if (localStorage.getItem(firstTxPartyKey()) === "1") return false;
  } catch (e) {}
  return todayTx().length === 0;
}
function markFirstTxPartySeen() {
  try {
    localStorage.setItem(firstTxPartyKey(), "1");
  } catch (e) {}
}
function closeFirstTxParty() {
  const wrap = document.querySelector(".first-tx-party");
  if (!wrap) return;
  wrap.classList.remove("show");
  setTimeout(() => wrap.remove(), 220);
}
function showFirstTxParty(amount, note) {
  markFirstTxPartySeen();
  try {
    if (navigator.vibrate) navigator.vibrate([70, 35, 90, 35, 120]);
  } catch (e) {}
  document.querySelectorAll(".first-tx-party").forEach((el) => el.remove());
  const wrap = document.createElement("div");
  wrap.className = "first-tx-party";
  const pieces = Array.from(
    { length: 30 },
    () =>
      `<i style="--x:${Math.round(Math.random() * 240 - 120)}px;--y:${Math.round(Math.random() * -180 - 45)}px;--r:${Math.round(Math.random() * 720 - 360)}deg;--d:${(Math.random() * 0.18).toFixed(2)}s"></i>`,
  ).join("");
  wrap.innerHTML = `<div class="first-tx-confetti">${pieces}</div><div class="first-tx-box"><div class="first-tx-emoji">🎉</div><div class="first-tx-title">Transaksi Pertama Hari Ini!</div><div class="first-tx-sub">الحمد لله</div><div class="first-tx-amount">Rp ${rp(amount)}</div><div class="first-tx-sub">${esc(note || "Transaksi")}</div><button class="first-tx-close" onclick="closeFirstTxParty()" type="button">Tutup</button></div>`;
  (document.querySelector(".app") || document.body).appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add("show"));
}

function closeManualBonusParty() {
  const wrap = document.querySelector(".manual-bonus-party");
  if (!wrap) return;
  wrap.classList.remove("show");
  setTimeout(() => wrap.remove(), 220);
}
function showManualBonusParty(amount, note, count = 1, options = {}) {
  document.querySelectorAll(".manual-bonus-party").forEach((el) => el.remove());
  const wrap = document.createElement("div");
  wrap.className = "manual-bonus-party";
  const pieces = Array.from(
    { length: 34 },
    () =>
      `<i style="--x:${Math.round(Math.random() * 250 - 125)}px;--y:${Math.round(Math.random() * -190 - 45)}px;--r:${Math.round(Math.random() * 720 - 360)}deg;--d:${(Math.random() * 0.2).toFixed(2)}s"></i>`,
  ).join("");
  const onlyAmount = options?.amountOnly === true;
  const noteText = manualBonusDisplayNote(note, "");
  const noteHtml = noteText
    ? `<div class="manual-bonus-note">${esc(noteText)}</div>`
    : "";
  wrap.innerHTML = onlyAmount
    ? `<div class="manual-bonus-confetti">${pieces}</div><div class="manual-bonus-box"><div class="manual-bonus-amount">Rp ${rp(amount)}</div><button class="manual-bonus-close" onclick="closeManualBonusParty()" type="button">Tutup</button></div>`
    : `<div class="manual-bonus-confetti">${pieces}</div><div class="manual-bonus-box"><div class="manual-bonus-emoji">🎁</div><div class="manual-bonus-title">BONUS DARI MIMIN</div><div class="manual-bonus-sub">الحمد لله</div><div class="manual-bonus-amount">Rp ${rp(amount)}</div>${noteHtml}<button class="manual-bonus-close" onclick="closeManualBonusParty()" type="button">Tutup</button></div>`;
  (document.querySelector(".app") || document.body).appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add("show"));
}

const SUCCESS_SOUND_SRC = "./success.mp3";
const BONUS_SOUND_SRC = "./notifkasi_bonus_masuk.mp3";
let successAudio = null;
let bonusAudio = null;
function primeSuccessSound() {
  try {
    if (!successAudio) {
      successAudio = new Audio(SUCCESS_SOUND_SRC);
      successAudio.preload = "auto";
      successAudio.volume = 0.9;
      successAudio.load();
    }
  } catch (e) {}
}
function playSuccessSound() {
  try {
    primeSuccessSound();
    if (!successAudio) return;
    successAudio.pause();
    successAudio.currentTime = 0;
    const p = successAudio.play();
    if (p && p.catch) p.catch(() => {});
  } catch (e) {}
}
function primeBonusSound() {
  try {
    if (!bonusAudio) {
      bonusAudio = new Audio(BONUS_SOUND_SRC);
      bonusAudio.preload = "auto";
      bonusAudio.volume = 1;
      bonusAudio.load();
    }
  } catch (e) {}
}
function playBonusSound() {
  try {
    primeBonusSound();
    if (!bonusAudio) return;
    bonusAudio.pause();
    bonusAudio.currentTime = 0;
    const p = bonusAudio.play();
    if (p && p.catch) p.catch(() => {});
  } catch (e) {}
}
function primeAppSounds() {
  primeSuccessSound();
  primeBonusSound();
}
function onlyDigits(v) {
  return String(v || "").replace(/[^0-9]/g, "");
}
function formatRupiahInput(el) {
  const n = onlyDigits(el.value);
  el.value = n ? "Rp " + rp(Number(n)) : "";
}
function modal(title, body, actions = "", variant = "") {
  closeModal(true); // bersihkan modal lama dulu supaya popup transaksi tidak dobel
  const r = $("modal");
  const variantText = String(variant || "").trim();
  const cls = variantText ? ` ${variantText}` : "";
  const isTxModal = variantText.includes("tx-modal");
  const isPaymentPicker = variantText.includes("payment-picker-modal");
  const wrap = `modal-wrap show${isTxModal ? " tx-backdrop" : ""}${isPaymentPicker ? " payment-picker-wrap" : ""}`;
  if (!r) return;
  r.removeAttribute("style");
  r.innerHTML = `<div class="modal${cls}" role="dialog" aria-modal="true"><div class="modal-head"><div><div class="modal-title">${esc(title)}</div></div><button type="button" class="icon" onpointerdown="closeModal(true);event.preventDefault()" ontouchstart="closeModal(true);event.preventDefault()" onclick="closeModal(true)">×</button></div>${body}${actions ? `<div class="modal-actions">${actions}</div>` : ""}</div>`;
  r.className = wrap;
}

function closeModal(force = false) {
  // Cleanup suggest floater
  try {
    const floater = document.getElementById("txProductSuggestFloater");
    if (floater) { floater.style.display = "none"; floater.innerHTML = ""; }
    txProductSuggestItems = [];
    txProductSuggestActiveIndex = -1;
    txProductSuggestTouching = false;
  } catch(e) {}
  try {
    if (typeof stopPrayerAyat === "function") stopPrayerAyat(false);
  } catch (e) {}
  try {
    if (
      document.activeElement &&
      typeof document.activeElement.blur === "function"
    )
      document.activeElement.blur();
  } catch (e) {}
  const main = $("modal");
  if (main) {
    main.className = "modal-wrap";
    main.innerHTML = "";
    main.style.cssText = "";
  }
  document.querySelectorAll(".modal-wrap").forEach((el) => {
    if (el !== main) el.remove();
  });
  document.querySelectorAll('.modal[role="dialog"]').forEach((el) => {
    if (!main || !main.contains(el)) el.remove();
  });
}
const THEME_KEY = "rocky_staff_theme";
function normalizeTheme(t) {
  return ["neo", "neobrutalism", "brutal", "dark"].includes(
    String(t || "").toLowerCase(),
  )
    ? "neo"
    : "light";
}
function getTheme() {
  return normalizeTheme(localStorage.getItem(THEME_KEY) || "light");
}
function isNeoTheme() {
  return getTheme() === "neo";
}
function setTheme(t) {
  const theme = normalizeTheme(t);
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(THEME_KEY, theme);
}
function toggleTheme() {
  setTheme(isNeoTheme() ? "light" : "neo");
  render();
}
function pendingKey() {
  return PENDING_KEY + "_" + key(state.user?.username || "guest");
}
function getPending() {
  try {
    return JSON.parse(localStorage.getItem(pendingKey()) || "[]");
  } catch (e) {
    return [];
  }
}
function setPending(list) {
  localStorage.setItem(pendingKey(), JSON.stringify(list || []));
}
function pendingForUser() {
  const u = key(state.user?.username);
  return getPending().filter((x) => !u || key(x.user) === u);
}
function addPending(item) {
  const list = getPending().filter((x) => x.id !== item.id);
  list.push({
    ...item,
    tries: Number(item.tries || 0),
    lastTryMs: item.lastTryMs || 0,
  });
  setPending(list);
}
function removePending(id) {
  setPending(getPending().filter((x) => x.id !== id));
}
function isPermissionError(e) {
  return String(e?.code || e?.message || "")
    .toLowerCase()
    .includes("permission");
}
function localTxFromPending(p) {
  return { id: p.id, ...(p.payload || {}), pending: true };
}
function localAttFromPending(p) {
  return { id: p.id, ...(p.payload || {}), pending: true };
}
function localUnlockFromPending(p) {
  return { id: p.id, ...(p.payload || {}), pending: true };
}
function applyPendingToState() {
  const p = pendingForUser();
  p.forEach((x) => {
    if (
      x.type === "tx_add" &&
      !state.data.tx.some((t) => String(t.id) === String(x.id))
    )
      state.data.tx.unshift(localTxFromPending(x));
    if (
      x.type === "att_add" &&
      !state.data.att.some((a) => String(a.id) === String(x.id))
    )
      state.data.att.unshift(localAttFromPending(x));
    if (
      x.type === "feature_unlock_request" &&
      !state.data.unlockRequests.some((t) => String(t.id) === String(x.id))
    )
      state.data.unlockRequests.unshift(localUnlockFromPending(x));
  });
  state.data.att = dedupeAttendanceRows(state.data.att);
  state.data.unlockRequests = sortDesc(state.data.unlockRequests || []);
}
function syncTimeText() {
  if (!state.lastSyncMs) return "Belum sync";
  const diff = Math.max(0, Math.round((Date.now() - state.lastSyncMs) / 1000));
  if (diff < 60) return "baru saja";
  if (diff < 3600) return `${Math.floor(diff / 60)} menit lalu`;
  return timeID(state.lastSyncMs);
}
function syncBar() {
  const pc = pendingForUser().length,
    cls = pc ? "syncbar sync-pending" : "syncbar";
  const msg = pc
    ? `<b>${pc} data belum terkirim</b><span> akan dicoba otomatis</span>`
    : `<span>Sync terakhir: <b>${syncTimeText()}</b></span>`;
  const err = state.syncError
    ? `<div class="hint" style="color:var(--red);margin-top:2px">${esc(state.syncError)}</div>`
    : "";
  return `<div class="${cls}"><div>${msg}${err}</div><button class="btn sm" onclick="retrySync()">Sync</button></div>`;
}
function syncHeroLine() {
  const pc = pendingForUser().length;
  const msg = pc
    ? `<b>${pc} data belum terkirim</b><span> · dicoba otomatis</span>`
    : `<span>Sync terakhir: <b>${syncTimeText()}</b></span>`;
  const err = state.syncError
    ? `<div class="hero-sync-error">${esc(state.syncError)}</div>`
    : "";
  return `<div class="hero-sync"><div>${msg}${err}</div><button class="hero-sync-btn" onclick="showForceUpdateConfirm()" aria-label="Update App">Click For Update</button></div>`;
}
function top(title, sub) {
  const icon = isNeoTheme() ? "M" : "NB",
    back = canAppBack()
      ? '<button class="top-back-btn" onclick="appBack()" aria-label="Kembali">←</button>'
      : "";
  const syncBtn = `<button class="sync-header-btn" id="syncHeaderBtn" aria-label="Sync data"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M18 2v4h-4"/><path d="M6 22v-4h4"/></svg><span class="longpress-ring"></span></button>`;
  return `<div class="top">${back}<div class="brand"><div class="title">${esc(title)}</div><div class="sub">${esc(sub || state.user?.name || "Staff")}</div></div><div class="row"><a class="btn sm member" href="${MEMBER_URL}" target="_blank" rel="noopener">Member</a>${headerTxStatus()}${syncBtn}<button class="btn sm" onclick="toggleTheme()">${icon}</button><button class="btn sm danger" onclick="logout()">Keluar</button></div></div>`;
}
function headerGuideNoteText() {
  const note = String(state.data.headerGuideNote || "").trim();
  return note || DEFAULT_HEADER_GUIDE_NOTE;
}
function staffDailyHomeNoteData() {
  const raw = state.data.staffDailyNote || {};
  const enabled = raw.enabled !== false;
  const note = String(raw.note || "").trim();
  return {
    enabled,
    note: note || DEFAULT_STAFF_DAILY_NOTE,
    updatedAtMs: Number(raw.updatedAtMs || 0),
    updatedByName: raw.updatedByName || raw.updatedBy || "",
  };
}
function staffDailyNoteRoleLabel() {
  return isDaily() ? "Karyawan Harian" : "Staff";
}
function staffDailyNoteCard() {
  if (!state.user) return "";
  const data = staffDailyHomeNoteData();
  if (!data.enabled || !data.note) return "";
  const updated = data.updatedAtMs
    ? `Update ${dateID(todayKey(new Date(data.updatedAtMs)))} · ${timeID(data.updatedAtMs)}`
    : "Catatan dari admin";
  const by = data.updatedAtMs ? " · Pesan dari Markas" : "";
  return `<div class="card staff-home-note-card"><div class="staff-home-note-main"><span class="staff-home-note-ico">📌</span><div style="min-width:0;flex:1"><div class="staff-home-note-title">PENTING</div><div class="staff-home-note-text">${linkText(data.note)}</div><div class="staff-home-note-meta">${esc(updated + by)}</div></div></div></div>`;
}
function normalizeCashDrawerStatus(value, diff = 0) {
  const raw = String(value || "").toLowerCase();
  if (["minus", "kurang"].includes(raw)) return "minus";
  if (["lebih", "plus"].includes(raw)) return "lebih";
  if (["pas", "sama"].includes(raw)) return "pas";
  const n = Number(diff || 0);
  if (n < 0) return "minus";
  if (n > 0) return "lebih";
  return "pas";
}
function normalizeCashDrawerRow(r = {}) {
  const diff = Number(r.difference_amount ?? r.differenceAmount ?? 0);
  return {
    id: r.id || "",
    dateKey: String(r.date_key || r.dateKey || todayKey()).slice(0, 10),
    status: normalizeCashDrawerStatus(r.status, diff),
    baseAmount: Number(r.base_amount ?? r.baseAmount ?? 0),
    actualAmount: Number(r.actual_amount ?? r.actualAmount ?? 0),
    differenceAmount: diff,
    adjustmentAmount: Number(r.adjustment_amount ?? r.adjustmentAmount ?? 0),
    createdAt: r.created_at || r.createdAt || "",
  };
}
async function loadDrawerWithdrawals(dateKey = todayKey()) {
  try {
    const snap = await getDocs(
      query(
        collection(db, "drawer_withdrawals"),
        where("dateKey", "==", dateKey)
      )
    );
    state.data.drawerWithdrawals = snap.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    })).sort((a, b) => (a.createdAtMs || 0) - (b.createdAtMs || 0));
  } catch (e) {
    console.warn("Gagal memuat tarikan laci", e);
    state.data.drawerWithdrawals = [];
  }
  return state.data.drawerWithdrawals;
}
async function loadCashDrawerStatus(dateKey = todayKey()) {
  try {
    const { data, error } = await cashDrawerClient
      .from(CASH_DRAWER_TABLE)
      .select(
        "id,date_key,status,base_amount,actual_amount,difference_amount,adjustment_amount,created_at",
      )
      .eq("owner_id", KAS_PRIBADI_OWNER_ID)
      .eq("date_key", dateKey)
      .order("created_at", { ascending: false })
      .limit(1);
    if (error) throw error;
    state.data.cashDrawer =
      data && data[0] ? normalizeCashDrawerRow(data[0]) : null;
  } catch (e) {
    console.warn("Status cash fisik gagal dimuat", e?.message || e);
    state.data.cashDrawer = null;
  }
  return state.data.cashDrawer;
}
function cashDrawerStaffMessage(row = state.data.cashDrawer) {
  if (!row) return "Belum ada cek cash fisik hari ini.";
  const amount = Math.abs(Number(row.differenceAmount || 0));
  if (row.status === "minus") return `Cash fisik MINUS Rp ${rp(amount)}`;
  if (row.status === "lebih") return `Cash fisik LEBIH Rp ${rp(amount)}`;
  return "Cash fisik PAS. Tidak ada selisih.";
}
function cashDrawerStatusCard() {
  const row = state.data.cashDrawer,
    status = row ? row.status : "empty";
  const cardStatus = row ? status : "blank";
  const statusLabel = row
    ? status === "minus"
      ? "MINUS"
      : status === "lebih"
        ? "LEBIH"
        : "PAS"
    : "BELUM CEK";
  const message = cashDrawerStaffMessage(row);
  return `<div class="cash-drawer-staff-card ${cardStatus}"><div class="cash-drawer-staff-copy"><span class="cash-drawer-staff-label">Cash Fisik Hari Ini</span><b class="cash-drawer-staff-title">${esc(message)}</b></div><span class="cash-drawer-staff-badge">${esc(statusLabel)}</span></div>`;
}
function headerGuideItems() {
  const themeIcon = isNeoTheme() ? "M" : "NB";
  const lock = missedAttendanceLockForDate();
  const free = isAttendanceFreeUser();
  const locked = !!lock || isClosedToday() || (!free && !todayAtt());
  const lockIcon = locked ? "🔒" : "🔓";
  const lockText = lock
    ? `Transaksi terkunci karena tidak ada absen ${dateID(lock.missedDate)}.`
    : locked
      ? "Transaksi terkunci karena belum absen atau sudah closing."
      : isRismaSpecialUser()
        ? "Risma bebas absen dan siap transaksi."
        : "Transaksi terbuka dan siap digunakan.";
  return `<div class="header-guide-grid"><div class="header-guide-item"><span class="header-guide-ico">M</span><div><div class="header-guide-title">Member</div><div class="header-guide-desc">Membuka halaman kode khusus member.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${lockIcon}</span><div><div class="header-guide-title">Status Transaksi</div><div class="header-guide-desc">${lockText}</div></div></div><div class="header-guide-item"><span class="header-guide-ico">↻</span><div><div class="header-guide-title">Refresh</div><div class="header-guide-desc">Muat ulang data, sync pending, dan update bonus terbaru.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">↯</span><div><div class="header-guide-title">↯ Update</div><div class="header-guide-desc">Hapus cache browser & muat ulang dari server. Pakai ini kalau ada update dari GitHub tapi tampilan masih lama.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${themeIcon}</span><div><div class="header-guide-title">Tema</div><div class="header-guide-desc">Ganti tampilan Majoo atau Neo Brutalism.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">⏻</span><div><div class="header-guide-title">Keluar</div><div class="header-guide-desc">Logout dari akun staff di perangkat ini.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">!</span><div><div class="header-guide-title">Catatan Refresh</div><div class="header-guide-desc">Pakai refresh saat data belum masuk, bonus belum berubah, atau transaksi gagal.</div></div></div></div>`;
}
function openHeaderGuideDetail() {
  modal(
    "Panduan Icon Header",
    `<div class="header-guide-modal-note">“${esc(headerGuideNoteText())}”</div>${headerGuideItems()}`,
    `<button class="btn primary" onclick="closeModal()">Tutup</button>`,
  );
}
function headerIconGuide() {
  return "";
}
function headerTopIcon(name) {
  const icons = {
    back: '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>',
    member:
      '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 10h4"/><path d="M7 14h7"/><path d="M16.5 10.5h.01"/></svg>',
    lock: '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><path d="M12 15v2"/></svg>',
    unlock:
      '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 7.5-1.9"/><path d="M12 15v2"/></svg>',
    refresh:
      '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M18 2v4h-4"/><path d="M6 22v-4h4"/></svg>',
    sun: '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.9 4.9 1.4 1.4"/><path d="m17.7 17.7 1.4 1.4"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m4.9 19.1 1.4-1.4"/><path d="m17.7 6.3 1.4-1.4"/></svg>',
    moon: '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M20 14.5A7.5 7.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z"/></svg>',
    neo: '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 16l3-8 2 8 3-8"/><path d="M7 12h10"/></svg>',
    logout:
      '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 19V5a2 2 0 0 0-2-2h-6"/><path d="M13 21h6a2 2 0 0 0 2-2"/></svg>',
    github:
      '<svg class="top-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2C6.48 2 2 6.48 2 12c0 4.42 2.87 8.17 6.84 9.5.5.09.66-.22.66-.48v-1.7c-2.78.6-3.37-1.34-3.37-1.34-.46-1.16-1.11-1.47-1.11-1.47-.91-.62.07-.61.07-.61 1 .07 1.53 1.03 1.53 1.03.89 1.52 2.34 1.08 2.91.83.09-.65.35-1.08.63-1.33-2.22-.25-4.55-1.11-4.55-4.94 0-1.09.39-1.98 1.03-2.68-.1-.25-.45-1.27.1-2.64 0 0 .84-.27 2.75 1.02A9.58 9.58 0 0 1 12 6.8c.85.004 1.7.115 2.5.337 1.91-1.29 2.75-1.02 2.75-1.02.55 1.37.2 2.39.1 2.64.64.7 1.03 1.59 1.03 2.68 0 3.84-2.34 4.68-4.57 4.93.36.31.68.92.68 1.85v2.74c0 .27.16.58.67.48A10.01 10.01 0 0 0 22 12c0-5.52-4.48-10-10-10Z"/></svg>',
  };
  return icons[name] || "";
}
function headerTopAction(label, iconName, attrs = "", extraClass = "") {
  return `<button type="button" class="btn sm top-icon-btn ${extraClass}" ${attrs} aria-label="${esc(label)}" title="${esc(label)}">${headerTopIcon(iconName)}</button>`;
}
function headerTopLink(label, iconName, href, extraClass = "") {
  return `<a class="btn sm top-icon-btn ${extraClass}" href="${esc(href)}" target="_blank" rel="noopener" aria-label="${esc(label)}" title="${esc(label)}">${headerTopIcon(iconName)}</a>`;
}
headerTxStatus = function () {
  if (!state.user) return "";
  const free = isAttendanceFreeUser();
  const locked = isTrialUser()
    ? false
    : !!missedAttendanceLockForDate() ||
      isClosedToday() ||
      (!free && !todayAtt());
  const label = locked ? "Terkunci" : "Terbuka";
  return `<span class="trx-head-status ${locked ? "locked" : "open"}" aria-label="Status transaksi: ${esc(label)}" title="Status transaksi: ${esc(label)}"><span class="lock-ico">${headerTopIcon(locked ? "lock" : "unlock")}</span><span class="trx-head-label">${esc(label)}</span></span>`;
};
top = function (title, sub) {
  const neo = isNeoTheme();
  const back = canAppBack()
    ? `<button class="top-back-btn" onclick="appBack()" aria-label="Kembali" title="Kembali">${headerTopIcon("back")}</button>`
    : "";
  return `<div class="top">${back}<div class="brand"><div class="title">${esc(title)}</div><div class="sub">${esc(sub || state.user?.name || "Staff")}</div></div><div class="row top-actions">${headerTopLink("Member", "member", MEMBER_URL, "member top-member")}${headerTxStatus()}${headerTopAction(neo ? "Tema Majoo" : "Tema Neo", neo ? "sun" : "neo", 'onclick="toggleTheme()"', "top-theme")}${headerTopAction("Keluar", "logout", 'onclick="logout()"', "danger top-logout")}</div></div>`;
};
headerGuideItems = function () {
  const neo = isNeoTheme();
  const lock = missedAttendanceLockForDate();
  const free = isAttendanceFreeUser();
  const locked = !!lock || isClosedToday() || (!free && !todayAtt());
  const lockText = lock
    ? `Transaksi terkunci karena tidak ada absen ${dateID(lock.missedDate)}.`
    : locked
      ? "Transaksi terkunci karena belum absen atau sudah closing."
      : isRismaSpecialUser()
        ? "Risma bebas absen dan siap transaksi."
        : "Transaksi terbuka dan siap digunakan.";
  return `<div class="header-guide-grid"><div class="header-guide-item"><span class="header-guide-ico">${headerTopIcon("member")}</span><div><div class="header-guide-title">Member</div><div class="header-guide-desc">Membuka halaman kode khusus member.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${headerTopIcon(locked ? "lock" : "unlock")}</span><div><div class="header-guide-title">Status Transaksi</div><div class="header-guide-desc">${lockText}</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${headerTopIcon("refresh")}</span><div><div class="header-guide-title">Refresh</div><div class="header-guide-desc">Muat ulang data, sync pending, dan update bonus terbaru.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${headerTopIcon(neo ? "sun" : "neo")}</span><div><div class="header-guide-title">Tema</div><div class="header-guide-desc">Ganti tampilan Majoo atau Neo Brutalism.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${headerTopIcon("logout")}</span><div><div class="header-guide-title">Keluar</div><div class="header-guide-desc">Logout dari akun staff di perangkat ini.</div></div></div><div class="header-guide-item"><span class="header-guide-ico">${headerTopIcon("refresh")}</span><div><div class="header-guide-title">Catatan Refresh</div><div class="header-guide-desc">Pakai refresh saat data belum masuk, bonus belum berubah, atau transaksi gagal.</div></div></div></div>`;
};
function showStaffAbsenFab() {
  return (
    !!state.user &&
    state.page === "home" &&
    !isAttendanceFreeUser() &&
    !todayAtt() &&
    !isClosedToday() &&
    !missedAttendanceLockForDate()
  );
}
function nav() {
  const n = $("nav"),
    f = $("fab"),
    af = $("absenFab");
  if (!state.user) {
    n.style.display = "none";
    f.style.display = "none";
    if (af) af.style.display = "none";
    return;
  }
  n.style.display = "flex";
  f.style.display = state.page === "home" ? "block" : "none";
  if (af) af.style.display = showStaffAbsenFab() ? "flex" : "none";
  document
    .querySelectorAll(".nav button")
    .forEach((b) => b.classList.remove("active"));
  $(`nav-${state.page}`)?.classList.add("active");
}
function renderLogin() {
  nav();
  page.innerHTML = `<div class="login"><div class="login-card"><div class="hero" style="text-align:center"><div class="big">ROCKY HIJAB</div><div class="sub">Koleksi Terbaik Untuk Muslimah Hebat</div></div><div class="card" style="margin-top:10px"><div class="field"><div class="label">Username Staff</div><input id="lu" autocomplete="username" placeholder="username"></div><div class="field"><div class="label">PIN</div><input id="lp" type="password" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" placeholder="PIN"></div><button class="btn primary block" onclick="login()">Masuk</button><div class="hint" style="margin-top:8px;text-align:center">Login Menggunakan Username Masing-Masing</div></div></div></div>`;
}
let androidStaffSessionSignature = "";
function syncAndroidStaffSession() {
  if (!state.user) return;
  try {
    const username = key(state.user.username),
      actualRole = String(state.user.role || "staff"),
      dailyMode = isDaily();
    const staffName = String(state.user.name || state.user.username || "");
    const payload = {
      username,
      user: username,
      staff: username,
      targetUsername: username,
      name: staffName,
      role: actualRole,
      userRole: actualRole,
      actualRole,
      bonusGroup: dailyMode ? "harian" : "staff",
      daily: dailyMode,
      isDaily: dailyMode,
      actualDaily: dailyMode,
      dailyMode,
      mode: dailyMode ? "harian" : "staff",
      notificationAudience: "staff",
      canReceiveStaffNotifications: true,
    };
    const signature = JSON.stringify(payload);
    if (signature === androidStaffSessionSignature) return;
    androidStaffSessionSignature = signature;
    const bridges = [window.AndroidStaff, window.Android].filter(Boolean),
      seen = [];
    bridges.forEach((bridge) => {
      if (seen.includes(bridge)) return;
      seen.push(bridge);
      if (typeof bridge.setStaffSession === "function")
        bridge.setStaffSession(signature);
      if (typeof bridge.registerStaffSession === "function")
        bridge.registerStaffSession(signature);
      if (typeof bridge.setStaffUser === "function") {
        try {
          bridge.setStaffUser(username, staffName, actualRole);
        } catch (e) {
          try {
            bridge.setStaffUser(username);
          } catch (err) {}
        }
      }
    });
  } catch (e) {}
}
function clearAndroidStaffSession() {
  androidStaffSessionSignature = "";
  try {
    const bridges = [window.AndroidStaff, window.Android].filter(Boolean),
      seen = [];
    bridges.forEach((bridge) => {
      if (seen.includes(bridge)) return;
      seen.push(bridge);
      if (typeof bridge.clearStaffSession === "function")
        bridge.clearStaffSession();
      if (typeof bridge.clearStaffUser === "function") bridge.clearStaffUser();
    });
  } catch (e) {}
}
function renderNow() {
  if (!state.user) return renderLogin();
  syncAndroidStaffSession();
  nav();
  if (state.page === "history") return history();
  if (state.page === "unlock") return renderUnlockPage();
  return home();
}
let renderFrame = 0;
function render() {
  if (renderFrame) return;
  const schedule = window.requestAnimationFrame || ((fn) => setTimeout(fn, 16));
  renderFrame = schedule(() => {
    renderFrame = 0;
    renderNow();
  });
}
async function getQueryDocs(makePrimary, makeFallback) {
  try {
    return await getDocs(makePrimary());
  } catch (e) {
    console.warn("primary query fallback", e?.code || e);
    return await getDocs(makeFallback());
  }
}
function clearStaffRealtime() {
  staffRealtimeUnsubs.forEach((fn) => {
    try {
      if (typeof fn === "function") fn();
    } catch (e) {
      console.warn("unsub realtime gagal", e);
    }
  });
  staffRealtimeUnsubs = [];
  staffRealtimeStartedFor = "";
}
function replaceScopedRows(listName, rows, matchFn) {
  const keep = (state.data[listName] || []).filter((x) => !matchFn(x));
  state.data[listName] = sortDesc([...keep, ...(rows || [])]);
}
function mergeRowsById(...lists) {
  const map = new Map();
  lists.flat().forEach((x) => {
    if (x && x.id)
      map.set(String(x.id), { ...(map.get(String(x.id)) || {}), ...x });
  });
  return sortDesc([...map.values()]);
}
function mergeScopedRows(listName, rows) {
  const map = new Map();
  (state.data[listName] || []).forEach((x) => {
    if (x && x.id) map.set(String(x.id), x);
  });
  (rows || []).forEach((x) => {
    if (x && x.id)
      map.set(String(x.id), { ...(map.get(String(x.id)) || {}), ...x });
  });
  state.data[listName] = sortDesc([...map.values()]);
}
function handleRealtimeError(label, err) {
  console.warn(label + " realtime gagal", err?.code || err?.message || err);
  if (label === "Ops Access" || label === "User") return;
  state.syncError =
    label + " realtime gagal. Pakai tombol refresh jika data belum masuk.";
  render();
}
function startStaffRealtime() {
  if (!state.user) return;
  const u = key(state.user.username),
    d = todayKey(),
    realtimeKey = u + "_" + d;
  if (staffRealtimeStartedFor === realtimeKey && staffRealtimeUnsubs.length)
    return;
  clearStaffRealtime();
  staffRealtimeStartedFor = realtimeKey;

  const txQ = query(
    collection(db, "transactions"),
    where("user", "==", u),
    where("dateKey", "==", d),
    limit(LIMITS.txToday),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      txQ,
      (snap) => {
        const rows = sortDesc(
          snap.docs.map((x) => ({ id: x.id, ...x.data() })),
        );
        // Jangan hapus riwayat lokal hanya karena polling Supabase kebetulan membawa hasil parsial.
        // Server tetap jadi sumber update: row dengan id sama akan dioverwrite, row deleted akan tersaring oleh liveTx().
        mergeScopedRows("tx", rows);
        applyPendingToState();
        state.lastSyncMs = Date.now();
        state.syncError = "";
        render();
      },
      (err) => handleRealtimeError("Transaksi hari ini", err),
    ),
  );

  const attQ = query(
    collection(db, "attendance"),
    where("user", "==", u),
    where("dateKey", "==", d),
    limit(10),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      attQ,
      (snap) => {
        const rows = snap.docs.map((x) => ({ id: x.id, ...x.data() }));
        replaceScopedRows(
          "att",
          rows,
          (t) => key(t.user) === u && attDate(t) === d,
        );
        state.data.att = dedupeAttendanceRows(state.data.att);
        render();
      },
      (err) => handleRealtimeError("Absen hari ini", err),
    ),
  );

  const manualQ = query(
    collection(db, "manualBonuses"),
    where("user", "==", u),
    where("dateKey", "==", d),
    limit(LIMITS.manualToday),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      manualQ,
      (snap) => {
        const rows = sortDesc(
          snap.docs
            .map((x) => ({ ...(x.data() || {}), id: x.id, docId: x.id }))
            .filter((b) => !deleted(b)),
        );
        replaceScopedRows(
          "manual",
          rows,
          (t) => key(t.user) === u && manualBonusDate(t) === d,
        );
        render();
        notifyNewManualBonuses();
        notifyNewBonusWithdrawals();
      },
      (err) => handleRealtimeError("Bonus manual hari ini", err),
    ),
  );

  const prevD = previousDateKey(d);
  if (prevD !== d) {
    const prevAttQ = query(
      collection(db, "attendance"),
      where("user", "==", u),
      where("dateKey", "==", prevD),
      limit(10),
    );
    staffRealtimeUnsubs.push(
      onSnapshot(
        prevAttQ,
        (snap) => {
          const rows = snap.docs.map((x) => ({ id: x.id, ...x.data() }));
          replaceScopedRows(
            "att",
            rows,
            (t) => key(t.user) === u && attDate(t) === prevD,
          );
          state.data.att = dedupeAttendanceRows(state.data.att);
          render();
        },
        (err) => handleRealtimeError("Absen kemarin", err),
      ),
    );
  }

  const unlockQ = query(
    collection(db, STAFF_UNLOCK_TABLE),
    where("requestKind", "==", "unlock"),
    where("user", "==", u),
    limit(LIMITS.unlockRequests),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      unlockQ,
      (snap) => {
        const rows = sortDesc(
          snap.docs
            .map((x) => ({ ...(x.data() || {}), id: x.id, docId: x.id }))
            .filter((r) => isFeatureUnlockRequest(r) && !deleted(r)),
        );
        replaceScopedRows(
          "unlockRequests",
          rows,
          (t) => isFeatureUnlockRequest(t) && key(t.user) === u,
        );
        render();
      },
      (err) => handleRealtimeError("Buka fitur", err),
    ),
  );

  const closingQ = query(
    collection(db, "closings"),
    where("dateKey", "==", d),
    limit(LIMITS.closingsToday),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      closingQ,
      (snap) => {
        const rows = snap.docs
          .map((x) => ({ id: x.id, ...x.data() }))
          .filter(
            (c) => c.id !== "__bonus_settings" && c.type !== "bonus_settings",
          );
        replaceScopedRows(
          "closings",
          rows,
          (t) => String(t.dateKey || "") === d,
        );
        render();
      },
      (err) => handleRealtimeError("Closing hari ini", err),
    ),
  );

  const targetTxQ = query(
    collection(db, "transactions"),
    where("dateKey", "==", d),
    limit(LIMITS.targetTxToday),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      targetTxQ,
      (snap) => {
        state.data.targetTx = sortDesc(
          snap.docs.map((x) => ({ id: x.id, ...x.data() })),
        );
        syncDailyTargetState();
        render();
        notifyTargetReachedInApp();
        scheduleDailyTargetCheck();
      },
      (err) =>
        console.warn(
          "Target omzet transaksi realtime gagal",
          err?.code || err?.message || err,
        ),
    ),
  );

  const targetAttQ = query(
    collection(db, "attendance"),
    where("dateKey", "==", d),
    limit(LIMITS.targetAttToday),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      targetAttQ,
      (snap) => {
        state.data.targetAtt = dedupeAttendanceRows(
          snap.docs.map((x) => ({ id: x.id, ...x.data() })),
        );
        syncDailyTargetState();
        render();
        notifyTargetReachedInApp();
        scheduleDailyTargetCheck();
      },
      (err) =>
        console.warn(
          "Target omzet absen realtime gagal",
          err?.code || err?.message || err,
        ),
    ),
  );

  const targetUsersQ = query(
    collection(db, "users"),
    limit(LIMITS.targetUsers),
  );
  staffRealtimeUnsubs.push(
    onSnapshot(
      targetUsersQ,
      (snap) => {
        state.data.targetUsers = snap.docs.map((x) => ({
          id: x.id,
          username: key((x.data() || {}).username || x.id),
          ...x.data(),
        }));
        syncDailyTargetState();
        render();
        notifyTargetReachedInApp();
        scheduleDailyTargetCheck();
      },
      (err) =>
        console.warn(
          "Target omzet user realtime gagal",
          err?.code || err?.message || err,
        ),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, DAILY_TARGETS_TABLE, targetDailyDocId(d)),
      (snap) => {
        if (snap.exists()) syncDailyTargetState(snap.data() || {});
        render();
        notifyTargetReachedInApp();
      },
      (err) =>
        console.warn(
          "Status target harian realtime gagal",
          err?.code || err?.message || err,
        ),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, TARGET_NOTIFICATIONS_TABLE, targetNotificationDocId(d)),
      (snap) => {
        state.data.targetNotification = snap.exists()
          ? { id: snap.id, ...(snap.data() || {}) }
          : null;
        notifyTargetReachedInApp();
        render();
      },
      (err) =>
        console.warn(
          "Notifikasi target harian realtime gagal",
          err?.code || err?.message || err,
        ),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      query(collection(db, TARGET_SETTINGS_TABLE), limit(1000)),
      (snap) => {
        const rows = snap.docs.map((x) => ({ id: x.id, ...x.data() }));
        const picked = pickDailyTargetSettings(rows, d);
        if (picked) state.data.targetSettings = picked;
        syncDailyTargetState();
        render();
        scheduleDailyTargetCheck();
      },
      (err) =>
        console.warn(
          "Setting target harian realtime gagal",
          err?.code || err?.message || err,
        ),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, "closings", "__bonus_settings"),
      (snap) => {
        state.data.bonus = snap.exists()
          ? normalizeBonusSettings(snap.data())
          : normalizeBonusSettings(DEFAULT_BONUS);
        render();
      },
      (err) => handleRealtimeError("Setting bonus", err),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, "closings", HEADER_GUIDE_NOTE_DOC_ID),
      (snap) => {
        state.data.headerGuideNote =
          snap && snap.exists()
            ? String((snap.data() || {}).note || DEFAULT_HEADER_GUIDE_NOTE)
            : DEFAULT_HEADER_GUIDE_NOTE;
        render();
      },
      (err) => handleRealtimeError("Catatan panduan", err),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, "closings", STAFF_DAILY_NOTE_DOC_ID),
      (snap) => {
        state.data.staffDailyNote =
          snap && snap.exists()
            ? {
                note: DEFAULT_STAFF_DAILY_NOTE,
                enabled: true,
                ...(snap.data() || {}),
              }
            : {
                note: DEFAULT_STAFF_DAILY_NOTE,
                enabled: true,
                updatedAtMs: 0,
                updatedByName: "",
              };
        render();
      },
      (err) => handleRealtimeError("Catatan staff", err),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, "closings", RECEIPT_TEXT_DOC_ID),
      (snap) => {
        state.data.receiptSettings =
          snap && snap.exists()
            ? normalizeReceiptSettings({ ...(snap.data() || {}) })
            : normalizeReceiptSettings(DEFAULT_RECEIPT_TEXT_SETTINGS);
      },
      (err) => handleRealtimeError("Setting struk", err),
    ),
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, "ops_access", `ops_access_${u}`),
      (snap) => {
        const wasGranted = !!state.data.opsAccess;
        const data = snap && snap.exists() ? snap.data() : null;
        state.data.opsAccess = (data && data.granted === true) ? data : null;
        if (state.data.opsAccess && !wasGranted) {
          if (window.loadAdminTransactions) window.loadAdminTransactions();
          
          if (!window._adminTxChannel) {
            window._adminTxChannel = cashDrawerClient
              .channel('admin_tx_realtime')
              .on("postgres_changes", { event: "*", schema: "public", table: "transactions", filter: "owner_id=eq." + KAS_PRIBADI_OWNER_ID }, () => {
                if (window.loadAdminTransactions) window.loadAdminTransactions();
              })
              .subscribe();
            
            staffRealtimeUnsubs.push(() => {
              if (window._adminTxChannel) {
                cashDrawerClient.removeChannel(window._adminTxChannel).catch(() => {});
                window._adminTxChannel = null;
              }
            });
          }
        } else if (!state.data.opsAccess && wasGranted) {
          if (window._adminTxChannel) {
            cashDrawerClient.removeChannel(window._adminTxChannel).catch(() => {});
            window._adminTxChannel = null;
          }
        }
        debouncedRender();
      },
      (err) => handleRealtimeError("Ops Access", err)
    )
  );

  staffRealtimeUnsubs.push(
    onSnapshot(
      doc(db, "users", u),
      (snap) => {
        if (!snap.exists()) {
          clearSessionAndRender("Akun sudah tidak valid");
          return;
        }
        const raw = snap.data() || {},
          fresh = { id: snap.id, username: raw.username || snap.id, ...raw };
        if (isAdmin(fresh) || fresh.active === false || deleted(fresh)) {
          clearSessionAndRender("Akun sudah nonaktif / tidak valid");
          return;
        }
        const deviceInvalidReason = isDeviceSessionInvalid(fresh);
        if (deviceInvalidReason) {
          clearSessionAndRender(deviceInvalidReason);
          return;
        }
        state.user = {
          ...state.user,
          transactionBonusRate: hasBonusValue(fresh.transactionBonusRate)
            ? Number(fresh.transactionBonusRate)
            : null,
          transactionBonusPercent: hasBonusValue(fresh.transactionBonusPercent)
            ? Number(fresh.transactionBonusPercent)
            : null,

          closingBonusPerMinute: isDailyUser(fresh)
            ? 0
            : hasBonusValue(fresh.closingBonusPerMinute)
              ? Number(fresh.closingBonusPerMinute)
              : null,
          dailyBonusRate: hasBonusValue(fresh.dailyBonusRate)
            ? Number(fresh.dailyBonusRate)
            : null,
          dailyBonusPercent: hasBonusValue(fresh.dailyBonusPercent)
            ? Number(fresh.dailyBonusPercent)
            : null,
          active: fresh.active !== false,
          deviceId: isDeviceFreeUser(fresh)
            ? ""
            : String(fresh.deviceId || state.user?.deviceId || ""),
          deviceResetAtMs: Number(
            fresh.deviceResetAtMs || state.user?.deviceResetAtMs || 0,
          ),
          ...trialSessionFields(fresh),
        };
        debouncedRender();
      },
      (err) => handleRealtimeError("User", err),
    ),
  );
}
async function loadStaffData(opts = {}) {
  if (!state.user) return;
  const u = key(state.user.username),
    silent = opts.silent === true,
    d = todayKey(),
    prevD = previousDateKey(d),
    m = monthKey(),
    monthStart = monthStartKey(m),
    monthEnd = monthEndKey(m);
  const cashDrawerLoad = loadCashDrawerStatus(d);
  const drawerWithdrawalLoad = loadDrawerWithdrawals(d);
  if (!silent) showLoad(true);
  try {
    // Load awal fokus ke bulan berjalan. Ini menjaga kartu hari ini, bonus bulanan,
    // absen bulanan, dan closing tetap sama tanpa mengambil riwayat lintas bulan.
    const [
      tx,
      txLegacy,
      att,
      attLegacy,
      prevAtt,
      manual,
      manualMonth,
      manualTarget,
      manualTrial,
      manualLegacy,
      unlockReq,
      bs,
      userSnap,
      guideNoteSnap,
      staffDailyNoteSnap,
      receiptTextSnap,
    ] = await Promise.all([
      getQueryDocs(
        () =>
          query(
            collection(db, "transactions"),
            where("user", "==", u),
            where("dateKey", ">=", monthStart),
            where("dateKey", "<=", monthEnd),
            limit(LIMITS.txBonusAll),
          ),
        () =>
          query(
            collection(db, "transactions"),
            where("user", "==", u),
            limit(LIMITS.txBonusAll),
          ),
      ),
      getDocs(
        query(
          collection(db, "transactions"),
          where("user", "==", u),
          limit(INITIAL_LEGACY_LIMITS.tx),
        ),
      ).catch(() => querySnapshot([])),
      getQueryDocs(
        () =>
          query(
            collection(db, "attendance"),
            where("user", "==", u),
            where("dateKey", ">=", monthStart),
            where("dateKey", "<=", monthEnd),
            limit(LIMITS.attMonth),
          ),
        () =>
          query(
            collection(db, "attendance"),
            where("user", "==", u),
            limit(LIMITS.attMonth),
          ),
      ),
      getDocs(
        query(
          collection(db, "attendance"),
          where("user", "==", u),
          limit(INITIAL_LEGACY_LIMITS.att),
        ),
      ).catch(() => querySnapshot([])),
      getDocs(
        query(
          collection(db, "attendance"),
          where("user", "==", u),
          where("dateKey", "==", prevD),
          limit(10),
        ),
      ).catch(() => querySnapshot([])),
      getQueryDocs(
        () =>
          query(
            collection(db, "manualBonuses"),
            where("user", "==", u),
            where("dateKey", ">=", monthStart),
            where("dateKey", "<=", monthEnd),
            limit(LIMITS.manualBonusAll),
          ),
        () =>
          query(
            collection(db, "manualBonuses"),
            where("user", "==", u),
            limit(LIMITS.manualBonusAll),
          ),
      ),
      getQueryDocs(
        () =>
          query(
            collection(db, "manualBonuses"),
            where("user", "==", u),
            where("monthKey", "==", m),
            limit(LIMITS.manualBonusAll),
          ),
        () =>
          query(
            collection(db, "manualBonuses"),
            where("user", "==", u),
            limit(LIMITS.manualBonusAll),
          ),
      ),
      getDocs(
        query(
          collection(db, "manualBonuses"),
          where("user", "==", u),
          where("id", ">=", `targetbonus_${monthStart}`),
          where("id", "<=", `targetbonus_${monthEnd}\uf8ff`),
          limit(INITIAL_LEGACY_LIMITS.manual),
        ),
      ).catch(() => querySnapshot([])),
      getDocs(
        query(
          collection(db, "manualBonuses"),
          where("user", "==", u),
          where("id", ">=", `trial_targetbonus_${monthStart}`),
          where("id", "<=", `trial_targetbonus_${monthEnd}\uf8ff`),
          limit(INITIAL_LEGACY_LIMITS.manual),
        ),
      ).catch(() => querySnapshot([])),
      getDocs(
        query(
          collection(db, "manualBonuses"),
          where("user", "==", u),
          limit(INITIAL_LEGACY_LIMITS.manual),
        ),
      ).catch(() => querySnapshot([])),
      getQueryDocs(
        () =>
          query(
            collection(db, STAFF_UNLOCK_TABLE),
            where("requestKind", "==", "unlock"),
            where("user", "==", u),
            limit(LIMITS.unlockRequests),
          ),
        () =>
          query(
            collection(db, STAFF_UNLOCK_TABLE),
            where("requestKind", "==", "unlock"),
            where("user", "==", u),
            limit(LIMITS.unlockRequests),
          ),
      ).catch(() => querySnapshot([])),
      getDocFromServer(doc(db, "closings", "__bonus_settings")),
      getDocFromServer(doc(db, "users", u)),
      getDocFromServer(doc(db, "closings", HEADER_GUIDE_NOTE_DOC_ID)).catch(
        () => null,
      ),
      getDocFromServer(doc(db, "closings", STAFF_DAILY_NOTE_DOC_ID)).catch(
        () => null,
      ),
      getDocFromServer(doc(db, "closings", RECEIPT_TEXT_DOC_ID)).catch(
        () => null,
      ),
    ]);

    let closingRows = [];
    try {
      const allRows = await getQueryDocs(
        () =>
          query(
            collection(db, "closings"),
            where("dateKey", ">=", monthStart),
            where("dateKey", "<=", monthEnd),
            limit(LIMITS.closingsAll),
          ),
        () => query(collection(db, "closings"), limit(LIMITS.closingsAll)),
      );
      closingRows = allRows.docs.map((x) => ({ id: x.id, ...x.data() }));
    } catch (closeErr) {
      console.warn("closing all query gagal", closeErr?.code || closeErr);
      closingRows = [];
    }

    const txRows = mergeRowsById(
      tx.docs.map((x) => ({ id: x.id, ...x.data() })),
      txLegacy.docs.map((x) => ({ id: x.id, ...x.data() })),
    ).filter((t) => txMonth(t) === m);
    const attRows = mergeRowsById(
      att.docs.map((x) => ({ id: x.id, ...x.data() })),
      attLegacy.docs.map((x) => ({ id: x.id, ...x.data() })),
      prevAtt.docs.map((x) => ({ id: x.id, ...x.data() })),
    ).filter((a) => attDate(a).startsWith(m) || attDate(a) === prevD);
    const manualRows = mergeRowsById(
      manual.docs.map((x) => ({ ...(x.data() || {}), id: x.id, docId: x.id })),
      manualMonth.docs.map((x) => ({
        ...(x.data() || {}),
        id: x.id,
        docId: x.id,
      })),
      manualTarget.docs.map((x) => ({
        ...(x.data() || {}),
        id: x.id,
        docId: x.id,
      })),
      manualTrial.docs.map((x) => ({
        ...(x.data() || {}),
        id: x.id,
        docId: x.id,
      })),
      manualLegacy.docs.map((x) => ({
        ...(x.data() || {}),
        id: x.id,
        docId: x.id,
      })),
    ).filter((b) => manualBonusMonth(b) === m);
    const unlockRows = unlockReq.docs
      .map((x) => ({ ...(x.data() || {}), id: x.id, docId: x.id }))
      .filter((r) => isFeatureUnlockRequest(r));
    state.data.tx = sortDesc(txRows);
    seedTxProductHistoryFromTx(state.data.tx);
    state.data.att = dedupeAttendanceRows(attRows);
    state.data.manual = sortDesc(manualRows.filter((b) => !deleted(b)));
    state.data.unlockRequests = sortDesc(unlockRows.filter((r) => !deleted(r)));
    state.data.closings = sortDesc(
      closingRows.filter(
        (c) =>
          c.id !== "__bonus_settings" &&
          c.dateKey !== "__bonus_settings" &&
          c.id !== "__risma_manual_closing" &&
          c.dateKey !== "__risma_manual_closing" &&
          c.id !== HEADER_GUIDE_NOTE_DOC_ID &&
          c.dateKey !== HEADER_GUIDE_NOTE_DOC_ID &&
          c.id !== STAFF_DAILY_NOTE_DOC_ID &&
          c.dateKey !== STAFF_DAILY_NOTE_DOC_ID &&
          c.id !== RECEIPT_TEXT_DOC_ID &&
          c.dateKey !== RECEIPT_TEXT_DOC_ID &&
          c.type !== "bonus_settings" &&
          c.type !== "closing_manual_config" &&
          c.type !== "header_guide_note" &&
          c.type !== "staff_daily_home_note" &&
          c.type !== "receipt_text_settings",
      ),
    );
    state.data.headerGuideNote =
      guideNoteSnap && guideNoteSnap.exists()
        ? String((guideNoteSnap.data() || {}).note || DEFAULT_HEADER_GUIDE_NOTE)
        : DEFAULT_HEADER_GUIDE_NOTE;
    state.data.staffDailyNote =
      staffDailyNoteSnap && staffDailyNoteSnap.exists()
        ? {
            note: DEFAULT_STAFF_DAILY_NOTE,
            enabled: true,
            ...(staffDailyNoteSnap.data() || {}),
          }
        : {
            note: DEFAULT_STAFF_DAILY_NOTE,
            enabled: true,
            updatedAtMs: 0,
            updatedByName: "",
          };
    state.data.receiptSettings =
      receiptTextSnap && receiptTextSnap.exists()
        ? normalizeReceiptSettings({ ...(receiptTextSnap.data() || {}) })
        : normalizeReceiptSettings(DEFAULT_RECEIPT_TEXT_SETTINGS);
    state.data.bonus = bs.exists()
      ? normalizeBonusSettings(bs.data())
      : normalizeBonusSettings(DEFAULT_BONUS);
    if (userSnap.exists()) {
      const rawUser = userSnap.data() || {},
        fresh = {
          id: userSnap.id,
          username: rawUser.username || userSnap.id,
          ...rawUser,
        };
      if (isAdmin(fresh) || fresh.active === false || deleted(fresh)) {
        clearSessionAndRender("Akun sudah nonaktif / tidak valid");
        return;
      }
      const deviceInvalidReason = isDeviceSessionInvalid(fresh);
      if (deviceInvalidReason) {
        clearSessionAndRender(deviceInvalidReason);
        return;
      }
      state.user = {
        username: key(fresh.username || u),
        name: fresh.name || u,
        pin: String(fresh.pin || state.user.pin || ""),
        role: fresh.role || "staff",
        transactionBonusRate: hasBonusValue(fresh.transactionBonusRate)
          ? Number(fresh.transactionBonusRate)
          : null,
        transactionBonusPercent: hasBonusValue(fresh.transactionBonusPercent)
          ? Number(fresh.transactionBonusPercent)
          : null,
        closingBonusPerMinute: isDailyUser(fresh)
          ? 0
          : hasBonusValue(fresh.closingBonusPerMinute)
            ? Number(fresh.closingBonusPerMinute)
            : null,
        dailyBonusRate: hasBonusValue(fresh.dailyBonusRate)
          ? Number(fresh.dailyBonusRate)
          : null,
        dailyBonusPercent: hasBonusValue(fresh.dailyBonusPercent)
          ? Number(fresh.dailyBonusPercent)
          : null,
        active: fresh.active !== false,
        deviceId: isDeviceFreeUser(fresh)
          ? ""
          : String(fresh.deviceId || state.user?.deviceId || ""),
        deviceResetAtMs: Number(
          fresh.deviceResetAtMs || state.user?.deviceResetAtMs || 0,
        ),
        ...trialSessionFields(fresh),
      };
      const saved = {
        username: state.user.username,
        name: state.user.name,
        pin: state.user.pin,
        role: state.user.role,
        transactionBonusRate: state.user.transactionBonusRate,
        transactionBonusPercent: state.user.transactionBonusPercent,
        closingBonusPerMinute: isDailyUser(state.user)
          ? 0
          : state.user.closingBonusPerMinute,
        dailyBonusRate: state.user.dailyBonusRate,
        dailyBonusPercent: state.user.dailyBonusPercent,
        active: true,
        deviceId: state.user.deviceId,
        deviceResetAtMs: state.user.deviceResetAtMs,
        ...trialSessionFields(state.user),
      };
      localStorage.setItem(SESSION, JSON.stringify(saved));
    }
    state.lastSyncMs = Date.now();
    state.syncError = "";
    applyPendingToState();
  } catch (e) {
    console.error(e);
    state.syncError = isPermissionError(e)
      ? "Akses Firebase ditolak."
      : "Gagal memuat data. Coba refresh manual.";
    applyPendingToState();
  }
  await cashDrawerLoad.catch(() => null);
  await drawerWithdrawalLoad.catch(() => null);
  await loadDailyTargetData({ apply: true });
  if (!silent) showLoad(false);
  render();
  notifyNewManualBonuses();
  notifyNewBonusWithdrawals();
  if (!opts.skipFlush) flushPending();
  startStaffRealtime();
}
async function flushPending() {
  if (!state.user || state.syncing) return;
  let list = getPending();
  if (!list.length) return;
  state.syncing = true;
  state.syncError = "";
  const remain = [];
  for (const item of list) {
    if (key(item.user) !== key(state.user.username)) {
      remain.push(item);
      continue;
    }
    try {
      if (item.type === "tx_add") {
        const allowed = await verifyTransactionAllowedServer(
          item.payload?.dateKey || todayKey(),
        );
        if (!allowed.ok) {
          item.tries = Number(item.tries || 0) + 1;
          item.lastTryMs = Date.now();
          remain.push(item);
          state.syncError =
            allowed.msg || "Pending transaksi belum bisa diverifikasi.";
          continue;
        }
        await setDoc(
          doc(db, "transactions", item.id),
          {
            ...(item.payload || {}),
            createdAt: serverTimestamp(),
            syncedAt: serverTimestamp(),
            syncedAtMs: Date.now(),
          },
          { merge: true },
        );
      } else if (item.type === "att_add") {
        const payload = item.payload || {};
        const d = String(payload.dateKey || todayKey()).slice(0, 10),
          docId = attendanceDocId(item.user || payload.user, d);
        const existing = await getDocFromServer(doc(db, "attendance", docId));
        if (!existing.exists())
          await setDoc(
            doc(db, "attendance", docId),
            {
              ...payload,
              clientId: docId,
              dateKey: d,
              createdAt: serverTimestamp(),
              syncedAt: serverTimestamp(),
              syncedAtMs: Date.now(),
            },
            { merge: true },
          );
        item.id = docId;
      } else if (item.type === "feature_unlock_request") {
        const payload = item.payload || {};
        await setDoc(
          doc(db, STAFF_UNLOCK_TABLE, item.id),
          {
            ...payload,
            createdAt: serverTimestamp(),
            syncedAt: serverTimestamp(),
            syncedAtMs: Date.now(),
          },
          { merge: true },
        );
        notifyAdminFeatureUnlock({ id: item.id, ...payload, pending: false });
      } else remain.push(item);
    } catch (e) {
      console.warn("pending sync failed", e?.code || e);
      item.tries = Number(item.tries || 0) + 1;
      item.lastTryMs = Date.now();
      remain.push(item);
      if (isPermissionError(e)) {
        state.syncError = "Akses Firebase ditolak. Data belum bisa sync.";
        break;
      } else state.syncError = "Koneksi belum stabil, sync akan dicoba lagi.";
    }
  }
  setPending(remain);
  state.syncing = false;
  applyPendingToState();
  render();
}
async function retrySync() {
  await flushPending();
  if (!pendingForUser().length) {
    toast("Semua data sudah sync");
    await loadStaffData({ silent: true, skipFlush: true });
  } else toast("Masih ada data menunggu sync");
}
function liveTx() {
  return state.data.tx.filter(
    (t) => !deleted(t) && recordMatchesCurrentAccount(t),
  );
}
function todayTx() {
  const d = todayKey();
  return liveTx().filter((t) => txDate(t) === d);
}
function monthTx() {
  const m = monthKey();
  return liveTx().filter((t) => txMonth(t) === m);
}
function todayTotal() {
  return todayTx().reduce((s, t) => s + Number(t.amount || 0), 0);
}
function monthTotal() {
  return monthTx().reduce((s, t) => s + Number(t.amount || 0), 0);
}
function todayAtt() {
  const d = todayKey(),
    u = key(state.user?.username);
  return dedupeAttendanceRows(state.data.att).find(
    (a) =>
      !deleted(a) &&
      recordMatchesCurrentAccount(a) &&
      attDate(a) === d &&
      (!u || key(a.user) === u),
  );
}
function monthAttendDays() {
  const m = monthKey(),
    set = new Set();
  dedupeAttendanceRows(state.data.att).forEach((a) => {
    if (
      !deleted(a) &&
      recordMatchesCurrentAccount(a) &&
      attDate(a).startsWith(m)
    )
      set.add(attDate(a));
  });
  return set.size;
}
function monthlyAttendancePerformance() {
  const m = monthKey();
  const rows = dedupeAttendanceRows(state.data.att).filter(
    (a) =>
      !deleted(a) && recordMatchesCurrentAccount(a) && attDate(a).startsWith(m),
  );
  if (!rows.length) return null;
  let total = 0,
    count = 0;
  for (const rec of rows) {
    const n = ms(rec);
    if (!n) continue;
    const p = parts(new Date(n));
    total += Number(p.hour || 0) * 60 + Number(p.minute || 0);
    count++;
  }
  if (!count) return null;
  const avg = total / count,
    h = Math.floor(avg / 60),
    mi = Math.floor(avg % 60),
    label = String(h).padStart(2, "0") + ":" + String(mi).padStart(2, "0");
  return { avgLabel: label, isGood: avg <= 440, count };
}
function averageAttendanceCard() {
  if (isDaily() || isRismaSpecialUser()) return "";
  const p = monthlyAttendancePerformance();
  if (!p)
    return `<div class="card avg-att-card"><div class="between"><div class="avg-att-head"><span class="avg-att-ico">⏱</span><div><div class="label">Rata-rata Jam Absen</div><div class="hint" style="margin-top:4px">${monthID(monthKey())} · belum ada data</div></div></div><div class="avg-att-metric"><div class="stat-val" style="color:var(--muted)">--:--</div></div></div></div>`;
  const cls = p.isGood ? "avg-good" : "avg-warn",
    pill = p.isGood ? "green" : "amber",
    txt = p.isGood ? "Performa baik" : "Perlu ditingkatkan";
  return `<div class="card avg-att-card ${cls}"><div class="between"><div class="avg-att-head"><span class="avg-att-ico">⏱</span><div><div class="label">Rata-rata Jam Absen</div><div class="hint" style="margin-top:4px">${monthID(monthKey())} · ${p.count} hari hadir</div></div></div><div class="avg-att-metric"><div class="stat-val">${p.avgLabel}</div><span class="pill ${pill}">${txt}</span></div></div></div>`;
}
function hasAttendOn(dateKey) {
  const u = key(state.user?.username),
    d = String(dateKey || "").slice(0, 10);
  return dedupeAttendanceRows(state.data.att).some(
    (a) =>
      !deleted(a) &&
      recordMatchesCurrentAccount(a) &&
      attDate(a) === d &&
      (!u || key(a.user) === u),
  );
}
function rate() {
  return userTransactionBonusRate();
}
function manualBonusRowsForDate(dateKey = todayKey()) {
  const d = String(dateKey || todayKey()).slice(0, 10);
  return sortDesc(
    (state.data.manual || []).filter(
      (b) =>
        !deleted(b) &&
        !isBonusWithdrawalRow(b) &&
        recordMatchesCurrentAccount(b) &&
        canReceiveManualBonusRow(b) &&
        manualBonusDate(b) === d &&
        Number(b.amount || 0) !== 0,
    ),
  );
}
function manualBonusRowsForMonth(month = monthKey()) {
  const m = String(month || monthKey()).slice(0, 7);
  return sortDesc(
    (state.data.manual || []).filter(
      (b) =>
        !deleted(b) &&
        !isBonusWithdrawalRow(b) &&
        recordMatchesCurrentAccount(b) &&
        canReceiveManualBonusRow(b) &&
        manualBonusMonth(b) === m &&
        Number(b.amount || 0) !== 0,
    ),
  );
}
function manualBonusRowsAll() {
  return sortDesc(
    (state.data.manual || []).filter(
      (b) =>
        !deleted(b) &&
        !isBonusWithdrawalRow(b) &&
        recordMatchesCurrentAccount(b) &&
        canReceiveManualBonusRow(b) &&
        Number(b.amount || 0) !== 0,
    ),
  );
}
function manualBonusToday() {
  return manualBonusRowsForDate(todayKey()).reduce(
    (sum, b) => sum + Number(b.amount || 0),
    0,
  );
}
function manualBonus() {
  return manualBonusRowsForMonth(monthKey()).reduce(
    (sum, b) => sum + Number(b.amount || 0),
    0,
  );
}
function bonusWithdrawalRowsForMonth(month = monthKey()) {
  const m = String(month || monthKey()).slice(0, 7);
  return sortDesc(
    (state.data.manual || []).filter(
      (b) =>
        !deleted(b) &&
        isBonusWithdrawalRow(b) &&
        recordMatchesCurrentAccount(b) &&
        manualBonusMonth(b) === m &&
      bonusWithdrawalAmount(b) > 0,
    ),
  );
}
function bonusWithdrawalDetailList(limit = 3) {
  return "";
}
function bonusWithdrawn() {
  return bonusWithdrawalRowsForMonth(monthKey()).reduce(
    (sum, b) => sum + bonusWithdrawalAmount(b),
    0,
  );
}
function activeClosings() {
  return state.data.closings.filter(
    (c) => c && c.closed === true && c.canceled !== true && !deleted(c),
  );
}
function closingScope(c) {
  return String(c?.scope || (c?.user ? "user" : "global")).toLowerCase();
}
function closingBonusValue(c) {
  if (!c || c.closed !== true) return 0;
  const u = key(state.user?.username),
    map = c.bonusByUser || {},
    scope = closingScope(c);
  if (scope === "user" || c.user) {
    if (Object.keys(map).length) return Number(map[u] || 0);
    return key(c.user) === u ? Number(c.bonusPerUser || c.totalBonus || 0) : 0;
  }
  // Penting: untuk closing GLOBAL, user hanya dapat bonus kalau index menulis bonusByUser[username].
  // Jangan fallback ke bonusPerUser/totalBonus, karena user yang sudah closing per-user bisa terbaca dobel.
  return Number(map[u] || 0);
}
function closingBonusRows(month = monthKey()) {
  if (isDaily()) return [];
  const m = String(month || monthKey()).slice(0, 7);
  const byDate = new Map();
  activeClosings().forEach((c) => {
    const d = String(c.dateKey || "").slice(0, 10);
    if (!d || !d.startsWith(m)) return;
    const val = Math.round(closingBonusValue(c));
    if (!val) return;
    const scope = closingScope(c),
      prev = byDate.get(d);
    // Satu user hanya boleh punya 1 bonus closing per tanggal. Jika ada closing per-user dan global, prioritaskan per-user.
    if (!prev || scope === "user" || c.user) byDate.set(d, { record: c, val });
  });
  return [...byDate.values()];
}
function closingBonus() {
  return closingBonusRows(monthKey()).reduce(
    (sum, x) => sum + Number(x.val || 0),
    0,
  );
}
function closingCount() {
  return closingBonusRows(monthKey()).length;
}
function isDailyRole(role) {
  return String(role || "").trim().toLowerCase() === "harian";
}
function isDailyTransactionRecord(t) {
  const storedRole = String(t?.userRole || t?.role || '').trim().toLowerCase();
  if (storedRole && isDailyRole(storedRole)) return true;
  if (storedRole && !isDailyRole(storedRole)) return false;
  return isDaily();
}
function trxBonus() {
  const tx = monthTx();
  const staffTx = isDaily() ? tx : tx.filter((t) => !isDailyTransactionRecord(t));
  return txBonusSum(staffTx);
}
function totalBonus() {
  return trxBonus() + closingBonus() + manualBonus();
}
function remainingBonus() {
  return Math.max(0, totalBonus() - bonusWithdrawn());
}
function todayClosing() {
  const d = todayKey(),
    u = key(state.user?.username);
  const rows = state.data.closings.filter(
    (c) =>
      c &&
      c.closed === true &&
      c.canceled !== true &&
      !deleted(c) &&
      String(c.dateKey || "") === d,
  );
  const userRows = rows.filter(
    (c) => (closingScope(c) === "user" || c.user) && key(c.user) === u,
  );
  if (userRows.length) return sortDesc(userRows)[0];
  const globalRows = rows.filter(
    (c) => closingScope(c) === "global" || (!c.user && c.scope !== "user"),
  );
  return sortDesc(globalRows)[0] || null;
}
function closingTimeText(c) {
  if (!c) return "--:--";
  const tm = String(c.closingTime || "").match(/^(\d{1,2}):(\d{2})/);
  if (tm) return String(tm[1]).padStart(2, "0") + ":" + tm[2];
  const n = Number(c.closedAtMs || c.createdAtMs || c.updatedAtMs || 0);
  return n ? timeID(n) : "--:--";
}
function isClosedToday() {
  const d = todayKey(),
    u = key(state.user?.username);
  return state.data.closings.some(
    (c) =>
      c &&
      c.closed === true &&
      c.canceled !== true &&
      !deleted(c) &&
      String(c.dateKey || "") === d &&
      ((!c.user && c.scope !== "user") ||
        c.scope === "global" ||
        key(c.user) === u),
  );
}
function delayMin(tm = timeNow(), source = null) {
  const m = String(tm).match(/^(\d{1,2}):(\d{2})$/);
  if (!m) return 0;
  return Math.max(
    0,
    Number(m[1]) * 60 + Number(m[2]) - closingDeadlineMinutes(source),
  );
}
function closingNotice() {
  if (isDaily() || (!todayAtt() && !(isRismaSpecialUser() && todayTx().length)))
    return "";
  const d = delayMin();
  if (!d || isClosedToday()) return "";
  const rate = userClosingBonusPerMinute();
  const est = d * rate;
  return `<div class="card warn" style="margin-bottom:8px"><b>Estimasi bonus closing</b><div class="hint" style="margin-top:4px;color:inherit">Estimasi bonus kamu Rp ${rp(est)} · sejak ${closingDeadlineTimeLabel()} WIB</div></div>`;
}
function todayClosingBonusNotice() {
  if (isDaily()) return "";
  const c = todayClosing();
  if (!c) return "";
  const val = Math.round(closingBonusValue(c));
  if (!val) return "";
  return `<div class="card closing-bonus-card"><div class="between"><div><div class="label">Bonus Closing Hari Ini</div><div class="stat-val" style="font-size:20px;color:var(--green)">Rp ${rp(val)}</div><div class="hint" style="margin-top:3px">Bonus dari closing index hari ini</div></div><span class="pill green">Dapat</span></div></div>`;
}
function todayClosingBonusInline() {
  if (isDaily()) return "";
  const c = todayClosing();
  if (!c) return "";
  const val = Math.round(closingBonusValue(c));
  if (!val) return "";
  return `<div class="bonus-note" style="margin-top:4px;color:var(--green);font-weight:850">Bonus closing hari ini Rp ${rp(val)}</div>`;
}
function validDateKey(v) {
  return /^\d{4}-\d{2}-\d{2}$/.test(String(v || "").slice(0, 10));
}
function shiftDateKey(date, days = 0) {
  const d = String(date || todayKey()).slice(0, 10);
  const base = Date.parse(`${d}T12:00:00+07:00`);
  if (!Number.isFinite(base)) return todayKey();
  return todayKey(new Date(base + (Number(days) || 0) * 86400000));
}
function previousDateKey(date = todayKey()) {
  return shiftDateKey(date, -1);
}
function isFeatureUnlockRequest(r) {
  return (
    String(r?.requestKind || "") === "unlock" ||
    String(r?.action || r?.type || "") === "feature_unlock_request" ||
    r?.featureUnlockRequest === true
  );
}
function cleanUnlockText(v, max = 280) {
  return String(v || "")
    .replace(/[<>]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}
function unlockRows() {
  return sortDesc(
    (state.data.unlockRequests || []).filter(
      (r) => isFeatureUnlockRequest(r) && !deleted(r),
    ),
  );
}
function unlockStatus(r) {
  const s = key(r?.status || "pending");
  if (s === "approved" || s === "diterima") return "approved";
  if (s === "rejected" || s === "ditolak") return "rejected";
  if (s === "cancelled" || s === "batal") return "cancelled";
  return "pending";
}
function unlockStatusText(r) {
  const s = unlockStatus(r);
  if (s === "approved") return "Dibuka";
  if (s === "rejected") return "Ditolak";
  if (s === "cancelled") return "Dibatalkan";
  return "Menunggu";
}
function unlockStatusClass(r) {
  const s = unlockStatus(r);
  if (s === "approved") return "green";
  if (s === "rejected") return "red";
  if (s === "cancelled") return "amber";
  return "blue";
}
function unlockTargetDate(r) {
  return String(r?.targetDate || r?.workDate || r?.dateKey || todayKey()).slice(
    0,
    10,
  );
}
function unlockMissedDate(r) {
  return String(
    r?.missedDate ||
      r?.missingDate ||
      r?.previousDate ||
      previousDateKey(unlockTargetDate(r)),
  ).slice(0, 10);
}
function isMissedAttendanceUnlock(r) {
  const kind = key(r?.lockKind || r?.reasonKind || r?.unlockKind || "");
  return (
    isFeatureUnlockRequest(r) &&
    (r?.missingAttendance === true ||
      kind === "missed_attendance" ||
      kind === "absen_kemarin" ||
      String(r?.source || "") === "staff_app_missed_attendance_unlock")
  );
}
function missedAttendanceUnlockRows() {
  return unlockRows().filter(isMissedAttendanceUnlock);
}
function unlockRequestDocId(u, nowMs = Date.now()) {
  return `staffunlock_${key(u)}_${nowMs}_${Math.random().toString(36).slice(2, 7)}`;
}
function missedAttendanceLockId(u, missedDate, targetDate) {
  return `missed_attendance_${key(u)}_${String(missedDate).slice(0, 10)}_${String(targetDate).slice(0, 10)}`;
}
function approvedUnlockForMissedAttendance(
  targetDate = todayKey(),
  missedDate = previousDateKey(targetDate),
  rows = null,
) {
  const list = (
    Array.isArray(rows) ? rows : missedAttendanceUnlockRows()
  ).filter(isMissedAttendanceUnlock);
  const u = key(state.user?.username),
    target = String(targetDate || todayKey()).slice(0, 10),
    missed = String(missedDate || previousDateKey(target)).slice(0, 10);
  return (
    list.find(
      (r) =>
        key(r.user) === u &&
        unlockStatus(r) === "approved" &&
        (unlockTargetDate(r) === target || unlockMissedDate(r) === missed),
    ) || null
  );
}
function pendingUnlockForMissedAttendance(
  targetDate = todayKey(),
  missedDate = previousDateKey(targetDate),
) {
  const u = key(state.user?.username),
    target = String(targetDate || todayKey()).slice(0, 10),
    missed = String(missedDate || previousDateKey(target)).slice(0, 10);
  return (
    missedAttendanceUnlockRows().find(
      (r) =>
        key(r.user) === u &&
        unlockStatus(r) === "pending" &&
        (unlockTargetDate(r) === target || unlockMissedDate(r) === missed),
    ) || null
  );
}
function latestMissedAttendanceUnlock() {
  return (
    missedAttendanceUnlockRows().find(
      (r) => key(r.user) === key(state.user?.username),
    ) || null
  );
}
function missedAttendanceLockForDate(
  date = todayKey(),
  unlockRowsOverride = null,
) {
  if (!state.user || isAttendanceFreeUser() || todayAtt()) return null;
  const target = String(date || todayKey()).slice(0, 10),
    missed = previousDateKey(target),
    u = key(state.user.username);
  if (!validDateKey(target) || !validDateKey(missed)) return null;
  if (hasAttendOn(missed)) return null;
  if (approvedUnlockForMissedAttendance(target, missed, unlockRowsOverride))
    return null;
  return {
    id: missedAttendanceLockId(u, missed, target),
    user: u,
    missedDate: missed,
    targetDate: target,
    dateKey: target,
    reason: `Tidak ada absen ${dateID(missed)}`,
  };
}
function missedAttendanceLockText(lock, action = "transaksi") {
  const label = action === "absen" ? "Absen" : "Transaksi";
  return `${label} terkunci karena tidak ada absen tanggal ${dateID(lock?.missedDate)}. Minta buka fitur ke admin dulu.`;
}
function txBlockedMessage() {
  if (isTrialUser()) return "Mode trial siap transaksi";
  const lock = missedAttendanceLockForDate();
  if (lock) return missedAttendanceLockText(lock, "transaksi");
  if (isClosedToday()) return "Transaksi sudah closing hari ini";
  if (isRismaSpecialUser()) return "Risma siap transaksi tanpa absen";
  return "Absen dulu sebelum transaksi";
}
function canTx() {
  if (isTrialUser()) return true;
  if (missedAttendanceLockForDate()) return false;
  if (isClosedToday()) return false;
  if (isAttendanceFreeUser()) return true;
  return !!todayAtt();
}
function upsertRows(listName, rows) {
  if (!Array.isArray(rows) || !rows.length) return;
  const map = new Map(
    (state.data[listName] || []).map((x) => [String(x.id || ""), x]),
  );
  rows.forEach((r) => {
    if (r && r.id) map.set(String(r.id), r);
  });
  state.data[listName] = sortDesc([...map.values()]);
}
function serverClosingHit(c, u, d) {
  return (
    c &&
    c.closed === true &&
    c.canceled !== true &&
    !deleted(c) &&
    String(c.dateKey || "") === d &&
    ((!c.user && c.scope !== "user") ||
      c.scope === "global" ||
      key(c.user) === u)
  );
}
async function verifyAbsenceOpenServer(
  dateKeyForWork = todayKey(),
  action = "transaksi",
) {
  const u = key(state.user?.username),
    target = String(dateKeyForWork || todayKey()).slice(0, 10),
    missed = previousDateKey(target);
  if (!u) return { ok: false, msg: "Sesi login tidak valid. Login ulang." };
  if (isAttendanceFreeUser()) return { ok: true };
  try {
    const reads = [
      getDocsFromServer(
        query(
          collection(db, "attendance"),
          where("user", "==", u),
          where("dateKey", "==", missed),
          limit(10),
        ),
      ),
      getDocsFromServer(
        query(
          collection(db, STAFF_UNLOCK_TABLE),
          where("requestKind", "==", "unlock"),
          where("user", "==", u),
          limit(LIMITS.unlockRequests),
        ),
      ),
    ];
    if (action !== "absen")
      reads.push(
        getDocsFromServer(
          query(
            collection(db, "attendance"),
            where("user", "==", u),
            where("dateKey", "==", target),
            limit(10),
          ),
        ),
      );
    const snaps = await Promise.all(reads);
    const missedRows = snaps[0].docs
      .map((x) => ({ id: x.id, ...x.data() }))
      .filter((a) => !deleted(a) && key(a.user) === u && attDate(a) === missed);
    const unlockRowsFresh = snaps[1].docs
      .map((x) => ({ id: x.id, ...x.data() }))
      .filter(
        (r) => isFeatureUnlockRequest(r) && key(r.user) === u && !deleted(r),
      );
    const todayRows =
      action !== "absen"
        ? snaps[2].docs
            .map((x) => ({ id: x.id, ...x.data() }))
            .filter(
              (a) => !deleted(a) && key(a.user) === u && attDate(a) === target,
            )
        : [];
    upsertRows("att", [...missedRows, ...todayRows]);
    upsertRows("unlockRequests", unlockRowsFresh);
    if (
      missedRows.length ||
      todayRows.length ||
      approvedUnlockForMissedAttendance(target, missed, unlockRowsFresh)
    )
      return { ok: true };
    render();
    return {
      ok: false,
      msg: missedAttendanceLockText(
        { missedDate: missed, targetDate: target },
        action,
      ),
    };
  } catch (e) {
    console.error("cek buka fitur staff gagal", e);
    return {
      ok: false,
      msg: isPermissionError(e)
        ? "Akses cek buka fitur ditolak Firebase."
        : "Gagal cek buka fitur. Pastikan internet aktif.",
    };
  }
}
async function verifyTransactionAllowedServer(dateKeyForTx = todayKey()) {
  const u = key(state.user?.username),
    d = String(dateKeyForTx || todayKey()).slice(0, 10);
  if (!u) return { ok: false, msg: "Sesi login tidak valid. Login ulang." };
  if (isTrialUser()) return { ok: true };
  const unlockCheck = await verifyAbsenceOpenServer(d, "transaksi");
  if (!unlockCheck.ok) return unlockCheck;
  try {
    const reads = [
      getDocsFromServer(
        query(collection(db, "closings"), where("dateKey", "==", d), limit(80)),
      ),
    ];
    if (!isAttendanceFreeUser())
      reads.push(
        getDocsFromServer(
          query(
            collection(db, "attendance"),
            where("user", "==", u),
            where("dateKey", "==", d),
            limit(10),
          ),
        ),
      );
    const snaps = await Promise.all(reads);
    const closingRows = snaps[0].docs.map((x) => ({ id: x.id, ...x.data() }));
    upsertRows("closings", closingRows);
    if (closingRows.some((c) => serverClosingHit(c, u, d))) {
      render();
      return { ok: false, msg: "Transaksi sudah closing hari ini." };
    }
    if (!isAttendanceFreeUser()) {
      const attRows = snaps[1].docs.map((x) => ({ id: x.id, ...x.data() }));
      upsertRows("att", attRows);
      const hasAtt = attRows.some(
        (a) => !deleted(a) && key(a.user) === u && attDate(a) === d,
      );
      if (!hasAtt) {
        state.data.att = (state.data.att || []).filter(
          (a) => !(key(a.user) === u && attDate(a) === d),
        );
        render();
        return {
          ok: false,
          msg: "Absen hari ini belum ada / sudah dihapus admin.",
        };
      }
    }
    return { ok: true };
  } catch (e) {
    console.error("cek ulang absen/closing gagal", e);
    return {
      ok: false,
      msg: isPermissionError(e)
        ? "Akses cek absen/closing ditolak Firebase."
        : "Gagal cek ulang absen/closing. Pastikan internet aktif.",
    };
  }
}
async function latestBonusSnapshotForSave() {
  const u = key(state.user?.username);
  if (!u) return { ok: false, msg: "Sesi login tidak valid. Login ulang." };
  try {
    const [userSnap, bonusSnap] = await Promise.all([
      getDocFromServer(doc(db, "users", u)),
      getDocFromServer(doc(db, "closings", "__bonus_settings")),
    ]);
    if (!userSnap.exists())
      return { ok: false, msg: "User tidak ditemukan. Login ulang." };
    const raw = userSnap.data() || {};
    const fresh = {
      id: userSnap.id,
      username: raw.username || userSnap.id,
      ...raw,
    };
    if (isAdmin(fresh) || fresh.active === false || deleted(fresh))
      return { ok: false, msg: "Akun sudah nonaktif / tidak valid." };
    const deviceInvalidReason = isDeviceSessionInvalid(fresh);
    if (deviceInvalidReason) return { ok: false, msg: deviceInvalidReason };
    lastDeviceSessionCheckAt = Date.now();
    const freshUser = {
      username: key(fresh.username || u),
      name: fresh.name || u,
      pin: String(fresh.pin || state.user.pin || ""),
      role: fresh.role || "staff",
      transactionBonusRate: hasBonusValue(fresh.transactionBonusRate)
        ? Number(fresh.transactionBonusRate)
        : null,
      transactionBonusPercent: hasBonusValue(fresh.transactionBonusPercent)
        ? Number(fresh.transactionBonusPercent)
        : null,
      closingBonusPerMinute: isDailyUser(fresh)
        ? 0
        : hasBonusValue(fresh.closingBonusPerMinute)
          ? Number(fresh.closingBonusPerMinute)
          : null,
      dailyBonusRate: hasBonusValue(fresh.dailyBonusRate)
        ? Number(fresh.dailyBonusRate)
        : null,
      dailyBonusPercent: hasBonusValue(fresh.dailyBonusPercent)
        ? Number(fresh.dailyBonusPercent)
        : null,
      active: fresh.active !== false,
      deviceId: isDeviceFreeUser(fresh)
        ? ""
        : String(fresh.deviceId || state.user?.deviceId || ""),
      deviceResetAtMs: Number(
        fresh.deviceResetAtMs || state.user?.deviceResetAtMs || 0,
      ),
      ...trialSessionFields(fresh),
    };
    const freshBonus = bonusSnap.exists()
      ? normalizeBonusSettings(bonusSnap.data())
      : normalizeBonusSettings(DEFAULT_BONUS);
    state.user = freshUser;
    state.data.bonus = freshBonus;
    localStorage.setItem(SESSION, JSON.stringify(freshUser));
    localStorage.setItem(
      LEGACY_SESSION,
      JSON.stringify({ username: freshUser.username, pin: freshUser.pin }),
    );
    const txRate = userTransactionBonusRate(freshUser);
    const txPercent = Number((txRate * 100).toFixed(3));
    const closingSnapshot = userClosingBonusPerMinute(freshUser);
    const userRole = isDailyUser(freshUser) ? "harian" : "staff";
    return {
      ok: true,
      user: freshUser,
      bonus: freshBonus,
      txRate,
      txPercent,
      closingSnapshot,
      userRole,
    };
  } catch (e) {
    console.error("cek bonus terbaru gagal", e);
    return {
      ok: false,
      msg: isPermissionError(e)
        ? "Akses cek bonus ditolak Firebase."
        : "Gagal cek bonus terbaru. Pastikan internet aktif.",
    };
  }
}

function statusPill() {
  if (isTrialUser()) return `<span class="pill amber">Mode Trial</span>`;
  if (isClosedToday()) return `<span class="pill amber">Sudah closing</span>`;
  if (isDaily()) return `<span class="pill blue">Karyawan harian</span>`;
  const a = todayAtt();
  return a
    ? `<span class="pill green">Sudah absen · ${timeID(ms(a))}</span>`
    : `<span class="pill red">Belum absen</span>`;
}
function locText() {
  if (!state.pos)
    return `<button class="pill blue" onclick="updateLocation()">Ambil GPS</button>`;
  const dist = distance(
    state.pos.lat,
    state.pos.lng,
    OFFICE_LOC.lat,
    OFFICE_LOC.lng,
  );
  return dist <= RADIUS_LIMIT
    ? `<span class="pill green">Radius · ${Math.round(dist)}m</span>`
    : `<span class="pill red">Diluar · ${Math.round(dist)}m</span>`;
}
let txProductDraftItems = [];
const TX_PRODUCT_HISTORY_KEY = "stafku_product_name_history_v1";
const TX_PRODUCT_HISTORY_MAX = 300;
let txProductSuggestActiveIndex = -1;
let txProductSuggestItems = [];
let txProductSuggestTouching = false;

let masterProdukList = [];
async function loadMasterProduk() {
  if (!supabase) return;
  try {
    const { data, error } = await supabase.from('produk').select('nama_produk');
    if (!error && data) {
      masterProdukList = data.map(r => String(r.nama_produk || "").toUpperCase().trim());
    }
  } catch (err) {
    console.error("Gagal load produk:", err);
  }
}
setTimeout(loadMasterProduk, 1000);
function getTxProductHistory() {
  try {
    const raw = localStorage.getItem(TX_PRODUCT_HISTORY_KEY);
    const arr = JSON.parse(raw || "[]");
    return Array.isArray(arr) ? arr.filter((x) => typeof x === "string") : [];
  } catch (e) {
    return [];
  }
}
function saveTxProductHistory(list) {
  try {
    localStorage.setItem(
      TX_PRODUCT_HISTORY_KEY,
      JSON.stringify(list.slice(0, TX_PRODUCT_HISTORY_MAX)),
    );
  } catch (e) {}
}
function addTxProductToHistory(name) {
  const value = txProductName(name);
  if (!value) return;
  let list = getTxProductHistory();
  list = list.filter((x) => x !== value);
  list.unshift(value);
  saveTxProductHistory(list);
}
let txProductHistorySeeded = false;
function seedTxProductHistoryFromTx(txRows) {
  if (txProductHistorySeeded) return;
  if (!Array.isArray(txRows) || !txRows.length) return;
  txProductHistorySeeded = true;
  try {
    const existing = getTxProductHistory();
    const seen = new Set(existing);
    const fresh = [];
    for (const t of txRows) {
      const items = txProductItemsFromText(t?.note || "", "");
      for (const name of items) {
        const value = txProductName(name);
        if (!value || value === "TRANSAKSI" || seen.has(value)) continue;
        seen.add(value);
        fresh.push(value);
      }
    }
    if (fresh.length) saveTxProductHistory([...existing, ...fresh]);
  } catch (e) {}
}
function hideTxProductSuggest() {
  if (txProductSuggestTouching) return;
  const floater = document.getElementById("txProductSuggestFloater");
  if (floater) floater.style.display = "none";
  txProductSuggestItems = [];
  txProductSuggestActiveIndex = -1;
}
function renderTxProductSuggestActive() {
  const box = $("txProductSuggest");
  if (!box) return;
  [...box.children].forEach((el, i) => {
    el.classList.toggle("active", i === txProductSuggestActiveIndex);
  });
}
function removeTxProductFromHistory(name) {
  const value = txProductName(name);
  if (!value) return;
  const list = getTxProductHistory().filter((x) => x !== value);
  saveTxProductHistory(list);
}
function deleteTxProductSuggest(index, ev) {
  txProductSuggestTouching = false;
  ev?.stopPropagation?.();
  ev?.preventDefault?.();
  const name = txProductSuggestItems[Number(index)];
  if (!name) return;
  removeTxProductFromHistory(name);
  const input = $("txProductInput");
  const currentVal = input?.value || "";
  setTimeout(() => {
    showTxProductSuggest(currentVal);
    input?.focus?.();
  }, 0);
}
function showTxProductSuggest(query) {
  const input = $("txProductInput");
  if (!input) return hideTxProductSuggest();
  const q = txProductName(query || "");
  if (!q) return hideTxProductSuggest();
  const sourceList = masterProdukList.length > 0 ? masterProdukList : getTxProductHistory();
  const matches = sourceList.filter((x) => x.includes(q)).slice(0, 15);
  if (!matches.length) return hideTxProductSuggest();
  txProductSuggestItems = matches;
  txProductSuggestActiveIndex = -1;

  // Render dropdown langsung ke body agar tidak ter-clip oleh overflow:auto modal
  let floater = document.getElementById("txProductSuggestFloater");
  if (!floater) {
    floater = document.createElement("div");
    floater.id = "txProductSuggestFloater";
    floater.style.cssText = "position:fixed;z-index:9999;background:var(--card,#fff);border:1.5px solid var(--line,#e3e3e3);border-radius:12px;box-shadow:0 10px 24px rgba(0,0,0,.22);overflow:auto;max-height:190px;padding:5px;box-sizing:border-box;";
    document.body.appendChild(floater);
  }

  // Posisi mengikuti input
  const rect = input.getBoundingClientRect();
  floater.style.left = rect.left + "px";
  floater.style.top = (rect.bottom + 4) + "px";
  floater.style.width = rect.width + "px";

  floater.innerHTML = matches
    .map(
      (name, i) =>
        `<div class="tx-product-suggest-item" onclick="pickTxProductSuggest(${i});event.preventDefault();event.stopPropagation()" style="display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 6px 9px 10px;font-size:13px;font-weight:700;border-radius:8px;cursor:pointer;color:var(--text,#111)"><span style="white-space:normal;flex:1;min-width:0;word-wrap:break-word;padding-right:8px">${esc(name)}</span><button type="button" onclick="deleteTxProductSuggest(${i},event);event.preventDefault();event.stopPropagation()" aria-label="Hapus riwayat" style="flex:0 0 auto;width:24px;height:24px;border-radius:50%;border:none;background:transparent;color:var(--muted,#888);font-size:16px;line-height:1;font-weight:900;display:flex;align-items:center;justify-content:center;cursor:pointer">×</button></div>`,
    )
    .join("");
  floater.style.display = "block";
}
function pickTxProductSuggest(index) {
  txProductSuggestTouching = false;
  const name = txProductSuggestItems[Number(index)];
  const input = $("txProductInput");
  if (!name || !input) return;
  
  txProductSuggestItems = [];
  txProductSuggestActiveIndex = -1;
  const floater = document.getElementById("txProductSuggestFloater");
  if (floater) { floater.style.display = "none"; floater.innerHTML = ""; }
  
  const val = txProductName(name);
  if (val) {
    input.value = val;
    updateTxProductAddButton();
  }
  
  const qtyInput = $("txProductQty");
  setTimeout(() => {
    if (qtyInput) {
      qtyInput.focus();
      qtyInput.select();
    }
  }, 0);
}
function moveTxProductSuggestActive(dir) {
  if (!txProductSuggestItems.length) return;
  const max = txProductSuggestItems.length - 1;
  txProductSuggestActiveIndex += dir;
  if (txProductSuggestActiveIndex > max) txProductSuggestActiveIndex = 0;
  if (txProductSuggestActiveIndex < 0) txProductSuggestActiveIndex = max;
  renderTxProductSuggestActive();
}
function txProductName(value) {
  return String(value || "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
}
function forceTxProductUppercaseInput(el) {
  if (!el) return;
  const oldValue = String(el.value || ""),
    nextValue = oldValue.toUpperCase();
  if (oldValue === nextValue) return;
  const start = el.selectionStart,
    end = el.selectionEnd;
  el.value = nextValue;
  try {
    if (typeof start === "number" && typeof end === "number")
      el.setSelectionRange(start, end);
  } catch (e) {}
}
function txProductItemsFromText(text, fallback = "Transaksi") {
  const lines = String(text || "")
    .split(/\r?\n/)
    .map(txProductName)
    .filter(Boolean);
  return lines.length ? lines : [fallback];
}
function txProductTextFromItems(items, fallback = "Transaksi") {
  const lines = (Array.isArray(items) ? items : [])
    .map(txProductName)
    .filter(Boolean);
  return lines.length ? lines.join("\n") : fallback;
}
function txProductDraftText() {
  const inputValue = txProductName($("txProductInput")?.value || "");
  let qty = parseInt($("txProductQty")?.value || "1") || 1;
  const rows = [...txProductDraftItems];
  if (inputValue) rows.push(inputValue + (qty > 1 ? ` qty ${qty}` : ""));
  return txProductTextFromItems(rows, "Transaksi");
}
function txProductItemCount(note) {
  return txProductItemsFromText(note, "Transaksi").length;
}
function txProductDisplayHtml(note) {
  const items = txProductItemsFromText(note, "Transaksi");
  if (items.length === 1) return esc(items[0]);
  return txProductReceiptHtml(items);
}
function txProductDetailHtml(note) {
  const items = txProductItemsFromText(note, "Transaksi");
  return txProductReceiptHtml(items);
}
function txProductReceiptHtml(items) {
  const rows = (Array.isArray(items) ? items : [])
    .map((x) => String(x || "").trim())
    .filter(Boolean);
  const safeRows = rows.length ? rows : ["Transaksi"];
  const sep = "-".repeat(32);
  return `<div class="tx-product-receipt-list">${safeRows.map((x) => `<div class="tx-product-receipt-row">${esc("> " + x)}</div><div class="tx-product-receipt-sep">${sep}</div>`).join("")}</div>`;
}
function renderTxProductDraft() {
  const list = $("txProductList"),
    add = $("txAddProductBtn"),
    input = $("txProductInput");
  forceTxProductUppercaseInput(input);
  if (add) add.disabled = !String(input?.value || "").trim();
  if (!list) return;
  if (!txProductDraftItems.length) {
    list.innerHTML = "";
    return;
  }
  list.innerHTML = txProductDraftItems
    .map((item, i) => {
      const parts = item.split(" qty ");
      const namePart = parts[0] || item;
      const qtyPart = parts[1] || "";
      return `<div class="tx-product-row" style="grid-template-columns: minmax(0,1fr) 50px auto !important; padding-left: 8px;">
        <span class="tx-product-name">${esc(namePart)}</span>
        <span style="text-align:center;font-weight:700;color:var(--primary)">${qtyPart ? esc(qtyPart) : ''}</span>
        <button type="button" class="tx-product-remove" onclick="removeTxProductItem(${i})">Hapus</button>
      </div>`;
    })
    .join("");
}
function updateTxProductAddButton() {
  renderTxProductDraft();
  showTxProductSuggest($("txProductInput")?.value || "");
}
function addTxProductItem() {
  const input = $("txProductInput");
  const qtyInput = $("txProductQty");
  const value = txProductName(input?.value || "");
  const qty = parseInt(qtyInput?.value || "1") || 1;
  if (!value) {
    renderTxProductDraft();
    input?.focus?.();
    return;
  }
  
  if (masterProdukList.length > 0 && !masterProdukList.includes(value)) {
    toast("Nama barang tidak terdaftar di sistem!");
    input?.focus?.();
    return;
  }

  txProductDraftItems.push(`${value} qty ${qty}`);
  addTxProductToHistory(value);
  if (input) input.value = "";
  if (qtyInput) qtyInput.value = "1";
  hideTxProductSuggest();
  renderTxProductDraft();
  setTimeout(() => input?.focus?.(), 0);
}
function removeTxProductItem(index) {
  const i = Number(index);
  if (Number.isInteger(i) && i >= 0 && i < txProductDraftItems.length)
    txProductDraftItems.splice(i, 1);
  renderTxProductDraft();
  setTimeout(() => $("txProductInput")?.focus?.(), 0);
}
function handleTxProductKey(e) {
  if (e?.key === "Enter" || e?.keyCode === 13) {
    e.preventDefault();
    if (
      txProductSuggestActiveIndex >= 0 &&
      txProductSuggestItems[txProductSuggestActiveIndex]
    ) {
      pickTxProductSuggest(txProductSuggestActiveIndex);
      return;
    }
    addTxProductItem();
  } else if (e?.key === "ArrowDown") {
    if (txProductSuggestItems.length) {
      e.preventDefault();
      moveTxProductSuggestActive(1);
    }
  } else if (e?.key === "ArrowUp") {
    if (txProductSuggestItems.length) {
      e.preventDefault();
      moveTxProductSuggestActive(-1);
    }
  } else if (e?.key === "Escape") {
    hideTxProductSuggest();
  }
}
function txPaymentBadgeHtml(v) {
  const method = normalizeTxPaymentMethod(v);
  if (!method) return "";
  const label = String(txPaymentLabel(method) || "").toUpperCase();
  const cls = method === "cash" ? "cash" : "qris";
  return `<span class="tx-pay-badge ${cls}">${esc(label)}</span>`;
}
const TX_HISTORY_ICONS = {
  receipt:
    '<svg class="tx-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h10a2 2 0 0 1 2 2v16l-3-2-3 2-3-2-3 2V5a2 2 0 0 1 2-2z"/><path d="M9 8h6"/><path d="M9 12h6"/><path d="M9 16h4"/></svg>',
  list: '<svg class="tx-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 6h11"/><path d="M8 12h11"/><path d="M8 18h11"/><path d="M5 6h.01"/><path d="M5 12h.01"/><path d="M5 18h.01"/></svg>',
  print:
    '<svg class="tx-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 8V4h10v4"/><path d="M7 18H5a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M7 14h10v7H7z"/><path d="M17 12h.01"/></svg>',
  trash:
    '<svg class="tx-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M6 7l1 14h10l1-14"/><path d="M9 7V4h6v3"/></svg>',
  back: '<svg class="tx-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>',
};
function txHistoryIcon(name) {
  return TX_HISTORY_ICONS[name] || "";
}
function isTxAfterLatestWithdrawal(t) {
  if (!state.data.drawerWithdrawals || !state.data.drawerWithdrawals.length) return false;
  const dkTx = String(txDate(t) || "").slice(0, 10);
  if (!dkTx) return false;
  const dws = state.data.drawerWithdrawals.filter(w => {
    if (w.deleted || w.status === "deleted") return false;
    return String(w.dateKey || "").slice(0, 10) === dkTx;
  });
  if (!dws.length) return false;
  let latestDw = dws[0];
  for (const w of dws) {
    if ((w.createdAtMs || 0) > (latestDw.createdAtMs || 0)) latestDw = w;
  }
  return ms(t) > Number(latestDw.createdAtMs || 0);
}
function txItem(t) {
  const pending = t.pending === true;
  const canDelete = txDate(t) === todayKey() && !pending;
  const id = esc(t.id);

  const noteLines = String(t.note || "").split("\n").map(x => x.trim()).filter(Boolean);
  let totalQty = 0;
  if (noteLines.length > 0 && noteLines[0] !== "Transaksi" && noteLines[0] !== "-") {
    for (const item of noteLines) {
      const lower = item.toLowerCase();
      if (lower.includes(" qty ")) {
        const q = parseInt(lower.split(" qty ")[1], 10);
        totalQty += isNaN(q) ? 1 : q;
      } else {
        totalQty += 1;
      }
    }
  }
  const detailIconHtml = totalQty > 0 ? `<span style="font-weight:900;font-size:16px;color:var(--text-main);display:flex;align-items:center;justify-content:center">${totalQty}</span>` : txHistoryIcon("list");
  const detailBtn = `<button class="btn sm tx-card-btn tx-card-detail" onclick="openTxDetail('${id}')" aria-label="Detail transaksi" title="Detail">${detailIconHtml}</button>`;
  const printBtn = !pending
    ? `<button class="btn sm tx-card-btn tx-card-print" onclick="printReceiptFromTx('${id}')" aria-label="Cetak struk" title="Cetak">${txHistoryIcon("print")}</button>`
    : "";
  const deleteBtn = canDelete
    ? `<button class="btn sm tx-card-btn tx-card-delete" onclick="delTx('${id}')" aria-label="Hapus transaksi" title="Hapus">${txHistoryIcon("trash")}</button>`
    : "";
  const action = pending
    ? `<div class="tx-card-actions">${detailBtn}<span class="pill amber">Sync</span></div>`
    : `<div class="tx-card-actions">${detailBtn}${printBtn}${deleteBtn}</div>`;

  const method = normalizeTxPaymentMethod(t.paymentMethod || t.paymentLabel);
  const label = txPaymentLabel(method);
  const payBadge = label
    ? `<span class="tx-pay-badge ${method === "cash" ? "cash" : "qris"}">${esc(label)}</span>`
    : "";
  const timeLabel = timeID(ms(t));
  const infoPay = payBadge ? ` · ${payBadge}` : "";
  const shadowStyle = typeof isTxAfterLatestWithdrawal==='function'&&isTxAfterLatestWithdrawal(t) ? 'border: 1px solid #ff4d4d !important; box-shadow: 0 0 5px rgba(255, 77, 77, 0.2) !important;' : '';

  return `<div class="tx-row tx-row-card-mini" style="${shadowStyle}">
    <div class="tx-card-main">
      <div class="tx-card-info">${timeLabel}${infoPay}</div>
    </div>
    <div class="tx-card-side">
      <div class="tx-card-amount">Rp ${rp(t.amount)}</div>
      <div class="tx-action tx-action-card-mini">${action}</div>
    </div>
  </div>`;
}
function findTxById(id) {
  return liveTx().find((t) => String(t.id) === String(id));
}
function openTxDetail(id) {
  const t = findTxById(id);
  if (!t) return toast("Transaksi tidak ditemukan", true);
  const pay = txPaymentLabel(t.paymentMethod || t.paymentLabel) || "Cash";
  const cashier = esc(t.name || state.user?.name || t.user || "Staff");
  const meta = `${cashier} · ${timeID(ms(t))} · ${esc(pay)}`;
  const body = `<div class="tx-admin-detail">
    <div class="tx-detail-card tx-detail-total-card">
      <div class="tx-detail-label">Total Bayar</div>
      <div class="tx-detail-amount">Rp ${rp(t.amount)}</div>
      <div class="tx-detail-meta">${meta}</div>
    </div>
    <div class="tx-detail-card tx-detail-products-card">
      <div class="tx-detail-label">Daftar Barang</div>
      ${txProductDetailHtml(t.note || "Transaksi")}
    </div>
  </div>`;
  modal(
    "Detail Transaksi",
    body,
    `<button type="button" class="btn block" onpointerdown="closeModal(true);event.preventDefault()" ontouchstart="closeModal(true);event.preventDefault()" onclick="closeModal(true)">${txHistoryIcon("back")} Kembali</button>`,
    "tx-modal tx-admin-detail-modal",
  );
}

function unlockHomeCard() {
  if (!state.user) return "";
  if (isAttendanceFreeUser()) return "";
  const lock = missedAttendanceLockForDate();
  if (!lock) return "";
  const pending = pendingUnlockForMissedAttendance(
    lock.targetDate,
    lock.missedDate,
  );
  const latestLine = `Tidak ada absen ${dateID(lock.missedDate)}${pending ? " - menunggu admin buka fitur" : ""}`;
  const primary = `<button class="btn primary" onclick="event.stopPropagation();requestFeatureUnlock()" ${pending ? "disabled" : ""}>${pending ? "Menunggu Admin" : "Minta Buka"}</button>`;
  return `<div class="card leave-home-card" onclick="go('unlock')" role="button" tabindex="0"><div class="leave-home-main"><div class="leave-home-ico">${unlockFeatureIcon()}</div><div class="leave-home-copy"><div class="label">Buka Fitur</div><div class="leave-home-title">Akses kerja terkunci</div><div class="hint">${esc(latestLine)}</div></div></div><div class="leave-home-actions">${primary}</div></div>`;
}
function unlockFeatureIcon() {
  return '<svg class="leave-home-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 11V8a5 5 0 0 1 9.4-2.4"/><path d="M6 11h12a1.5 1.5 0 0 1 1.5 1.5v6A1.5 1.5 0 0 1 18 20H6a1.5 1.5 0 0 1-1.5-1.5v-6A1.5 1.5 0 0 1 6 11Z"/><path d="M12 15v2"/></svg>';
}
function notifyAdminFeatureUnlock(row = {}) {
  const staffName = String(
    row.name || state.user?.name || row.user || state.user?.username || "Staff",
  );
  return notifyRockyAdmin(
    ROCKY_ADMIN_NOTIFY_UNLOCK_URL,
    {
      type: "feature_unlock_request",
      title: "Minta Buka Fitur Staff",
      staff: staffName,
      user: staffName,
      username: String(row.user || state.user?.username || ""),
      name: staffName,
      action: "request",
      status: String(row.status || "pending"),
      lockId: String(row.parentLockId || row.lockId || ""),
      missedDate: String(row.missedDate || ""),
      targetDate: String(row.targetDate || row.dateKey || ""),
      unlockId: String(row.id || row.clientId || ""),
      reason: String(row.reason || row.note || ""),
      note: String(row.reason || row.note || ""),
      feature: String(row.feature || "attendance_transaction"),
      source: "staff",
    },
    "Notif buka fitur admin",
  );
}
async function requestFeatureUnlock() {
  if (!state.user) return toast("Silakan login ulang");
  const lock = missedAttendanceLockForDate();
  if (!lock) return toast("Fitur sudah terbuka");
  if (pendingUnlockForMissedAttendance(lock.targetDate, lock.missedDate))
    return toast("Permintaan buka fitur masih menunggu admin");
  const note = cleanUnlockText(
    prompt(
      "Alasan minta buka fitur?",
      `Saya tidak absen ${dateID(lock.missedDate)} dan ingin mulai kerja hari ini`,
    ) || "",
    220,
  );
  if (note.length < 5) return toast("Alasan wajib diisi");
  const u = key(state.user.username),
    nowMs = Date.now(),
    id = unlockRequestDocId(u, nowMs),
    staffName = state.user.name || u;
  const payload = {
    requestKind: "unlock",
    action: "feature_unlock_request",
    type: "feature_unlock_request",
    featureUnlockRequest: true,
    lockKind: "missed_attendance",
    missingAttendance: true,
    parentLockId: String(lock.id || ""),
    lockId: String(lock.id || ""),
    missedDate: lock.missedDate,
    targetDate: lock.targetDate,
    user: u,
    name: staffName,
    feature: "attendance_transaction",
    reason: note,
    note,
    status: "pending",
    adminRead: false,
    dateKey: todayKey(),
    monthKey: monthKey(),
    createdAtMs: nowMs,
    createdBy: u,
    createdByName: staffName,
    clientId: id,
    source: "staff_app_missed_attendance_unlock",
  };
  const local = { id, ...payload, pending: true };
  state.data.unlockRequests = sortDesc([
    local,
    ...(state.data.unlockRequests || []),
  ]);
  render();
  showLoad(true);
  try {
    await setDoc(
      doc(db, STAFF_UNLOCK_TABLE, id),
      {
        ...payload,
        createdAt: serverTimestamp(),
        syncedAt: serverTimestamp(),
        syncedAtMs: Date.now(),
      },
      { merge: false },
    );
    const saved = { id, ...payload, pending: false };
    state.data.unlockRequests = sortDesc(
      (state.data.unlockRequests || []).map((r) =>
        String(r.id) === id ? saved : r,
      ),
    );
    removePending(id);
    await notifyAdminFeatureUnlock(saved);
    toast("Permintaan buka fitur terkirim");
  } catch (e) {
    console.error(e);
    addPending({
      type: "feature_unlock_request",
      id,
      user: u,
      payload,
      createdAtMs: nowMs,
    });
    toast("Koneksi gagal. Minta buka fitur akan sync otomatis.");
  } finally {
    showLoad(false);
    render();
  }
}
function unlockItem(r) {
  const pending =
    r.pending === true ? '<span class="pending-tag">MENUNGGU SYNC</span>' : "";
  return `<div class="leave-row"><div class="leave-row-main"><div class="leave-row-title">Buka fitur kerja</div><div class="leave-row-meta">Tidak absen ${esc(dateID(unlockMissedDate(r)))} - ${esc(r.reason || r.note || "-")} ${pending}</div></div><div class="leave-row-actions"><span class="pill ${unlockStatusClass(r)}">${unlockStatusText(r)}</span></div></div>`;
}
function renderUnlockPage() {
  const rows = missedAttendanceUnlockRows(),
    pending = rows.filter((r) => unlockStatus(r) === "pending").length;
  const lock = missedAttendanceLockForDate();
  const waiting = lock
    ? pendingUnlockForMissedAttendance(lock.targetDate, lock.missedDate)
    : null;
  const lockCard = lock
    ? `<div class="card warn leave-lock-card"><b>Akses kerja terkunci</b><div class="hint" style="margin-top:4px;color:inherit">${esc(missedAttendanceLockText(lock, isDaily() ? "transaksi" : "absen"))}</div><button class="btn primary block" style="margin-top:8px" onclick="requestFeatureUnlock()" ${waiting ? "disabled" : ""}>${waiting ? "Menunggu admin buka fitur" : "Minta Buka Fitur"}</button></div>`
    : "";
  const body = rows.length
    ? `<div class="leave-list">${rows.map(unlockItem).join("")}</div>`
    : '<div class="empty">Akses kerja normal. Belum ada permintaan buka fitur.</div>';
  const heroDisabled = lock && waiting ? "disabled" : "";
  const heroLabel = lock
    ? waiting
      ? "Menunggu Admin"
      : "Minta Buka"
    : "Terbuka";
  page.innerHTML = `${top("Buka Fitur", `${pending} menunggu admin`)}${syncBar()}${lockCard}<div class="card leave-hero-card"><div><div class="label">Akses Kerja</div><div class="leave-hero-title">${lock ? "Tidak absen hari sebelumnya" : "Fitur terbuka"}</div><div class="hint">${lock ? "Kirim permintaan ke admin untuk membuka absen dan transaksi." : "Tidak ada akses yang terkunci sekarang."}</div></div><button class="btn primary" onclick="requestFeatureUnlock()" ${heroDisabled || (!lock ? "disabled" : "")}>${heroLabel}</button></div>${body}`;
}

function cleanReceiptLine(v, fallback = "", max = 42) {
  const s = String(v ?? "")
    .replace(/[\x00-\x1F\x7F]/g, " ")
    .replace(/[\r\n\t]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  const out = s || fallback;
  return String(out || "").slice(0, max);
}
function cleanReceiptMultiline(v, fallback = "", maxLines = 4, maxEach = 42) {
  const lines = String(v ?? "")
    .split(/\r?\n/)
    .map((x) => cleanReceiptLine(x, "", maxEach))
    .filter(Boolean)
    .slice(0, maxLines);
  return lines.length ? lines.join("\n") : fallback;
}
function normalizeReceiptSettings(raw = {}) {
  const m = { ...DEFAULT_RECEIPT_TEXT_SETTINGS, ...(raw || {}) };
  const feed = Math.round(
    Number(m.bottomFeedLines ?? DEFAULT_RECEIPT_TEXT_SETTINGS.bottomFeedLines),
  );
  const bottomFeedLines = Math.max(
    0,
    Math.min(
      20,
      Number.isFinite(feed)
        ? feed
        : DEFAULT_RECEIPT_TEXT_SETTINGS.bottomFeedLines,
    ),
  );
  return {
    storeName: cleanReceiptLine(
      m.storeName,
      DEFAULT_RECEIPT_TEXT_SETTINGS.storeName,
    ),
    storeSubtext: cleanReceiptMultiline(m.storeSubtext, "", 4),
    dailyTitle: cleanReceiptLine(
      m.dailyTitle,
      DEFAULT_RECEIPT_TEXT_SETTINGS.dailyTitle,
    ),
    dateLabel: cleanReceiptLine(
      m.dateLabel,
      DEFAULT_RECEIPT_TEXT_SETTINGS.dateLabel,
      12,
    ),
    cashierLabel: cleanReceiptLine(
      m.cashierLabel,
      DEFAULT_RECEIPT_TEXT_SETTINGS.cashierLabel,
      12,
    ),
    productLabel: cleanReceiptLine(
      m.productLabel,
      DEFAULT_RECEIPT_TEXT_SETTINGS.productLabel,
      12,
    ),
    totalLabel: cleanReceiptLine(
      m.totalLabel,
      DEFAULT_RECEIPT_TEXT_SETTINGS.totalLabel,
      12,
    ),
    countLabel: cleanReceiptLine(
      m.countLabel,
      DEFAULT_RECEIPT_TEXT_SETTINGS.countLabel,
      12,
    ),
    footerText: cleanReceiptMultiline(
      m.footerText,
      DEFAULT_RECEIPT_TEXT_SETTINGS.footerText,
      3,
    ),
    bottomFeedLines,
  };
}
function receiptSettings() {
  return normalizeReceiptSettings(
    state.data.receiptSettings || DEFAULT_RECEIPT_TEXT_SETTINGS,
  );
}
function receiptBottomFeed(s = receiptSettings()) {
  return "\n".repeat(Math.max(0, Math.min(20, Number(s.bottomFeedLines || 0))));
}
function receiptLabel(label, width = 8) {
  const s = cleanReceiptLine(label, "-", 12);
  return `${s.length < width ? s.padEnd(width, " ") : s} :`;
}
function receiptSummaryLabel(label) {
  return receiptLabel(label, 11);
}
function receiptSummaryLine(label, value, indent = "") {
  return `${indent}${receiptSummaryLabel(label)} ${String(value ?? "").trim()}`;
}
function receiptHeaderLines(s = receiptSettings()) {
  const lines = [s.storeName];
  if (s.storeSubtext)
    lines.push(...String(s.storeSubtext).split(/\n/).filter(Boolean));
  return lines.join("\n");
}
function receiptFooterLines(s = receiptSettings()) {
  return String(s.footerText || DEFAULT_RECEIPT_TEXT_SETTINGS.footerText)
    .split(/\n/)
    .filter(Boolean)
    .join("\n");
}

function receiptProductParts(note) {
  const lines = String(note || "Transaksi")
    .split(/\r?\n/)
    .map((x) => cleanReceiptLine(x, "", 32))
    .filter(Boolean);
  return lines.length ? lines : ["Transaksi"];
}
function receiptProductNumbered(note, indent = "") {
  const sep = "-".repeat(32);
  return receiptProductParts(note)
    .flatMap((line) => [`${indent}> ${line}`, `${indent}${sep}`])
    .join("\n");
}
function receiptProductBlock(
  note,
  { firstPrefix = "", indent = "", separator = "" } = {},
) {
  const lines = receiptProductParts(note);
  const sep = separator || "-".repeat(32);
  return lines
    .flatMap((line) => [`${indent}> ${line}`, `${indent}${sep}`])
    .join("\n");
}

function receiptTextForTx(t) {
  const s = receiptSettings();
  const tanggal = `${dateID(txDate(t))} ${timeID(ms(t))}`;
  const kasir =
    state.user?.name || state.user?.username || t.name || t.user || "-";
  const nominal = Number(t.amount || 0);
  const pay = txPaymentLabel(t.paymentMethod || t.paymentLabel);
  const paymentLine = pay ? `\n${receiptSummaryLine("Bayar", pay)}` : "";
  const productLabel = cleanReceiptLine(
    s.productLabel || "Produk",
    "Produk",
    12,
  );
  return `${receiptHeaderLines(s)}
--------------------------------
${receiptLabel(s.dateLabel)} ${tanggal}
${receiptLabel(s.cashierLabel)} ${kasir}
${productLabel}:
${receiptProductNumbered(t.note)}

${receiptSummaryLine("Total Bayar", `Rp ${rp(nominal)}`)}${paymentLine}
--------------------------------
${receiptFooterLines(s)}${receiptBottomFeed(s)}
`;
}

let receiptPreviewText = "";
let receiptPreviewTitle = "Struk Transaksi";

function printReceiptFromTx(id) {
  const t = findTxById(id);
  if (!t) return toast("Transaksi tidak ditemukan");
  const text = receiptTextForTx(t);
  openReceiptPreview(text, `Struk · ${dateID(txDate(t))}`);
}

function receiptTextForTodayTransactions() {
  const s = receiptSettings();
  const items = [...todayTx()].sort((a, b) => ms(a) - ms(b));
  const tanggal = dateID(todayKey());
  const kasir = state.user?.name || state.user?.username || "-";
  const total = items.reduce((sum, t) => sum + Number(t.amount || 0), 0);
  const rows = items
    .map((t, i) => {
      const no = String(i + 1).padStart(2, "0");
      const status = t.pending === true ? " (MENUNGGU SYNC)" : "";
      const produk = receiptProductNumbered(t.note, "    ");
      const pay = txPaymentLabel(t.paymentMethod || t.paymentLabel);
      const payLine = pay
        ? `\n${receiptSummaryLine("Bayar", pay, "    ")}`
        : "";
      return `${no}. ${timeID(ms(t))}${status}\n    Produk:\n${produk}\n${receiptSummaryLine("Total Bayar", `Rp ${rp(t.amount)}`, "    ")}${payLine}`;
    })
    .join("\n\n");
  return `${receiptHeaderLines(s)}
${s.dailyTitle}
--------------------------------
${receiptLabel(s.dateLabel)} ${tanggal}
${receiptLabel(s.cashierLabel)} ${kasir}
${receiptLabel(s.countLabel)} ${items.length} trx
--------------------------------
${rows}
--------------------------------
${receiptSummaryLine("TOTAL BAYAR", `Rp ${rp(total)}`)}
--------------------------------
${receiptFooterLines(s)}${receiptBottomFeed(s)}
`;
}

function printTodayTransactions() {
  const items = todayTx();
  if (!items.length) return toast("Belum ada transaksi hari ini");
  const text = receiptTextForTodayTransactions();
  openReceiptPreview(text, `Semua Transaksi · ${dateID(todayKey())}`);
}

function openReceiptPreview(text, title = "Struk Transaksi") {
  receiptPreviewText = String(text || "");
  receiptPreviewTitle = String(title || "Struk Transaksi");
  const body = `<div class="hint">Preview struk dulu. Struk bisa dibagikan atau langsung dicetak ke printer Android.</div>
    <div class="receipt-preview-box"><pre class="receipt-preview-text">${esc(receiptPreviewText)}</pre></div>
    <div class="receipt-modal-actions">
      <button class="btn" onclick="shareReceiptText()">Bagikan</button>
      <button class="btn primary" onclick="nativePrintReceiptText()">Cetak</button>
    </div>`;
  modal(title, body, "", "");
}

async function copyReceiptText() {
  const text = receiptPreviewText || "";
  if (!text) return toast("Struk kosong");
  try {
    if (window.Android && typeof window.Android.copyReceipt === "function") {
      window.Android.copyReceipt(text);
      return;
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
    } else {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.left = "-9999px";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    toast("Struk disalin");
  } catch (e) {
    console.log(text);
    toast("Gagal salin, struk tampil di console");
  }
}

async function shareReceiptText() {
  const text = receiptPreviewText || "";
  if (!text) return toast("Struk kosong");
  try {
    if (window.Android && typeof window.Android.shareReceipt === "function") {
      window.Android.shareReceipt(text);
      return;
    }
    if (navigator.share) {
      await navigator.share({ title: receiptPreviewTitle, text });
      return;
    }
    await copyReceiptText();
    toast("Share belum tersedia, struk disalin");
  } catch (e) {
    if (String(e?.name || "") !== "AbortError") toast("Gagal bagikan struk");
  }
}

function nativePrintReceiptText() {
  const text = receiptPreviewText || "";
  if (!text) return toast("Struk kosong");
  if (window.Android && typeof window.Android.printReceipt === "function") {
    window.Android.printReceipt(text);
    return;
  }
  toast("Cetak Android aktif jika dibuka dari APK Android Studio");
}
function directPrintReceiptText(text, title = "Struk Transaksi") {
  receiptPreviewText = String(text || "");
  receiptPreviewTitle = String(title || "Struk Transaksi");
  nativePrintReceiptText();
}

function browserPrintReceiptText() {
  const text = receiptPreviewText || "";
  if (!text) return toast("Struk kosong");
  if (window.Android && typeof window.Android.printPdf === "function") {
    window.Android.printPdf(receiptPreviewTitle || "Struk Transaksi", text);
    return;
  }
  toast(
    "Print/PDF tersedia di APK Android Studio. Untuk browser pakai Salin/Bagikan.",
  );
}

/* ===== JADWAL SHALAT RINGAN - OFFLINE / TANPA API =====
   Koordinat jadwal mengikuti koordinat absen: OFFICE_LOC. */
const PRAYER_COORD = { lat: OFFICE_LOC.lat, lng: OFFICE_LOC.lng, tz: 7 };
const PRAYER_CFG = {
  fajrAngle: 20,
  ishaAngle: 18,
  asrFactor: 1,
  dhuhrOffset: 2,
  maghribOffset: 2,
};
function prayerDayOfYear(d) {
  const start = new Date(d.getFullYear(), 0, 0);
  return Math.floor((d - start) / 86400000);
}
function prayerDeg(x) {
  return (x * Math.PI) / 180;
}
function prayerRad(x) {
  return (x * 180) / Math.PI;
}
function prayerPad(n) {
  return String(Math.floor(Math.abs(n))).padStart(2, "0");
}
function prayerFmtMin(min) {
  min = ((Math.round(min) % 1440) + 1440) % 1440;
  const h = Math.floor(min / 60),
    m = min % 60;
  return `${prayerPad(h)}:${prayerPad(m)}`;
}
function prayerSolarData(date) {
  const n = prayerDayOfYear(date);
  const g = ((2 * Math.PI) / 365) * (n - 1);
  const eq =
    229.18 *
    (0.000075 +
      0.001868 * Math.cos(g) -
      0.032077 * Math.sin(g) -
      0.014615 * Math.cos(2 * g) -
      0.040849 * Math.sin(2 * g));
  const dec =
    0.006918 -
    0.399912 * Math.cos(g) +
    0.070257 * Math.sin(g) -
    0.006758 * Math.cos(2 * g) +
    0.000907 * Math.sin(2 * g) -
    0.002697 * Math.cos(3 * g) +
    0.00148 * Math.sin(3 * g);
  const noon = 720 - 4 * PRAYER_COORD.lng - eq + PRAYER_COORD.tz * 60;
  return { dec, noon };
}
function prayerHourAngle(latRad, dec, altDeg) {
  const alt = prayerDeg(altDeg);
  const cosH =
    (Math.sin(alt) - Math.sin(latRad) * Math.sin(dec)) /
    (Math.cos(latRad) * Math.cos(dec));
  return prayerRad(Math.acos(Math.max(-1, Math.min(1, cosH))));
}
function prayerTimesForDate(date = new Date()) {
  const { dec, noon } = prayerSolarData(date),
    lat = prayerDeg(PRAYER_COORD.lat);
  const sunAngle = (angle, afterNoon) => {
    const h = prayerHourAngle(lat, dec, -Math.abs(angle));
    return noon + (afterNoon ? h * 4 : -h * 4);
  };
  const sunrise = sunAngle(0.833, false),
    sunset = sunAngle(0.833, true);
  const diff = Math.abs(lat - dec);
  const asrAlt = prayerRad(
    Math.atan(1 / (PRAYER_CFG.asrFactor + Math.tan(diff))),
  );
  const asr = noon + prayerHourAngle(lat, dec, asrAlt) * 4;
  return [
    { key: "subuh", name: "Subuh", min: sunAngle(PRAYER_CFG.fajrAngle, false) },
    { key: "dzuhur", name: "Dzuhur", min: noon + PRAYER_CFG.dhuhrOffset },
    { key: "ashar", name: "Ashar", min: asr },
    { key: "maghrib", name: "Maghrib", min: sunset + PRAYER_CFG.maghribOffset },
    { key: "isya", name: "Isya", min: sunAngle(PRAYER_CFG.ishaAngle, true) },
  ].map((x) => ({ ...x, time: prayerFmtMin(x.min) }));
}
function nextPrayerInfo() {
  const now = new Date();
  const cur = now.getHours() * 60 + now.getMinutes();
  const today = prayerTimesForDate(now);
  let next = today.find((p) => Math.round(p.min) > cur);
  let label = "hari ini";
  if (!next) {
    const tomorrow = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 1,
    );
    next = prayerTimesForDate(tomorrow)[0];
    label = "besok";
  }
  return { next, label, today };
}
function prayerStatCard(extraClass = "") {
  const info = nextPrayerInfo(),
    p = info.next;
  const tap = ` onclick="requestOpenPrayerAyat()" role="button" tabindex="0" title="Double Klik untuk Putar ayat" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();requestOpenPrayerAyat()}"`;
  if (extraClass === "daily") {
    return `<div class="card prayer-daily-banner"${tap}><div class="prayer-daily-icon">☪</div><div class="prayer-daily-main"><div class="prayer-daily-label">Jadwal Shalat</div><div class="prayer-daily-foot">${p.name} ${info.label} · Double Klik untuk Putar ayat</div></div><div class="prayer-daily-time">${p.time}</div></div>`;
  }
  const cls = extraClass ? ` prayer-${extraClass}-card` : "";
  return `<div class="stat prayer-stat-card${cls}"${tap}><div class="stat-label">Jadwal Shalat</div><div class="stat-val">${p.time}</div><div class="stat-foot">${p.name} · Double Klik untuk Putar ayat</div></div>`;
}

const PRAYER_AYAT_TOTAL = 6236;
const PRAYER_AYAT_CACHE_PREFIX = "rocky_prayer_random_ayah_";
let prayerAyatAudio = null,
  prayerAyatAudioSrc = "",
  prayerAyatPlaying = false,
  prayerAyatPaused = false,
  lastPrayerAyatTap = 0,
  prayerAyatLoadingPromise = null;
function prayerAyatDateKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function prayerAyatSeed(str) {
  let h = 2166136261;
  str = String(str || "");
  for (let i = 0; i < str.length; i++)
    h = Math.imul(h ^ str.charCodeAt(i), 16777619);
  return h >>> 0;
}
function prayerAyatNumber(d = new Date()) {
  const seed = prayerAyatSeed(prayerAyatDateKey(d));
  return (seed % PRAYER_AYAT_TOTAL) + 1;
}
function prayerAyatCacheKey(dateKey = prayerAyatDateKey()) {
  return PRAYER_AYAT_CACHE_PREFIX + dateKey;
}
function prayerAyatAudioUrl(num = prayerAyatNumber()) {
  return `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${num}.mp3`;
}
function readPrayerAyatCache(dateKey = prayerAyatDateKey()) {
  try {
    const raw = JSON.parse(
      localStorage.getItem(prayerAyatCacheKey(dateKey)) || "null",
    );
    if (raw && raw.dateKey === dateKey && Number(raw.num) > 0) return raw;
  } catch (e) {}
  return null;
}
function savePrayerAyatCache(ayat) {
  try {
    if (!ayat || !ayat.dateKey) return;
    localStorage.setItem(
      prayerAyatCacheKey(ayat.dateKey),
      JSON.stringify(ayat),
    );
    Object.keys(localStorage)
      .filter(
        (k) =>
          k.indexOf(PRAYER_AYAT_CACHE_PREFIX) === 0 &&
          k !== prayerAyatCacheKey(ayat.dateKey),
      )
      .slice(0, -7)
      .forEach((k) => localStorage.removeItem(k));
  } catch (e) {}
}
function cleanPrayerAyatText(v) {
  return String(v || "")
    .replace(/<[^>]*>/g, "")
    .replace(/\s+/g, " ")
    .trim();
}
function normalizePrayerAyatApi(json, num, dateKey) {
  const rows = Array.isArray(json?.data) ? json.data : [];
  const ar =
    rows.find(
      (x) => String(x?.edition?.language || "").toLowerCase() === "ar",
    ) ||
    rows[0] ||
    {};
  const id =
    rows.find(
      (x) => String(x?.edition?.language || "").toLowerCase() === "id",
    ) ||
    rows[1] ||
    {};
  const surah = ar.surah || id.surah || {};
  const surahName = surah.englishName || surah.name || "Al-Qur’an";
  const ayahNo = ar.numberInSurah || id.numberInSurah || num;
  return {
    num,
    dateKey,
    ref: `QS. ${surahName}: ${ayahNo}`,
    arabic: cleanPrayerAyatText(ar.text) || "Teks Arab belum tersedia.",
    translation: cleanPrayerAyatText(id.text) || "Terjemahan belum tersedia.",
    audio: prayerAyatAudioUrl(num),
    loaded: true,
  };
}
function currentPrayerAyat() {
  const dateKey = prayerAyatDateKey(),
    num = prayerAyatNumber();
  const cached = readPrayerAyatCache(dateKey);
  if (cached && Number(cached.num) === num)
    return {
      ...cached,
      audio: cached.audio || prayerAyatAudioUrl(num),
      loaded: true,
    };
  return {
    num,
    dateKey,
    ref: `Ayat Harian #${num}`,
    arabic: "Memuat ayat harian...",
    translation: "Ayat Al-Qur’an dipilih otomatis setiap ganti tanggal.",
    audio: prayerAyatAudioUrl(num),
    loaded: false,
  };
}
async function fetchPrayerAyatToday(force = false) {
  const dateKey = prayerAyatDateKey(),
    num = prayerAyatNumber();
  if (!force) {
    const cached = readPrayerAyatCache(dateKey);
    if (cached && Number(cached.num) === num)
      return {
        ...cached,
        audio: cached.audio || prayerAyatAudioUrl(num),
        loaded: true,
      };
  }
  if (prayerAyatLoadingPromise) return prayerAyatLoadingPromise;
  prayerAyatLoadingPromise = (async () => {
    try {
      const url = `https://api.alquran.cloud/v1/ayah/${num}/editions/quran-uthmani,id.indonesian`;
      const res = await fetch(url, { cache: "force-cache" });
      if (!res.ok) throw new Error("Gagal memuat ayat");
      const json = await res.json();
      const ayat = normalizePrayerAyatApi(json, num, dateKey);
      savePrayerAyatCache(ayat);
      return ayat;
    } finally {
      prayerAyatLoadingPromise = null;
    }
  })();
  return prayerAyatLoadingPromise;
}
function getPrayerAyatAudio() {
  const ayat = currentPrayerAyat();
  if (!prayerAyatAudio || prayerAyatAudioSrc !== ayat.audio) {
    try {
      if (prayerAyatAudio) {
        prayerAyatAudio.pause();
        prayerAyatAudio.currentTime = 0;
      }
    } catch (e) {}
    prayerAyatAudioSrc = ayat.audio;
    prayerAyatAudio = new Audio(ayat.audio);
    prayerAyatAudio.preload = "none";
    prayerAyatAudio.onplaying = () => {
      prayerAyatPlaying = true;
      prayerAyatPaused = false;
      updatePrayerAyatUI();
    };
    prayerAyatAudio.onpause = () => {
      prayerAyatPlaying = false;
      prayerAyatPaused =
        prayerAyatAudio &&
        prayerAyatAudio.currentTime > 0 &&
        !prayerAyatAudio.ended;
      updatePrayerAyatUI();
    };
    prayerAyatAudio.onended = () => {
      prayerAyatPlaying = false;
      prayerAyatPaused = false;
      updatePrayerAyatUI();
    };
    prayerAyatAudio.onerror = () => {
      prayerAyatPlaying = false;
      prayerAyatPaused = false;
      updatePrayerAyatUI(
        "Audio tilawah gagal dimuat. Cek internet lalu coba Play lagi.",
      );
    };
    prayerAyatAudio.onwaiting = () =>
      updatePrayerAyatUI("Memuat audio tilawah...");
  }
  return prayerAyatAudio;
}
function updatePrayerAyatUI(customStatus = "") {
  const btn = $("prayerAyatPlayBtn"),
    st = $("prayerAyatStatus");
  const audio = prayerAyatAudio;
  const isPlaying = !!(audio && !audio.paused && !audio.ended);
  const isPaused = !!(
    audio &&
    audio.paused &&
    audio.currentTime > 0 &&
    !audio.ended
  );
  if (btn) btn.innerHTML = isPlaying ? "⏸ Pause" : "▶ Play";
  if (st)
    st.textContent =
      customStatus ||
      (isPlaying
        ? "Sedang memutar tilawah"
        : isPaused
          ? "Dijeda"
          : "Klik Play untuk memutar tilawah");
}
function playPrayerAyat() {
  const audio = getPrayerAyatAudio();
  try {
    if (audio.ended) audio.currentTime = 0;
  } catch (e) {}
  updatePrayerAyatUI("Memuat audio tilawah...");
  const playPromise = audio.play();
  if (playPromise && typeof playPromise.catch === "function") {
    playPromise.catch(() => {
      prayerAyatPlaying = false;
      prayerAyatPaused = false;
      updatePrayerAyatUI("Klik Play untuk memutar tilawah");
    });
  }
}
function togglePrayerAyat() {
  const audio = getPrayerAyatAudio();
  try {
    if (!audio.paused && !audio.ended) {
      audio.pause();
      updatePrayerAyatUI();
      return;
    }
    playPrayerAyat();
  } catch (e) {
    toast("Gagal memutar audio");
  }
}
function stopPrayerAyat(closePopup = true) {
  try {
    if (prayerAyatAudio) {
      prayerAyatAudio.pause();
      prayerAyatAudio.currentTime = 0;
    }
  } catch (e) {}
  prayerAyatPlaying = false;
  prayerAyatPaused = false;
  updatePrayerAyatUI();
  if (closePopup) closeModal(true);
}
function prayerAyatModalBody(ayat) {
  const loading = !ayat.loaded;
  return `<div class="prayer-ayat-box"><div id="prayerAyatRef" class="prayer-ayat-ref">${esc(ayat.ref)}</div><div id="prayerAyatArabic" class="prayer-ayat-arabic">${esc(ayat.arabic)}</div><div id="prayerAyatTranslation" class="prayer-ayat-translation">“${esc(ayat.translation)}”</div><div id="prayerAyatStatus" class="prayer-ayat-status">${loading ? "Memuat teks ayat harian..." : "Klik Play untuk memutar tilawah"}</div><div class="prayer-ayat-controls"><button id="prayerAyatPlayBtn" type="button" class="btn primary" onclick="togglePrayerAyat()">▶ Play</button><button type="button" class="btn danger" onclick="stopPrayerAyat(true)">Close</button></div></div>`;
}
function updatePrayerAyatContent(ayat) {
  const ref = $("prayerAyatRef"),
    ar = $("prayerAyatArabic"),
    tr = $("prayerAyatTranslation");
  if (ref) ref.textContent = ayat.ref;
  if (ar) ar.textContent = ayat.arabic;
  if (tr) tr.textContent = `“${ayat.translation}”`;
}
async function loadPrayerAyatForModal() {
  try {
    updatePrayerAyatUI("Memuat teks ayat harian...");
    const ayat = await fetchPrayerAyatToday(false);
    updatePrayerAyatContent(ayat);
    updatePrayerAyatUI();
  } catch (e) {
    updatePrayerAyatUI(
      "Teks ayat gagal dimuat. Audio masih bisa dicoba jika internet tersedia.",
    );
  }
}
function requestOpenPrayerAyat() {
  const now = Date.now(),
    ayat = currentPrayerAyat();
  if (now - lastPrayerAyatTap > 2500) {
    lastPrayerAyatTap = now;
    toast(`Klik sekali lagi untuk memutar ${ayat.ref}`);
    return;
  }
  lastPrayerAyatTap = 0;
  openPrayerAyat(true);
}
function openPrayerAyat(autoPlay = false) {
  const ayat = currentPrayerAyat();
  modal("Ayat Hari Ini", prayerAyatModalBody(ayat), "", "prayer-ayat-modal");
  updatePrayerAyatUI(
    ayat.loaded
      ? "Klik Play untuk memutar tilawah"
      : "Memuat teks ayat harian...",
  );
  loadPrayerAyatForModal();
  if (autoPlay) playPrayerAyat();
}

window.loadAdminTransactions = async (showNotice) => {
  if (!state.data.opsAccess) return;
  try {
    const { data } = await cashDrawerClient.from("transactions")
      .select("id,amount,type,description,date")
      .eq("owner_id", KAS_PRIBADI_OWNER_ID)
      .eq("date", todayKey());
    state.data.adminTransactions = data || [];
    render();
    if (showNotice) toast("Data Cash Fisik direfresh");
  } catch(e) {
    if (showNotice) toast("Gagal refresh Cash Fisik", true);
  }
};

let currentCashOutType = "qris";

window.setCashOutType = (type) => {
  currentCashOutType = type;
  const qBtn = document.getElementById("cashout-type-qris");
  const tBtn = document.getElementById("cashout-type-tabungan");
  if (qBtn) {
    qBtn.style.background = type === "qris" ? "#dbeafe" : "#f1f5f9";
    qBtn.style.color = type === "qris" ? "#1d4ed8" : "#64748b";
    qBtn.style.borderColor = type === "qris" ? "#111" : "#cbd5e1";
  }
  if (tBtn) {
    tBtn.style.background = type === "tabungan" ? "#fef3c7" : "#f1f5f9";
    tBtn.style.color = type === "tabungan" ? "#b45309" : "#64748b";
    tBtn.style.borderColor = type === "tabungan" ? "#111" : "#cbd5e1";
  }
};

window.renderCashOutTodayList = () => {
  const tx = state.data.adminTransactions || [];
  const rows = tx.filter(t => t.type === 'expense' && (String(t.description).startsWith("[CASHOUT:qris]") || String(t.description).startsWith("[CASHOUT:tabungan]")));
  rows.sort((a,b) => b.id - a.id);
  const total = rows.reduce((s,t) => s + Number(t.amount || 0), 0);
  const te = document.getElementById('cashOutTodayTotal');
  if(te) te.innerText = rp(total);
  
  const list = document.getElementById('cashOutTodayList');
  if(!list) return;
  
  if(!rows.length) {
    list.innerHTML = '<div class="empty" style="font-size:12px;padding:14px;text-align:center;color:#758071">Belum ada QRIS/Tabungan hari ini</div>';
    return;
  }
  
  list.innerHTML = rows.map(t => {
    const isQris = String(t.description).startsWith("[CASHOUT:qris]");
    const tp = isQris ? 'qris' : 'tabungan';
    const label = isQris ? 'QRIS' : 'Tabungan';
    let desc = String(t.description).replace("[CASHOUT:qris] ", "").replace("[CASHOUT:tabungan] ", "");
    if(desc === "[CASHOUT:qris]" || desc === "[CASHOUT:tabungan]") desc = label;
    
    const badgeStyle = isQris ? "background:#dbeafe; color:#1d4ed8; border:1px solid #bfdbfe;" : "background:#fef3c7; color:#b45309; border:1px solid #fde68a;";
    
    return `<div style="display:flex; align-items:center; justify-content:space-between; gap:8px; padding:9px 10px; border:1px solid #e5e7eb; border-radius:13px; margin-bottom:7px; background:white;">
      <div style="min-width:0;flex:1;display:flex;align-items:center;gap:7px">
        <span style="display:inline-flex; align-items:center; padding:2px 6px; border-radius:999px; font-size:9px; font-weight:800; ${badgeStyle}">${label}</span>
        <div style="min-width:0">
          <b style="font-size:13px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${desc}</b>
          <span style="font-size:10px;color:var(--muted)">${String(t.date).slice(0,10)}</span>
        </div>
      </div>
      <b class="num" style="font-size:14px;color:#2563eb;white-space:nowrap">-${rp(t.amount)}</b>
      <button class="x" style="color:var(--red);font-size:18px;padding:4px 8px; border:none; background:transparent; cursor:pointer;" onclick="deleteCashOut(${t.id})" aria-label="Hapus" title="Hapus">✕</button>
    </div>`;
  }).join('');
};

window.deleteCashOut = async (id) => {
  const tx = state.data.adminTransactions || [];
  const t = tx.find(x => x.id === id);
  if (!t) return toast("Data tidak ditemukan");
  
  const desc = String(t.description || "");
  if (desc.includes("[AUTO-QRIS:") || /QRIS\s+otomatis\s+kasir/i.test(desc)) {
    return toast("QRIS otomatis tidak bisa dihapus di sini. Hapus transaksi aslinya dari aplikasi staff.", true);
  }

  window.closeCashOutModal();
  setTimeout(async () => {
    const p = await pinAsk(`Hapus transaksi Rp ${rp(t.amount)}?`);
    if (!p) {
      setTimeout(() => window.openCashOutModal(), 200);
      return;
    }
    if (String(p) !== String(state.user.pin)) {
      toast("PIN salah", true);
      setTimeout(() => window.openCashOutModal(), 200);
      return;
    }
    try {
      const { error } = await cashDrawerClient.from("transactions").delete().match({ id, owner_id: KAS_PRIBADI_OWNER_ID });
      if (error) throw error;
      toast("QRIS/Tabungan dihapus");
      if (window.loadAdminTransactions) await window.loadAdminTransactions();
      setTimeout(() => window.openCashOutModal(), 200);
    } catch (e) {
      toast(e.message || "Gagal menghapus", true);
      setTimeout(() => window.openCashOutModal(), 200);
    }
  }, 200);
};

window.addCashOut = async () => {
  const descRaw = document.getElementById("cashOutDesc")?.value?.trim() || "";
  const amount = Number(onlyDigits(document.getElementById("cashOutAmount")?.value || "0"));
  if (!amount || amount <= 0) return toast("Nominal tidak valid", true);
  
  
  try {
    const payload = {
      id: Date.now(),
      owner_id: KAS_PRIBADI_OWNER_ID,
      date: todayKey(),
      description: "[CASHOUT:" + currentCashOutType + "] " + descRaw,
      amount: amount,
      type: "expense",
      category_name: "Pengurangan Cash"
    };
    const { error } = await cashDrawerClient.from("transactions").insert([payload]);
    if (error) throw error;
    toast("Pengeluaran tersimpan");
    
    document.getElementById("cashOutDesc").value = "";
    document.getElementById("cashOutAmount").value = "";
    
    if (window.loadAdminTransactions) await window.loadAdminTransactions();
    if (document.getElementById("cashOutTodayList")) renderCashOutTodayList();
    if (document.getElementById("cashOutCashFisikVal")) window.openCashOutModal();
  } catch(e) {
    toast(e.message || "Gagal menyimpan", true);
  } finally {
    
  }
};

window.saveOpsExpense = async () => {
  const descInput = document.getElementById("opsDescInput");
  const amountInput = document.getElementById("opsAmountInput");
  const desc = descInput?.value?.trim();
  const amount = Number(onlyDigits(amountInput?.value || "0"));
  if (!desc) return toast("Deskripsi harus diisi", true);
  if (!amount || amount <= 0) return toast("Nominal minimal Rp 1", true);
  
  
  try {
    const payload = {
      id: Date.now(),
      owner_id: KAS_PRIBADI_OWNER_ID,
      date: todayKey(),
      description: "[OPS] " + desc,
      amount: amount,
      type: "expense",
      category_name: "Operasional Toko"
    };
    const { error } = await cashDrawerClient.from("transactions").insert([payload]);
    if (error) throw error;
    toast("Operasional tersimpan");
    
    if (descInput) descInput.value = "";
    if (amountInput) amountInput.value = "";
    
    if (window.loadAdminTransactions) await window.loadAdminTransactions();
    if (document.getElementById("opsTodayList")) renderOpsTodayList();
  } catch(e) {
    toast(e.message || "Gagal menyimpan", true);
  }
};

window.renderOpsTodayList = () => {
  const tx = state.data.adminTransactions || [];
  const rows = tx.filter(t => t.type === 'expense' && String(t.description).startsWith("[OPS]"));
  rows.sort((a,b) => b.id - a.id);
  const total = rows.reduce((s,t) => s + Number(t.amount || 0), 0);
  const te = document.getElementById('opsTodayTotal');
  if (te) te.innerText = rp(total);
  const list = document.getElementById('opsTodayList');
  if (!list) return;
  if (!rows.length) {
    list.innerHTML = '<div style="padding:16px;text-align:center;color:var(--muted);font-size:13px;font-weight:600;">Belum ada operasional hari ini</div>';
    return;
  }
  list.innerHTML = rows.map(t => {
    const desc = String(t.description || '').replace("[OPS]", "").trim();
    return `<div style="display:flex;align-items:center;padding:12px 14px;background:var(--card);border:1.5px solid var(--line);border-radius:12px;margin-bottom:8px;">
      <div style="flex:1;min-width:0">
        <b style="font-size:14px;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:var(--text);font-weight:800;margin-bottom:2px;">${esc(desc)}</b>
        <small style="color:var(--muted);font-size:11.5px;font-weight:600;">${dateID(String(t.date))}</small>
      </div>
      <b style="color:var(--red);font-size:14px;margin-right:16px;font-family:monospace;font-weight:800;">-${rp(t.amount)}</b>
      <button style="background:transparent;border:none;font-size:20px;padding:0;cursor:pointer;line-height:1;display:flex;align-items:center;" onclick="deleteOpsExpense(${t.id})" aria-label="Hapus">&#128465;&#65039;</button>
    </div>`;
  }).join('');
};

window.deleteOpsExpense = async (id) => {
  const tx = state.data.adminTransactions || [];
  const t = tx.find(x => x.id === id);
  if (!t) return toast("Data operasional tidak ditemukan");

  window.closeOpsModal();
  setTimeout(async () => {
    const p = await pinAsk(`Hapus operasional Rp ${rp(t.amount)}?`);
    if (!p) {
      setTimeout(() => window.openOpsModal(), 200);
      return;
    }
    if (String(p) !== String(state.user.pin)) {
      toast("PIN salah", true);
      setTimeout(() => window.openOpsModal(), 200);
      return;
    }
    try {
      const { error } = await cashDrawerClient.from("transactions").delete().eq("owner_id", KAS_PRIBADI_OWNER_ID).eq("id", id);
      if (error) throw error;
      toast("Operasional toko dihapus");
      if (window.loadAdminTransactions) await window.loadAdminTransactions();
      setTimeout(() => window.openOpsModal(), 200);
    } catch(e) {
      toast(e.message || "Gagal menghapus", true);
      setTimeout(() => window.openOpsModal(), 200);
    }
  }, 200);
};

window.closeOpsModal = () => {
  const m = document.getElementById("customOpsModalWrap");
  if (m) m.classList.remove("show");
};

window.toggleOpsCard = () => {
  state.data.opsCardOpen = !state.data.opsCardOpen;
  render();
};

window.openOpsModal = () => {
  let m = document.getElementById("customOpsModalWrap");
  if (!m) {
    m = document.createElement("div");
    m.id = "customOpsModalWrap";
    m.className = "modal-wrap";
    m.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" style="padding:20px; background:var(--card); border-radius:24px; max-width:400px; width:90%; box-sizing:border-box; position:relative; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border: 1.5px solid var(--line);">
        <button style="position:absolute; top:16px; right:16px; background:transparent; border:none; font-size:24px; color:var(--muted); cursor:pointer; padding:4px;" onclick="closeOpsModal()">×</button>
        <div style="margin-bottom:16px; padding-right:24px;">
          <h3 style="margin:0 0 4px 0; font-size:17px; color:var(--text); font-weight:800;">Pengeluaran Operasional Toko</h3>
          <small style="color:var(--muted); font-size:11.5px; font-weight:700; display:block; line-height:1.3;">Mengurangi pendapatan hari ini &bull; Masuk total pengeluaran</small>
        </div>
        <div style="margin-bottom:12px;">
          <input id="opsDescInput" type="text" placeholder="Misal: plastik, bensin, dll" style="width:100%; box-sizing:border-box; font-size:15px; padding:12px 14px; border:1.5px solid var(--line); border-radius:12px; background:var(--card2); color:var(--text); outline:none; font-weight:600;">
        </div>
        <div style="margin-bottom:16px;">
          <input id="opsAmountInput" type="tel" inputmode="numeric" placeholder="Nominal" oninput="formatRupiahInput(this)" style="width:100%; box-sizing:border-box; font-size:18px; font-weight:800; padding:12px 14px; border:1.5px solid var(--line); border-radius:12px; background:var(--card2); color:var(--text); outline:none; font-family:monospace;">
        </div>
        <div style="display:flex; gap:10px; margin-bottom:20px;">
          <button style="flex:1; background:var(--card2); color:var(--text); border:1.5px solid var(--line); font-size:15px; font-weight:800; border-radius:12px; padding:12px; cursor:pointer;" onclick="closeOpsModal()">Batal</button>
          <button style="flex:1.5; background:#b45309; color:#fff; border:none; font-size:15px; font-weight:800; border-radius:12px; padding:12px; cursor:pointer;" onclick="saveOpsExpense()">Simpan</button>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; padding:0 4px;">
          <b style="font-size:14px; color:var(--text); font-weight:800;">Operasional Hari Ini</b>
          <span id="opsTodayTotal" style="font-size:15px; color:#b45309; font-weight:900; font-family:monospace;">Rp 0</span>
        </div>
        <div id="opsTodayList" style="max-height:35vh; overflow-y:auto; margin-bottom:16px; display:flex; flex-direction:column; gap:0;"></div>
        <button style="width:100%; background:var(--card2); color:var(--text); border:1.5px solid var(--line); font-size:15px; font-weight:800; border-radius:12px; padding:12px; cursor:pointer;" onclick="closeOpsModal()">Tutup</button>
      </div>
    `;
    document.body.appendChild(m);
  }
  
  const d = document.getElementById("opsDescInput");
  const a = document.getElementById("opsAmountInput");
  if (d) d.value = "";
  if (a) a.value = "";
  
  m.classList.add("show");
  setTimeout(() => {
    if (d) d.focus();
    renderOpsTodayList();
  }, 50);
};

window.openCashOutModal = () => {
  const tx = state.data.adminTransactions || [];
  let opsTotal = 0;
  let qrisTotal = 0;
  let tabunganTotal = 0;
  for (const t of tx) {
    if (t.type === 'expense') {
      if (String(t.description).startsWith("[OPS]")) opsTotal += Number(t.amount || 0);
      else if (String(t.description).startsWith("[CASHOUT:qris]")) qrisTotal += Number(t.amount || 0);
      else if (String(t.description).startsWith("[CASHOUT:tabungan]")) tabunganTotal += Number(t.amount || 0);
    }
  }
  const allFirebaseTx = state.data.targetTx || [];
  const globalFbTotal = allFirebaseTx
    .filter(t => !deleted(t) && (t.dateKey || t.date) === todayKey())
    .reduce((sum, t) => sum + Number(t.amount || 0), 0);
  const cashFisik = globalFbTotal - opsTotal - qrisTotal - tabunganTotal;

  let m = document.getElementById("customCashOutModalWrap");
  if (!m) {
    m = document.createElement("div");
    m.id = "customCashOutModalWrap";
    m.className = "modal-wrap";
    m.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" style="padding:20px; background:var(--card); border-radius:24px; max-width:420px; width:90%; box-sizing:border-box; position:relative; box-shadow: 0 10px 40px rgba(0,0,0,0.15); border: 1.5px solid var(--line);">
        <button style="position:absolute; top:16px; right:16px; background:transparent; border:none; font-size:24px; color:var(--muted); cursor:pointer; padding:4px;" onclick="closeCashOutModal()">×</button>
        <div style="margin-bottom:16px; padding-right:24px;">
          <h3 style="margin:0 0 4px 0; font-size:17px; color:var(--text); font-weight:800;">Pengurangan Cash</h3>
          <small style="color:#2563eb; font-size:11.5px; font-weight:700; display:block; line-height:1.3;">QRIS & Tabungan tidak dihitung pengeluaran bisnis</small>
        </div>
        
        <div style="background:#eff6ff;border:1.5px solid #bfdbfe;border-radius:14px;padding:14px 16px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center">
          <div>
            <div style="font-size:11px;font-weight:900;color:#1d4ed8;margin-bottom:2px">CASH DI TANGAN HARI INI</div>
            <div class="num" id="cashOutCashFisikVal" style="font-size:24px;font-weight:900;color:${cashFisik < 0 ? 'var(--red)' : '#1d4ed8'}">Rp ${rp(cashFisik)}</div>
          </div>
          <div style="text-align:right;font-size:11.5px;color:#4b5563;font-weight:800;line-height:1.8">
            <div>QRIS: <span class="num" id="cashOutQrisVal" style="color:#2563eb">Rp ${rp(qrisTotal)}</span></div>
            <div>Tabungan: <span class="num" id="cashOutTabunganVal" style="color:#854d0e">Rp ${rp(tabunganTotal)}</span></div>
          </div>
        </div>
        
        <div style="display:flex; gap:10px; margin-bottom:16px;">
          <button id="cashout-type-qris" style="flex:1; font-size:15px; padding:12px; background:#dbeafe; color:#1d4ed8; border:2px solid #111; border-radius:12px; font-weight:800; cursor:pointer; box-shadow:2px 2px 0 #111;" onclick="setCashOutType('qris')">&#128241; QRIS</button>
          <button id="cashout-type-tabungan" style="flex:1; font-size:15px; padding:12px; background:var(--card2); color:var(--muted); border:2px solid var(--line); border-radius:12px; font-weight:800; cursor:pointer; box-shadow:2px 2px 0 var(--line);" onclick="setCashOutType('tabungan')">&#127976; Tabungan</button>
        </div>
        
        <div style="margin-bottom:12px;">
          <input type="text" id="cashOutDesc" class="input" placeholder="Keterangan (opsional)" style="width:100%; box-sizing:border-box; font-size:15px; padding:12px 14px; border:1.5px solid var(--line); border-radius:12px; background:var(--card2); color:var(--text); outline:none; font-weight:600;">
        </div>
        <div style="margin-bottom:16px;">
          <input type="tel" id="cashOutAmount" class="input" placeholder="Nominal" inputmode="numeric" oninput="formatRupiahInput(this)" style="width:100%; box-sizing:border-box; font-size:18px; font-weight:800; padding:12px 14px; border:1.5px solid var(--line); border-radius:12px; background:var(--card2); color:var(--text); outline:none; font-family:monospace;">
        </div>
        
        <div style="display:flex; gap:10px; margin-bottom:20px;">
          <button style="flex:1; background:var(--card2); color:var(--text); border:1.5px solid var(--line); font-size:15px; font-weight:800; border-radius:12px; padding:12px; cursor:pointer;" onclick="closeCashOutModal()">Batal</button>
          <button style="flex:1.5; background:#2563eb; color:#fff; border:none; font-size:15px; font-weight:800; border-radius:12px; padding:12px; cursor:pointer;" onclick="addCashOut()">Simpan</button>
        </div>
        
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; padding:0 4px;">
          <b style="font-size:14px; color:var(--text); font-weight:800;">Cash Keluar Hari Ini</b>
          <span id="cashOutTodayTotal" style="font-size:15px; color:#2563eb; font-weight:900; font-family:monospace;">Rp 0</span>
        </div>
        <div id="cashOutTodayList" style="max-height:35vh; overflow-y:auto; margin-bottom:16px; display:flex; flex-direction:column; gap:0;"></div>
        <button style="width:100%; background:var(--card2); color:var(--text); border:1.5px solid var(--line); font-size:15px; font-weight:800; border-radius:12px; padding:12px; cursor:pointer;" onclick="closeCashOutModal()">Tutup</button>
      </div>
    `;
    document.body.appendChild(m);
  } else {
    // update dynamic values if modal exists
    const cashOutCashFisikVal = document.getElementById("cashOutCashFisikVal");
    const cashOutQrisVal = document.getElementById("cashOutQrisVal");
    const cashOutTabunganVal = document.getElementById("cashOutTabunganVal");
    if (cashOutCashFisikVal) {
      cashOutCashFisikVal.innerText = 'Rp ' + rp(cashFisik);
      cashOutCashFisikVal.style.color = cashFisik < 0 ? 'var(--red)' : '#1d4ed8';
    }
    if (cashOutQrisVal) cashOutQrisVal.innerText = 'Rp ' + rp(qrisTotal);
    if (cashOutTabunganVal) cashOutTabunganVal.innerText = 'Rp ' + rp(tabunganTotal);
  }
  
  const d = document.getElementById("cashOutDesc");
  const a = document.getElementById("cashOutAmount");
  if (d) d.value = "";
  if (a) a.value = "";
  
  m.classList.add("show");
  setCashOutType('qris');
  setTimeout(() => renderCashOutTodayList(), 50);
};

window.closeCashOutModal = () => {
  const m = document.getElementById("customCashOutModalWrap");
  if (m) m.classList.remove("show");
};

function opsAccessCard() {
  if (!state.data.opsAccess) return "";
  const tx = state.data.adminTransactions || [];
  let opsTotal = 0;
  let qrisTotal = 0;
  let tabunganTotal = 0;
  for (const t of tx) {
    if (t.type === 'expense') {
      if (String(t.description).startsWith("[OPS]")) opsTotal += Number(t.amount || 0);
      else if (String(t.description).startsWith("[CASHOUT:qris]")) qrisTotal += Number(t.amount || 0);
      else if (String(t.description).startsWith("[CASHOUT:tabungan]")) tabunganTotal += Number(t.amount || 0);
    }
  }
  const allFirebaseTx = state.data.targetTx || [];
  const globalFbTotal = allFirebaseTx
    .filter(t => !deleted(t) && (t.dateKey || t.date) === todayKey())
    .reduce((sum, t) => sum + Number(t.amount || 0), 0);
  const cashFisik = globalFbTotal - opsTotal - qrisTotal - tabunganTotal;
  const isOpen = state.data.opsCardOpen === true;

  return `
    <div style="background:#eff6ff; border:1.5px solid #bfdbfe; border-radius:18px; padding:11px 12px; margin-bottom:10px; box-shadow:0 1px 2px 0 rgba(0,0,0,0.05); overflow:hidden;">
      <div style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;" onclick="toggleOpsCard()">
        <div style="min-width:0;">
          <div style="font-size:10px; font-weight:950; color:#2563eb; text-transform:uppercase; letter-spacing:0.45px; margin:0 0 2px; line-height:1.1;">Cash Fisik Hari Ini</div>
          <div class="num" style="font-size:22px; color:${cashFisik < 0 ? 'var(--red)' : '#2563eb'}; font-weight:950; line-height:1.08; letter-spacing:-0.5px;">Rp ${rp(cashFisik)}</div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <span id="cashFisikSyncIcon" onclick="event.stopPropagation(); (async()=>{const el=document.getElementById('cashFisikSyncIcon');if(el)el.classList.add('cf-syncing');await (window.loadAdminTransactions&&window.loadAdminTransactions(true));const el2=document.getElementById('cashFisikSyncIcon');if(el2)el2.classList.remove('cf-syncing');})();" title="Refresh Cash Fisik" style="min-height:26px; min-width:26px; display:inline-flex; align-items:center; justify-content:center; background:#fff; color:#2563eb; border:2px solid #111; border-radius:999px; box-shadow:2px 2px 0 #111; cursor:pointer;"><svg viewBox="0 0 24 24" style="width:14px;height:14px;stroke:currentColor;stroke-width:2.6;fill:none;stroke-linecap:round;stroke-linejoin:round"><path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M18 2v4h-4"/><path d="M6 22v-4h4"/></svg></span>
          <span style="min-height:24px; display:inline-flex; align-items:center; justify-content:center; font-size:8.8px; background:#dbeafe; color:#1d4ed8; border:2px solid #111; border-radius:999px; padding:3px 7px; font-weight:950; box-shadow:2px 2px 0 #111; line-height:1; white-space:nowrap;">HARI INI</span>
          <span style="font-size:16px; color:#2563eb; font-weight:900; transition:transform 0.2s; display:inline-block; transform:rotate(${isOpen ? '180deg' : '0deg'});">▾</span>
        </div>
      </div>
      ${isOpen ? `
      <div style="margin-top:10px; padding-top:10px; border-top:1px dashed #bfdbfe;">
        <div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:7px; margin-bottom:8px; width:100%;">
          <button onclick="openOpsModal()" style="width:100%; min-height:30px; padding:6px 7px; font-size:10px; line-height:1; border-radius:999px; font-weight:950; border:2px solid #111; box-shadow:2px 2px 0 #111; cursor:pointer; white-space:nowrap; background:#fff3e0; color:#e8820c;">+ Ops</button>
          <button onclick="openCashOutModal()" style="width:100%; min-height:30px; padding:6px 7px; font-size:10px; line-height:1; border-radius:999px; font-weight:950; border:2px solid #111; box-shadow:2px 2px 0 #111; cursor:pointer; white-space:nowrap; background:#dbeafe; color:#1d4ed8;">+ QRIS</button>
        </div>
        <div class="small" style="font-size:10.2px; color:#4b5563; line-height:1.35; font-weight:850; background:#f8fbff; border:1px solid #dbeafe; border-radius:12px; padding:7px 8px; word-break:break-word; text-align:center;">Operasional Toko - QRIS</div>
        <div style="margin-top:7px; border:1px solid #dbeafe; border-radius:14px; overflow:hidden; display:flex; flex-direction:column; background:white;">
          <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; padding:7px 9px; border-bottom:1px solid #eef2ff;">
            <span style="font-size:10px; color:var(--muted); font-weight:900;">Operasional Toko</span>
            <b class="num" style="font-size:12.5px; font-weight:950; cursor:pointer; white-space:nowrap; color:#e8820c;" onclick="openOpsModal()">Rp ${rp(opsTotal)}</b>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; gap:8px; padding:7px 9px;">
            <span style="font-size:10px; color:var(--muted); font-weight:900;">QRIS</span>
            <b class="num" style="font-size:12.5px; font-weight:950; cursor:pointer; white-space:nowrap; color:#2563eb;" onclick="openCashOutModal()">Rp ${rp(qrisTotal)}</b>
          </div>
        </div>
      </div>` : ''}
    </div>
  `;
}

function home() {
  const tx = todayTx(),
    a = todayAtt(),
    c = todayClosing(),
    emptyStockCard = ""; // HIDDEN sementara (belum butuh) - fitur & fungsi stockEmptyQuickCard() tetap ada, tinggal balikin ke: stockEmptyQuickCard();
  if (isDaily()) {
    const todayTxBonus = txBonusSum(tx),
      manualToday = manualBonusToday(),
      todayBonus = todayTxBonus + manualToday;
    const syncBtnDaily = `<button class="refresh-icon-btn sync-header-btn" aria-label="Sync data" title="Tahan untuk Pusat Sinkronisasi" style="top:26px; right:16px; background:rgba(255,255,255,0.2); border-color:rgba(255,255,255,0.4); color:#fff;"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M18 2v4h-4"/><path d="M6 22v-4h4"/></svg><span class="longpress-ring" style="border-color:#fff"></span></button>`;
    const manualCard = "";
    page.innerHTML = `${top("Mode Harian", state.user?.name || "Karyawan Harian")}${trialModeCard()}${manualBonusNoticeCard()}${bonusWithdrawalNoticeCard()}${cashDrawerStatusCard()}${opsAccessCard()}<div class="hero daily-income-hero" style="position:relative">${syncBtnDaily}<div class="kicker">Pendapatan Hari Ini</div><div class="big">Rp ${rp(todayTotal())}</div><div class="sub hero-meta-line">${dateID(todayKey()).slice(0, 5)} · ${tx.length} trx</div>${syncHeroLine()}</div>${emptyStockCard}<div class="grid2" style="margin-top:8px"><div class="stat"><div class="stat-label">Transaksi Hari Ini</div><div class="stat-val">${tx.length}</div><div class="stat-foot">hari ini</div></div><div class="stat"><div class="stat-label">Gaji Hari Ini</div><div class="stat-val">Rp ${rp(todayBonus)}</div><div class="stat-foot">hari ini</div></div></div>${prayerStatCard("daily")}${manualCard}${staffDailyNoteCard()}<div class="bonus-refresh-note"><span class="note-alert-icon">!</span><span><b>Perhatian:</b> klik ikon refresh saat aplikasi error atau saat Transaksi gagal di lakukan.<br><span style="display:block;margin-top:2px">Copyright © 2026 Program by Alfajri – Rocky Hijab.</span></span></div>${headerIconGuide()}`;
    return;
  }
  const mainLabel = c ? "Closing Hari Ini" : "Absen Hari Ini";
  const mainValue = c ? closingTimeText(c) : a ? timeID(ms(a)) : "--:--";
  const mainFoot = c ? "sudah closing" : a ? "sudah absen" : "belum absen";
  const mainClass = c ? "closed" : a ? "ok" : "wait";
  const earnedBonus = totalBonus(),
    takenBonus = bonusWithdrawn(),
    sisaBonus = remainingBonus();
  page.innerHTML = `${top("Mode Staff", state.user?.name || "Karyawan Staff")}${trialModeCard()}${targetReachedNoticeCard()}${manualBonusNoticeCard()}${bonusWithdrawalNoticeCard()}${cashDrawerStatusCard()}${opsAccessCard()}${averageAttendanceCard()}${closingNotice()}<div class="hero" style="position:relative"><div class="kicker">Pendapatan Hari Ini</div><div class="big">Rp ${rp(todayTotal())}</div><div class="sub hero-meta-line">${dateID(todayKey()).slice(0, 5)} · ${tx.length} trx</div>${syncHeroLine()}</div>${dailyTargetCard()}${emptyStockCard}<div class="grid2 staff-stat-grid" style="margin-top:8px"><div class="stat att-status ${mainClass}"><div class="stat-label">${mainLabel}</div><div class="stat-val">${mainValue}</div><div class="stat-foot">${mainFoot}</div></div>${prayerStatCard()}<div class="stat"><div class="stat-label">Transaksi</div><div class="stat-val">${tx.length}</div><div class="stat-foot">hari ini</div></div><div class="stat"><div class="stat-label">Total Masuk Kerja</div><div class="stat-val">${monthAttendDays()} <span style="font-size:13px;font-weight:850;color:var(--muted);letter-spacing:0">Hari</span></div><div class="stat-foot">${monthID(monthKey())}</div></div></div><div class="card bonus-plus-card" style="margin-top:8px"><div class="bonus-plus-head"><div class="label">Bonus Bulan Ini</div><button class="refresh-icon-btn sync-header-btn" aria-label="Sync data" title="Tahan untuk Pusat Sinkronisasi"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M18 2v4h-4"/><path d="M6 22v-4h4"/></svg><span class="longpress-ring"></span></button></div><div class="big" style="color:var(--blue)">Rp ${rp(sisaBonus)}</div><div class="bonus-note">Bonus terhitung ${rp(earnedBonus)} · sudah diambil ${rp(takenBonus)}</div>${bonusWithdrawalDetailList()}${todayClosingBonusInline()}</div>${staffDailyNoteCard()}<div class="bonus-refresh-note"><span class="note-alert-icon">!</span><span><b>Perhatian:</b> klik ikon refresh saat aplikasi error atau saat Transaksi gagal di lakukan.<br><span style="display:block;margin-top:2px">Copyright © 2026 Program by Alfajri – Rocky Hijab.</span></span></div>${headerIconGuide()}`;
}
  function drawerWithdrawalCard() {
    const withdrawals = (state.data.drawerWithdrawals || []).filter(w => {
      if (w.deleted || w.status === "deleted") return false;
      return !w.assignedUser || w.assignedUser === "all" || key(w.assignedUser) === key(state.user?.username);
    });
    if (withdrawals.length === 0) return "";
    const lastWithdrawal = withdrawals[withdrawals.length - 1];
    const remainingOwner = Number(lastWithdrawal.remainingAmount || 0);
    const map = new Map();
    for (const t of (state.data.targetTx || [])) {
      if (!deleted(t) && txDate(t) === todayKey()) map.set(t.id, t);
    }
    for (const t of todayTx()) {
      if (!deleted(t)) map.set(t.id, t);
    }
    const globalToday = Array.from(map.values());

    const txAfter = globalToday.filter(t => ms(t) > (lastWithdrawal.createdAtMs || 0) && (!t.paymentMethod || (!t.paymentMethod.includes("qris") && !t.paymentMethod.includes("transfer"))));
    const newCash = txAfter.reduce((sum, t) => sum + Number(t.amount || 0), 0);
    const estimasi = remainingOwner + newCash;
    return `<div class="card" style="margin-bottom:8px;background:#f8f9fa;border:1px solid #e9ecef;box-shadow:none">
      <div style="font-size:12px;font-weight:800;color:#495057;margin-bottom:8px;display:flex;align-items:center;gap:6px"><i class="fas fa-money-bill-wave" style="color:#0ca678"></i> Estimasi Uang Laci</div>
      <div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;margin-bottom:4px">
        <span style="color:#6c757d">Sisa Uang Laci (Owner):</span>
        <span style="font-weight:600;font-family:monospace">Rp ${rp(remainingOwner)}</span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;font-size:12px;margin-bottom:4px">
        <span style="color:#6c757d">Transaksi Cash Baru:</span>
        <span style="font-weight:600;font-family:monospace">+ Rp ${rp(newCash)}</span>
      </div>
      <div style="border-top:1px dashed #dee2e6;margin:8px 0 6px"></div>
      <div style="display:flex;justify-content:space-between;align-items:center;font-size:13px">
        <span style="font-weight:800;color:#343a40">Estimasi Laci:</span>
        <span style="font-weight:850;color:#0ca678;font-family:monospace">Rp ${rp(estimasi)}</span>
      </div>
    </div>`;
  }
  function history() {
    const items = sortDesc(todayTx());
    const drawerCard = drawerWithdrawalCard();
    const printAllCard = items.length
      ? `<div class="card" style="margin-bottom:8px"><button class="btn primary block tx-print-all-btn" onclick="printTodayTransactions()">${txHistoryIcon("print")} Cetak Semua Transaksi Hari Ini</button><div class="hint" style="margin-top:6px">Cetak ${items.length} transaksi hari ini dalam 1 struk.</div></div>`
      : "";
    const body = items.length
      ? `<div class="tx-table"><div class="tx-head"><span>Nama / Jam</span><span>Nominal</span><span style="text-align:right">Aksi</span></div><div class="tx-list">${items.map(txItem).join("")}</div></div>`
      : '<div class="empty">Belum ada transaksi hari ini.</div>';
    page.innerHTML = `${top("Riwayat Hari Ini", `${items.length} transaksi · Rp ${rp(todayTotal())}`)}${syncBar()}${drawerCard}${printAllCard}${body}`;
  }

  const __baseHomeWithUnlockCard = home;
  home = function () {
    __baseHomeWithUnlockCard();
    if (isRismaSpecialUser() && page) {
      const stat = page.querySelector(".att-status");
      if (stat) {
        stat.classList.remove("wait", "closed");
        stat.classList.add("ok");
        const label = stat.querySelector(".stat-label"),
          val = stat.querySelector(".stat-val"),
          foot = stat.querySelector(".stat-foot");
        if (label) label.textContent = "Akses Hari Ini";
        if (val) val.textContent = "OK";
        if (foot) foot.textContent = "bebas absen";
      }
    }
    const card = unlockHomeCard();
    if (!card || !page) return;
    const stock = page.querySelector(".stock-empty-card");
    if (stock) stock.insertAdjacentHTML("afterend", card);
    else page.insertAdjacentHTML("beforeend", card);
  };

  function cleanBelanjaText(v) {
    return String(v || "")
      .replace(/[<>]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }
  function belanjaSlug(v) {
    return (
      cleanBelanjaText(v)
        .toLowerCase()
        .replace(/\s+/g, "_")
        .replace(/[^a-z0-9_\-.]/g, "")
        .slice(0, 70) || "item"
    );
  }
  function getBelanjakuBridgeQueue() {
    try {
      const raw = JSON.parse(
        localStorage.getItem(BELANJAKU_BRIDGE_KEY) || "[]",
      );
      return Array.isArray(raw) ? raw.filter(Boolean) : [];
    } catch (e) {
      return [];
    }
  }
  function setBelanjakuBridgeQueue(list) {
    try {
      localStorage.setItem(
        BELANJAKU_BRIDGE_KEY,
        JSON.stringify((list || []).slice(-250)),
      );
    } catch (e) {}
  }
  function saveBelanjakuBridgeQueue(item) {
    const list = getBelanjakuBridgeQueue().filter(
      (x) => String(x.id) !== String(item.id),
    );
    list.push(item);
    setBelanjakuBridgeQueue(list);
  }
  function stockEmptyIcon() {
    return '<svg class="stock-empty-svg" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8.5 12 4l8 4.5"/><path d="M4 8.5V17l8 4 8-4V8.5"/><path d="M12 12.5 4 8.5"/><path d="M12 12.5 20 8.5"/><path d="M12 12.5V21"/><path d="M8.5 16h7"/></svg>';
  }
  function stockEmptyQuickCard() {
    return `<div class="card stock-empty-card"><div class="stock-empty-left"><div class="stock-empty-icon">${stockEmptyIcon()}</div><div class="stock-empty-copy"><div class="label">Barang Kosong</div><div class="hint">Laporkan Segera Apabila Ada Stok Barang Yang Menipis Atau Kosong</div></div></div><button class="btn stock-empty-btn" type="button" onclick="openEmptyStock()">Laporkan</button></div>`;
  }
  function normalizeEmptyStockVariants(list) {
    const merged = [],
      seen = new Set();
    (Array.isArray(list) ? list : []).forEach((row) => {
      const colorName = cleanBelanjaText(row?.colorName || row?.color || "");
      if (!colorName) return;
      const k = colorName.toLowerCase();
      if (seen.has(k)) return;
      seen.add(k);
      // Qty sengaja tidak ditampilkan di STF. Nilai 1 hanya untuk kompatibilitas data Belanjaku.
      merged.push({ colorName, qty: 1, done: false });
    });
    return merged;
  }
  function addEmptyStockVariantRow(colorName = "") {
    const list = $("emptyStockVariantList");
    if (!list) return;
    const row = document.createElement("div");
    row.className = "empty-stock-variant-row";
    row.style.cssText =
      "display:grid;grid-template-columns:minmax(0,1fr) 36px;gap:7px;align-items:end;margin-bottom:8px";
    row.innerHTML = `<div><div class="label" style="font-size:10px;margin-bottom:4px">Warna</div><input class="empty-stock-color" autocomplete="off" placeholder="Warna"></div><button type="button" class="btn danger" style="min-height:42px;padding:0;border-radius:10px" onclick="removeEmptyStockVariantRow(this)">×</button>`;
    const color = row.querySelector(".empty-stock-color");
    if (color) color.value = cleanBelanjaText(colorName);
    list.appendChild(row);
    setTimeout(() => color?.focus({ preventScroll: true }), 40);
    return row;
  }
  function removeEmptyStockVariantRow(btn) {
    const list = $("emptyStockVariantList"),
      row = btn?.closest?.(".empty-stock-variant-row");
    if (!list || !row) return;
    const rows = [...list.querySelectorAll(".empty-stock-variant-row")];
    if (rows.length <= 1) {
      const color = row.querySelector(".empty-stock-color");
      if (color) color.value = "";
      color?.focus();
    } else row.remove();
  }
  function getEmptyStockVariants() {
    return normalizeEmptyStockVariants(
      [...document.querySelectorAll(".empty-stock-variant-row")].map((row) => ({
        colorName: row.querySelector(".empty-stock-color")?.value,
      })),
    );
  }
  function buildBelanjakuEmptyItem({ name, variants }) {
    const now = Date.now(),
      nowISO = new Date(now).toISOString(),
      u = key(state.user?.username || "staff"),
      displayName = state.user?.name || state.user?.username || "Staff";
    const cleanName = cleanBelanjaText(name);
    const cleanVariants = normalizeEmptyStockVariants(variants);
    const id =
      "stafku_empty_" +
      belanjaSlug(u) +
      "_" +
      now +
      "_" +
      Math.random().toString(36).slice(2, 7);
    const variantText = cleanVariants.map((v) => v.colorName).join(", ");
    const baseNote = `Dari Stafku (${displayName}) - barang kosong`;
    return {
      id,
      name: cleanName,
      supplierName: "",
      kodiPrice: 0,
      variants: cleanVariants,
      unit: "pcs",
      priority: "Tinggi",
      note: variantText ? `${baseNote}. Warna: ${variantText}` : baseNote,
      done: false,
      source: "stafku_barang_kosong",
      staffStatus: "inbox",
      staffRequest: true,
      createdBy: u,
      createdByName: displayName,
      createdAt: nowISO,
      updatedAt: nowISO,
      createdAtMs: now,
      updatedAtMs: now,
    };
  }
  async function sendBelanjakuItemToSupabase(item) {
    if (typeof fetch !== "function") return false;
    try {
      const url = `${BELANJAKU_SUPABASE_URL.replace(/\/$/, "")}/rest/v1/${BELANJAKU_SUPABASE_ITEMS_TABLE}?on_conflict=id`;
      const res = await fetch(url, {
        method: "POST",
        headers: {
          apikey: BELANJAKU_SUPABASE_ANON_KEY,
          Authorization: `Bearer ${BELANJAKU_SUPABASE_ANON_KEY}`,
          "Content-Type": "application/json",
          Prefer: "resolution=merge-duplicates,return=minimal",
        },
        body: JSON.stringify({
          id: item.id,
          data: item,
          updated_at: item.updatedAt || new Date().toISOString(),
        }),
      });
      if (!res.ok)
        throw new Error("Supabase " + res.status + ": " + (await res.text()));
      return true;
    } catch (e) {
      console.warn("Belanjaku bridge belum terkirim", e);
      return false;
    }
  }
  async function syncBelanjakuBridgeQueue() {
    const queue = getBelanjakuBridgeQueue();
    if (!queue.length) return { sent: 0, remaining: 0 };
    const remaining = [];
    let sent = 0;
    for (const item of queue) {
      const ok = await sendBelanjakuItemToSupabase(item);
      if (ok) sent += 1;
      else remaining.push(item);
    }
    setBelanjakuBridgeQueue(remaining);
    return { sent, remaining: remaining.length };
  }
  function openEmptyStock() {
    if (!state.user) return toast("Silakan login ulang");
    modal(
      "Barang Kosong",
      `<div class="tx-chip"><span>Terima Kasih Sudah Ikut Berkontribusi 🔥🔥🔥🔥</span><b>${timeNow()} WIB</b></div><div class="field"><div class="label">Nama Barang</div><input id="emptyStockName" autocomplete="off" placeholder="isi Nama Barang"></div><div class="field"><div class="between" style="margin-bottom:7px;align-items:center"><div class="label" style="margin:0">Warna</div><button type="button" class="btn warn sm" onclick="addEmptyStockVariantRow()">+ Warna</button></div><div id="emptyStockVariantList"><div class="empty-stock-variant-row" style="display:grid;grid-template-columns:minmax(0,1fr) 36px;gap:7px;align-items:end;margin-bottom:8px"><div><div class="label" style="font-size:10px;margin-bottom:4px">Warna</div><input class="empty-stock-color" autocomplete="off" placeholder="Warna"></div><button type="button" class="btn danger" style="min-height:42px;padding:0;border-radius:10px" onclick="removeEmptyStockVariantRow(this)">×</button></div></div><div class="hint" style="display:block;margin-top:2px">Isi nama barang dan warna saja</div></div><div class="tx-note-mini">Setelah dikirim, barang masuk halaman <b>Kiriman Staff</b><b</b>.</div>`,
      `<button type="button" class="btn danger" onclick="closeModal(true)">Batal</button><button type="button" class="btn warn" onclick="submitEmptyStock()">Kirim</button>`,
      "tx-modal",
    );
    setTimeout(() => $("emptyStockName")?.focus(), 80);
  }
  async function submitEmptyStock() {
    const name = cleanBelanjaText($("emptyStockName")?.value),
      variants = getEmptyStockVariants();
    if (!name) return toast("Nama barang wajib diisi");
    if (!variants.length) return toast("Minimal isi 1 warna");
    const item = buildBelanjakuEmptyItem({ name, variants });
    saveBelanjakuBridgeQueue(item);
    closeModal(true);
    toast(`${variants.length} warna disiapkan untuk Belanjaku`);
    const result = await syncBelanjakuBridgeQueue();
    if (result.sent > 0) toast("Barang kosong multi warna masuk ke Belanjaku");
    else toast("Tersimpan lokal, buka Belanjaku lalu refresh");
  }

  async function pinAsk(msg = "Masukkan PIN") {
    return new Promise((res) => {
      window.__pin = (v) => {
        closeModal();
        delete window.__pin;
        res(String(v || ""));
      };
      modal(
        "Verifikasi PIN",
        `<div class="hint" style="margin-bottom:8px">${esc(msg)}</div><input id="pinx" type="password" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" placeholder="PIN" style="text-align:center;font-size:22px;font-weight:950">`,
        `<button class="btn" onclick="__pin('')">Batal</button><button class="btn primary" onclick="__pin(document.getElementById('pinx').value)">Lanjut</button>`,
      );
      setTimeout(() => $("pinx")?.focus(), 60);
    });
  }
  const TX_PAYMENT_METHODS = { cash: "Cash", qris_transfer: "QRIS / Transfer" };
  let pendingTxDraft = null;
  let txPaymentSubmitting = false;
  function normalizeTxPaymentMethod(v) {
    const s = key(v)
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "");
    if (s === "cash") return "cash";
    if (
      s === "qris" ||
      s === "transfer" ||
      s === "qris_transfer" ||
      s === "qris_transfer_bank" ||
      s === "qris_dan_transfer"
    )
      return "qris_transfer";
    return "";
  }
  function txPaymentLabel(v) {
    const m = normalizeTxPaymentMethod(v);
    if (m) return TX_PAYMENT_METHODS[m];
    const s = String(v || "").trim();
    return s || "";
  }

  function notifyAdminNewTransaction(tx = {}) {
    try {
      if (!ROCKY_ADMIN_NOTIFY_WORKER_URL || !ROCKY_ADMIN_NOTIFY_SECRET) return;
      const amount = Number(tx.amount || 0);
      const staffName = String(
        tx.name ||
          tx.user ||
          state.user?.name ||
          state.user?.username ||
          "Staff",
      );
      const note = String(tx.note || "Transaksi baru");
      return notifyRockyAdmin(
        ROCKY_ADMIN_NOTIFY_WORKER_URL,
        {
          type: "transaction",
          title: "Transaksi Baru",
          staff: staffName,
          user: staffName,
          username: String(tx.user || state.user?.username || ""),
          name: staffName,
          amount,
          note,
          paymentMethod: String(tx.paymentMethod || ""),
          paymentLabel: String(
            tx.paymentLabel || txPaymentLabel(tx.paymentMethod) || "",
          ),
          transactionId: String(tx.id || tx.clientId || ""),
          dateKey: String(tx.dateKey || todayKey()),
          source: "staff_cashier",
          app: "Aplikasi_KASIR_STAF_ROCKY",
          createdAt: new Date().toISOString(),
        },
        "Notif transaksi admin",
      );
    } catch (err) {
      console.warn("Notif admin gagal:", err?.message || err);
    }
  }

  async function notifyRockyAdmin(url, payload = {}, label = "Notif admin") {
    let timeout = null;
    try {
      if (!url || !ROCKY_ADMIN_NOTIFY_SECRET) return null;
      const controller =
        typeof AbortController !== "undefined" ? new AbortController() : null;
      if (controller) timeout = setTimeout(() => controller.abort(), 4500);
      const r = await fetch(url, {
        method: "POST",
        keepalive: true,
        headers: {
          "Content-Type": "application/json",
          "X-Notify-Secret": ROCKY_ADMIN_NOTIFY_SECRET,
        },
        body: JSON.stringify({ ...payload, secret: ROCKY_ADMIN_NOTIFY_SECRET }),
        signal: controller ? controller.signal : undefined,
      });
      const data = await r.json().catch(() => null);
      if (!r.ok || data?.ok === false)
        console.warn(label + " gagal:", data || r.status);
      return data;
    } catch (err) {
      console.warn(label + " gagal:", err?.message || err);
      return null;
    } finally {
      if (timeout) clearTimeout(timeout);
    }
  }
  function notifyAdminAttendance(att = {}, action = "masuk") {
    try {
      const createdMs = Number(att.createdAtMs || ms(att) || Date.now());
      const staffName = String(
        att.name ||
          state.user?.name ||
          att.user ||
          state.user?.username ||
          "Staff",
      );
      return notifyRockyAdmin(
        ROCKY_ADMIN_NOTIFY_ATTENDANCE_URL,
        {
          type: "attendance",
          staff: staffName,
          user: staffName,
          username: String(att.user || state.user?.username || ""),
          name: staffName,
          action: String(action || "masuk"),
          time: String(att.time || timeID(createdMs) || timeNow()),
          dateKey: String(att.dateKey || todayKey(new Date(createdMs))),
          attendanceId: String(att.id || att.clientId || ""),
          source: "staff",
          note: String(att.note || "Absen dari aplikasi staff"),
        },
        "Notif absen admin",
      );
    } catch (err) {
      console.warn("Notif absen admin gagal:", err?.message || err);
      return null;
    }
  }
  function notifyAdminTransactionDelete(tx = {}) {
    try {
      const staffName = String(
        tx.deletedByName ||
          state.user?.name ||
          tx.name ||
          tx.user ||
          state.user?.username ||
          "Staff",
      );
      const ownerName = String(tx.name || tx.user || "");
      const paymentLabel = String(
        tx.paymentLabel || txPaymentLabel(tx.paymentMethod) || tx.payment || "",
      );
      const amount = Number(tx.amount || 0);
      const desc = String(tx.note || tx.desc || "Transaksi");
      return notifyRockyAdmin(
        ROCKY_ADMIN_NOTIFY_TRANSACTION_DELETE_URL,
        {
          type: "delete_transaction",
          title: "Transaksi Dihapus",
          staff: staffName,
          user: staffName,
          username: String(
            tx.deletedBy || state.user?.username || tx.user || "",
          ),
          name: staffName,
          deletedBy: staffName,
          targetUser: ownerName,
          transactionUser: ownerName,
          amount,
          desc,
          note: desc,
          payment: String(paymentLabel || tx.paymentMethod || ""),
          paymentMethod: String(tx.paymentMethod || ""),
          paymentLabel,
          transactionId: String(tx.id || tx.clientId || ""),
          dateKey: String(tx.dateKey || txDate(tx) || todayKey()),
          time: timeNow(),
          source: "staff",
        },
        "Notif hapus transaksi admin",
      );
    } catch (err) {
      console.warn("Notif hapus transaksi admin gagal:", err?.message || err);
      return null;
    }
  }
  function openTxLegacy(draft = {}) {
    if (!state.user) return;
    if (!canTx()) return toast(txBlockedMessage());
    primeAppSounds();
    const defaultNote = String(draft?.note || "");
    const defaultAmount = Number(draft?.amount || 0);
    const amountValue = defaultAmount > 0 ? `Rp ${rp(defaultAmount)}` : "";
    modal(
      "Transaksi Baru",
      `<div class="tx-chip"><span>⚡ Input cepat</span><b>${timeNow()} WIB</b></div><div class="field"><div class="label">Nama Produk</div><textarea id="txn" class="tx-product-input" placeholder="Produk...&#10;&#10;&#10;" autocomplete="off" rows="4">${esc(defaultNote)}</textarea></div><div class="field"><div class="label">Nominal Rupiah</div><input id="txa" class="tx-amount-input" type="tel" inputmode="numeric" pattern="[0-9]*" placeholder="Rp 0" value="${esc(amountValue)}" oninput="formatRupiahInput(this)" style="text-align:right;font-size:25px;font-weight:950"></div><div class="tx-note-mini">Klik <b>Simpan</b> atau <b>Cetak</b>, lalu pilih metode pembayaran dulu. Transaksi baru dianggap sukses setelah memilih <b>Cash</b> atau <b>QRIS / Transfer</b>.</div>`,
      `<div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;width:100%"><button type="button" class="btn danger" onpointerdown="closeModal(true);event.preventDefault()" ontouchstart="closeModal(true);event.preventDefault()" onclick="closeModal(true)" style="grid-column:1 / -1">Batal</button><button class="btn success" onclick="saveTx(true)" style="background:var(--green);border-color:var(--green);color:#fff">Cetak</button><button class="btn primary" onclick="saveTx(false)">Simpan</button></div>`,
      "tx-modal",
    );
  }
  function openTx(draft = {}) {
    if (!state.user) return;
    if (!canTx()) return toast(txBlockedMessage());
    primeAppSounds();
    const defaultNote = String(draft?.note || "").trim();
    txProductDraftItems =
      defaultNote && defaultNote !== "Transaksi"
        ? txProductItemsFromText(defaultNote, "Transaksi")
        : [];
    const defaultAmount = Number(draft?.amount || 0);
    const amountValue = defaultAmount > 0 ? `Rp ${rp(defaultAmount)}` : "";
    const isEdit = !!draft?.editId;
    const body = `<div class="tx-chip"><span>Input cepat</span><b>${timeNow()} WIB</b></div>
    <div class="field tx-product-builder" style="position:relative">
      <div class="label">Rincian Barang</div>
      <form class="tx-product-entry" style="grid-template-columns: minmax(0,1fr) 50px auto !important; margin:0" onsubmit="event.preventDefault(); addTxProductItem(); return false;">
        <input id="txProductInput" class="tx-product-input" type="text" placeholder="Nama barang..." autocomplete="off" oninput="updateTxProductAddButton()" onkeydown="handleTxProductKey(event)" >
        <input id="txProductQty" class="tx-product-input input" type="number" inputmode="numeric" min="1" value="1" placeholder="Qty" style="text-align:center;padding:0 !important" onfocus="hideTxProductSuggest(); this.select()" onkeydown="handleTxProductKey(event)">
        <button id="txAddProductBtn" type="submit" class="btn primary tx-product-add" disabled>+ Tambah</button>
      </form>
      <div id="txProductSuggest" class="tx-product-suggest"></div>
      <div id="txProductList" class="tx-product-list"></div>
    </div>
    <div class="field"><div class="label">Total Bayar</div><input id="txa" class="tx-amount-input" type="tel" inputmode="numeric" pattern="[0-9]*" placeholder="Rp 0" value="${esc(amountValue)}" oninput="formatRupiahInput(this)" style="text-align:right;font-size:25px;font-weight:950"></div>
    `;
    const encodedDraft = escAttr(
      JSON.stringify({
        editId: String(draft?.editId || ""),
        createdAtMs: Number(draft?.createdAtMs || 0),
        paymentMethod: String(draft?.paymentMethod || ""),
      }),
    );
    const actions = `<div style="display:grid;grid-template-columns:1fr 1fr;gap:7px;width:100%"><button type="button" class="btn danger" onpointerdown="closeModal(true);event.preventDefault()" ontouchstart="closeModal(true);event.preventDefault()" onclick="closeModal(true)" style="grid-column:1 / -1">Batal</button><button class="btn success" onclick="saveTx(true,'',JSON.parse(this.dataset.draft||'{}'))" data-draft="${encodedDraft}" style="background:var(--green);border-color:var(--green);color:#fff">Cetak</button><button class="btn primary" onclick="saveTx(false,'',JSON.parse(this.dataset.draft||'{}'))" data-draft="${encodedDraft}">${isEdit ? "Update" : "Simpan"}</button></div>`;
    modal(
      isEdit ? "Edit Transaksi" : "Transaksi Baru",
      body,
      actions,
      "tx-modal",
    );
    setTimeout(() => {
      renderTxProductDraft();
      $("txProductInput")?.focus?.();
      // Setup click-outside handler untuk hide suggest dropdown
      function txSuggestOutsideHandler(e) {
        const floater = document.getElementById("txProductSuggestFloater");
        const input = $("txProductInput");
        if (!input) { document.removeEventListener("pointerdown", txSuggestOutsideHandler, true); return; }
        if (floater && !floater.contains(e.target) && e.target !== input) {
          txProductSuggestTouching = false;
          hideTxProductSuggest();
        }
      }
      document.removeEventListener("pointerdown", txSuggestOutsideHandler, true);
      document.addEventListener("pointerdown", txSuggestOutsideHandler, true);
    }, 30);
  }
  function openTxPaymentChoice(draft) {
    txPaymentSubmitting = false;
    pendingTxDraft = {
      printAfterSave: Boolean(draft?.printAfterSave),
      amount: Number(draft?.amount || 0),
      note: String(draft?.note || "Transaksi").trim() || "Transaksi",
      editId: String(draft?.editId || ""),
      createdAtMs: Number(draft?.createdAtMs || 0),
      paymentMethod: String(draft?.paymentMethod || ""),
    };
    modal(
      "Pilih Pembayaran",
      `<div class="payment-simple-choices"><button type="button" data-payment-choice="cash" class="payment-simple-btn payment-simple-cash" onpointerdown="confirmTxPayment('cash',this,event)" ontouchstart="confirmTxPayment('cash',this,event)" onclick="confirmTxPayment('cash',this,event)"><span>Cash</span></button><button type="button" data-payment-choice="qris_transfer" class="payment-simple-btn payment-simple-qris" onpointerdown="confirmTxPayment('qris_transfer',this,event)" ontouchstart="confirmTxPayment('qris_transfer',this,event)" onclick="confirmTxPayment('qris_transfer',this,event)"><span>Qris / Transfer</span></button></div>`,
      ``,
      "tx-modal payment-picker-modal",
    );
  }

  function cancelTxPaymentChoice() {
    txPaymentSubmitting = false;
    pendingTxDraft = null;
    closeModal(true);
  }
  function reopenTxDraft() {
    txPaymentSubmitting = false;
    const draft = pendingTxDraft ? { ...pendingTxDraft } : {};
    openTx(draft);
  }
  async function confirmTxPayment(paymentMethod, btn, event) {
    try {
      if (event && typeof event.preventDefault === "function")
        event.preventDefault();
    } catch (e) {}
    try {
      if (event && typeof event.stopPropagation === "function")
        event.stopPropagation();
    } catch (e) {}
    if (txPaymentSubmitting) return;
    txPaymentSubmitting = true;
    const buttons = [...document.querySelectorAll("[data-payment-choice]")];
    buttons.forEach((b) => {
      b.disabled = true;
      b.setAttribute("aria-busy", "true");
      b.style.opacity = ".72";
    });
    if (btn) {
      btn.dataset.originalText = btn.dataset.originalText || btn.textContent;
      btn.textContent = "Menyimpan...";
    }
    const draft = pendingTxDraft ? { ...pendingTxDraft } : null;
    if (!draft) {
      txPaymentSubmitting = false;
      buttons.forEach((b) => {
        b.disabled = false;
        b.removeAttribute("aria-busy");
        b.style.opacity = "";
        if (b.dataset.originalText) b.textContent = b.dataset.originalText;
      });
      return toast("Data transaksi tidak ditemukan. Isi ulang transaksi.");
    }
    try {
      await saveTx(Boolean(draft.printAfterSave), paymentMethod, draft);
    } finally {
      txPaymentSubmitting = false;
      document.querySelectorAll("[data-payment-choice]").forEach((b) => {
        b.disabled = false;
        b.removeAttribute("aria-busy");
        b.style.opacity = "";
        if (b.dataset.originalText) b.textContent = b.dataset.originalText;
      });
    }
  }
  async function saveTx(
    printAfterSave = false,
    paymentMethod = "",
    draft = null,
  ) {
    primeAppSounds();
    const amount = Number(draft?.amount || onlyDigits($("txa")?.value)),
      note = txProductTextFromItems(
        txProductItemsFromText(
          String(draft?.note ?? txProductDraftText()).trim(),
          "Transaksi",
        ),
        "Transaksi",
      );
    const editId = String(draft?.editId || "");
    const editTx = editId ? findTxById(editId) : null;
    if (!amount || amount <= 0) return toast("Nominal wajib diisi");
    if (editId) {
      if (!editTx) return toast("Transaksi edit tidak ditemukan");
      if (editTx.pending === true)
        return toast("Transaksi masih menunggu sync");
      if (txDate(editTx) !== todayKey())
        return toast("Hanya transaksi hari ini yang bisa diedit");
      if (key(editTx.user) !== key(state.user?.username))
        return toast("Tidak bisa edit transaksi orang lain");
    }
    if (!paymentMethod) {
      if (!canTx()) {
        closeModal();
        return toast(txBlockedMessage());
      }
      return openTxPaymentChoice({
        printAfterSave,
        amount,
        note,
        editId,
        createdAtMs: Number(draft?.createdAtMs || editTx?.createdAtMs || 0),
        paymentMethod: String(
          draft?.paymentMethod || editTx?.paymentMethod || "",
        ),
      });
    }
    const payment = normalizeTxPaymentMethod(paymentMethod);
    if (!payment) return toast("Pilih Cash atau QRIS / Transfer dulu");
    const paymentText = txPaymentLabel(payment);
    pendingTxDraft = null;
    if (!canTx()) {
      closeModal();
      return toast(txBlockedMessage());
    }
    showLoad(true);
    const verified = await verifyTransactionAllowedServer(todayKey());
    if (!verified.ok) {
      showLoad(false);
      closeModal();
      return toast(verified.msg || "Transaksi ditolak. Cek absen ulang.");
    }
    const latest = await latestBonusSnapshotForSave();
    showLoad(false);
    if (!latest.ok)
      return toast(
        latest.msg || "Gagal cek bonus terbaru. Transaksi belum disimpan.",
      );
    const firstTxToday = !editId && isFirstTxPartyDue();
    const now = Date.now(),
      u = key(latest.user.username || state.user.username),
      id =
        editId ||
        "stafftx_" +
          u +
          "_" +
          now +
          "_" +
          Math.random().toString(36).slice(2, 7);
    const userRole = latest.userRole;
    const txRate = latest.txRate;
    const txPercent = latest.txPercent;
    const closingSnapshot = latest.closingSnapshot;
    const payload = {
      user: u,
      name: latest.user.name || state.user.name || u,
      amount,
      note,
      paymentMethod: payment,
      paymentLabel: paymentText,
      paymentStatus: "success",
      paymentCashOutType: payment === "qris_transfer" ? "qris" : "",
      isNonCashPayment: payment === "qris_transfer",
      paymentConfirmed: true,
      paymentConfirmedAtMs: now,
      notifyAdmin: true,
      notificationType: "staff_transaction",
      notificationStatus: "pending",
      dateKey: todayKey(),
      monthKey: monthKey(),
      userRole,
      role: userRole,
      bonusGroup: userRole === "harian" ? "harian" : "staff",
      bonusRate: txRate,
      bonusPercent: txPercent,
      transactionBonusRate: txRate,
      transactionBonusPercent: txPercent,
      closingBonusPerMinuteSnapshot: closingSnapshot,
      bonusLogicVersion: 3,
      ...trialRecordFlags(latest.user || state.user),
      createdAtMs: now,
      deleted: false,
      createdBy: u,
      clientId: id,
      source: "trx_staff_bonus_per_user_check_on_save",
    };
    if (editId) {
      const {
        createdAtMs,
        createdBy,
        notifyAdmin,
        notificationType,
        notificationStatus,
        ...editCore
      } = payload;
      const editPatch = {
        ...editCore,
        source: editTx.source || payload.source,
        clientId: editTx.clientId || payload.clientId,
        createdAtMs: Number(editTx.createdAtMs || createdAtMs || now),
        createdBy: editTx.createdBy || u,
        updatedAtMs: now,
        updatedBy: u,
        updatedByName: latest.user.name || state.user.name || u,
      };
      closeModal();
      try {
        await setDoc(
          doc(db, "transactions", editId),
          {
            ...editPatch,
            updatedAt: serverTimestamp(),
            syncedAt: serverTimestamp(),
            syncedAtMs: Date.now(),
          },
          { merge: true },
        );
        const savedTx = { ...editTx, ...editPatch, id: editId, pending: false };
        state.data.tx = state.data.tx.map((t) =>
          String(t.id) === String(editId) ? savedTx : t,
        );
        state.data.targetTx = mergeRowsById(state.data.targetTx, [savedTx]);
        await logAudit("transaction_update", {
          id: editId,
          user: u,
          amount,
          note,
          paymentMethod: payment,
          paymentLabel: paymentText,
        });
        syncDailyTargetState();
        scheduleDailyTargetCheck();
        render();
        if (printAfterSave) {
          toast(`Transaksi ${paymentText} diupdate, mencetak struk`);
          setTimeout(
            () =>
              directPrintReceiptText(
                receiptTextForTx(savedTx),
                "Struk Transaksi",
              ),
            120,
          );
        } else {
          toast(`Transaksi diupdate via ${paymentText}`);
        }
      } catch (e) {
        console.error(e);
        toast("Gagal update transaksi: " + (e.message || e));
      }
      return;
    }
    const local = { id, ...payload, pending: true };
    closeModal();
    state.data.tx = [local, ...state.data.tx];
    render();
    try {
      await setDoc(
        doc(db, "transactions", id),
        {
          ...payload,
          createdAt: serverTimestamp(),
          syncedAt: serverTimestamp(),
          syncedAtMs: Date.now(),
        },
        { merge: false },
      );
      const savedTx = { id, ...payload, pending: false };
      state.data.tx = state.data.tx.map((t) => (t.id === id ? savedTx : t));
      removePending(id);
      playSuccessSound();
      await logAudit("transaction_create", {
        id,
        user: u,
        amount,
        note,
        paymentMethod: payment,
        paymentLabel: paymentText,
      });
      if (!isTrialRecord(savedTx)) notifyAdminNewTransaction(savedTx);
      state.data.targetTx = mergeRowsById(state.data.targetTx, [savedTx]);
      syncDailyTargetState();
      scheduleDailyTargetCheck();
      render();
      if (firstTxToday) showFirstTxParty(amount, note);
      if (printAfterSave) {
        toast(`Transaksi ${paymentText} tersimpan, mencetak struk`);
        setTimeout(
          () =>
            directPrintReceiptText(
              receiptTextForTx(savedTx),
              "Struk Transaksi Baru",
            ),
          120,
        );
      } else {
        toast(`Transaksi sukses via ${paymentText}`);
      }
    } catch (e) {
      console.error(e);
      if (isPermissionError(e)) {
        state.data.tx = state.data.tx.filter((t) => t.id !== id);
        state.syncError = "Akses Firebase menolak transaksi.";
        toast("Akses Firebase menolak transaksi");
      } else {
        state.data.tx = state.data.tx.filter((t) => t.id !== id);
        state.syncError =
          "Transaksi gagal tersimpan. Cek koneksi, lalu coba simpan ulang.";
        toast("Gagal menyimpan. Transaksi staff wajib online.");
      }
      render();
    }
  }
  async function delTx(id) {
    const t = state.data.tx.find((x) => String(x.id) === String(id));
    if (!t) return toast("Transaksi tidak ditemukan");
    if (key(t.user) !== key(state.user.username))
      return toast("Tidak bisa hapus transaksi orang lain");
    const p = await pinAsk(`Hapus transaksi Rp ${rp(t.amount)}?`);
    if (!p) return;
    if (String(p) !== String(state.user.pin)) return toast("PIN salah");
    showLoad(true);
    try {
      await setDoc(
        doc(db, "transactions", id),
        {
          deleted: true,
          deletedAt: serverTimestamp(),
          deletedAtMs: Date.now(),
          deletedBy: state.user.username,
          deletedByName: state.user.name,
        },
        { merge: true },
      );
      state.data.tx = state.data.tx.map((x) =>
        String(x.id) === String(id)
          ? {
              ...x,
              deleted: true,
              deletedAtMs: Date.now(),
              deletedBy: state.user.username,
              deletedByName: state.user.name,
            }
          : x,
      );
      state.data.targetTx = state.data.targetTx.map((x) =>
        String(x.id) === String(id)
          ? {
              ...x,
              deleted: true,
              deletedAtMs: Date.now(),
              deletedBy: state.user.username,
              deletedByName: state.user.name,
            }
          : x,
      );
      syncDailyTargetState();
      scheduleDailyTargetCheck();
      await logAudit("transaction_soft_delete", {
        id,
        user: t.user,
        amount: Number(t.amount || 0),
        note: t.note || "Transaksi",
      });
      await notifyAdminTransactionDelete({
        ...t,
        id,
        deletedBy: state.user.username,
        deletedByName: state.user.name,
      });
      toast("Transaksi dihapus aman");
    } catch (e) {
      console.error(e);
      toast(
        isPermissionError(e)
          ? "Akses Firebase menolak hapus"
          : "Gagal hapus transaksi",
      );
    }
    showLoad(false);
    render();
  }
  function getPosition() {
    return new Promise((res, rej) => {
      if (!navigator.geolocation) return rej(new Error("GPS tidak tersedia"));
      navigator.geolocation.getCurrentPosition(
        (p) =>
          res({
            lat: p.coords.latitude,
            lng: p.coords.longitude,
            accuracy: p.coords.accuracy || 0,
          }),
        (e) => rej(e),
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 },
      );
    });
  }
  function distance(a, b, c, d) {
    const R = 6371000,
      rad = (x) => (x * Math.PI) / 180,
      da = rad(c - a),
      db = rad(d - b),
      x =
        Math.sin(da / 2) ** 2 +
        Math.cos(rad(a)) * Math.cos(rad(c)) * Math.sin(db / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
  }
  async function updateLocation() {
    try {
      state.pos = await getPosition();
      render();
    } catch (e) {
      toast("GPS gagal / izin lokasi ditolak");
    }
  }
  async function serverAttendanceToday(user, dateKey = todayKey()) {
    const u = key(user),
      d = String(dateKey || todayKey()).slice(0, 10),
      docId = attendanceDocId(u, d);
    try {
      const direct = await getDocFromServer(doc(db, "attendance", docId));
      if (direct.exists()) return { id: direct.id, ...direct.data() };
    } catch (e) {
      console.warn("cek absen direct gagal", e?.code || e);
    }
    try {
      const snap = await getDocsFromServer(
        query(
          collection(db, "attendance"),
          where("user", "==", u),
          where("dateKey", "==", d),
          limit(10),
        ),
      );
      const rows = snap.docs
        .map((x) => ({ id: x.id, ...x.data() }))
        .filter((a) => !deleted(a) && key(a.user) === u && attDate(a) === d);
      if (rows.length) return sortDesc(rows)[0];
    } catch (e) {
      console.warn("cek absen tanggal gagal", e?.code || e);
    }
    return null;
  }
  async function clockIn() {
    if (clockInInFlight || state.busy) return toast("Absen sedang diproses");
    if (!state.user) return toast("Silakan login ulang");
    if (isRismaSpecialUser())
      return toast("Risma tidak perlu absen. Transaksi sudah terbuka.");
    const u = key(state.user.username),
      d = todayKey(),
      id = attendanceDocId(u, d);
    const lock = missedAttendanceLockForDate(d);
    if (lock) return toast(missedAttendanceLockText(lock, "absen"));
    if (todayAtt()) return toast("Sudah absen hari ini");
    clockInInFlight = true;
    let pos = state.pos;
    try {
      if (!(await validateCurrentDeviceSession({ silent: true, force: true })))
        return;
      const unlockCheck = await verifyAbsenceOpenServer(d, "absen");
      if (!unlockCheck.ok) return toast(unlockCheck.msg);
      const existing = await serverAttendanceToday(u, d);
      if (existing) {
        state.data.att = dedupeAttendanceRows([
          { id: existing.id, ...existing },
          ...state.data.att,
        ]);
        state.data.targetAtt = dedupeAttendanceRows([
          { id: existing.id, ...existing },
          ...state.data.targetAtt,
        ]);
        syncDailyTargetState();
        render();
        return toast("Sudah absen hari ini");
      }
      try {
        if (!pos) pos = await getPosition();
        state.pos = pos;
      } catch (e) {
        return toast("GPS gagal / izin lokasi ditolak");
      }
      const dist = distance(pos.lat, pos.lng, OFFICE_LOC.lat, OFFICE_LOC.lng);
      if (dist > RADIUS_LIMIT)
        return toast(`Diluar radius (${Math.round(dist)}m)`);
      showLoad(true);
      const now = Date.now();
      const payload = {
        user: u,
        name: state.user.name || u,
        dateKey: d,
        monthKey: d.slice(0, 7),
        createdAtMs: now,
        loc: pos,
        lat: pos.lat,
        lng: pos.lng,
        ...trialRecordFlags(state.user),
        deleted: false,
        clientId: id,
        source: "trx_staff_sesuai_index",
      };
      const local = { id, ...payload, pending: true };
      state.data.att = dedupeAttendanceRows([local, ...state.data.att]);
      render();
      await setDoc(
        doc(db, "attendance", id),
        {
          ...payload,
          createdAt: serverTimestamp(),
          syncedAt: serverTimestamp(),
          syncedAtMs: Date.now(),
        },
        { merge: true },
      );
      state.data.att = dedupeAttendanceRows(
        state.data.att.map((a) => (a.id === id ? { ...a, pending: false } : a)),
      );
      state.data.targetAtt = dedupeAttendanceRows([
        { id, ...payload, pending: false },
        ...state.data.targetAtt,
      ]);
      syncDailyTargetState();
      removePending(id);
      if (!isTrialRecord(payload))
        await notifyAdminAttendance(
          { id, ...payload, pending: false },
          "masuk",
        );
      toast("Absen berhasil");
    } catch (e) {
      console.error(e);
      if (isPermissionError(e)) {
        state.data.att = state.data.att.filter((a) => a.id !== id);
        state.syncError = "Akses Firebase menolak absen.";
        toast("Akses Firebase menolak absen");
      } else {
        const now = Date.now();
        const payload = {
          user: u,
          name: state.user.name || u,
          dateKey: d,
          monthKey: d.slice(0, 7),
          createdAtMs: now,
          loc: pos || null,
          lat: pos?.lat || null,
          lng: pos?.lng || null,
          ...trialRecordFlags(state.user),
          deleted: false,
          clientId: id,
          source: "trx_staff_sesuai_index",
        };
        state.data.att = dedupeAttendanceRows([
          { id, ...payload, pending: true },
          ...state.data.att,
        ]);
        state.data.targetAtt = dedupeAttendanceRows([
          { id, ...payload, pending: true },
          ...state.data.targetAtt,
        ]);
        syncDailyTargetState();
        addPending({ type: "att_add", id, user: u, payload, createdAtMs: now });
        toast("Koneksi gagal. Absen disimpan lokal & akan sync otomatis.");
      }
    } finally {
      showLoad(false);
      clockInInFlight = false;
      render();
    }
  }
  async function logAudit(action, detail = {}) {
    try {
      await addDoc(collection(db, "audit_logs"), {
        action,
        detail,
        user: state.user?.username || "",
        name: state.user?.name || "",
        createdAt: serverTimestamp(),
        createdAtMs: Date.now(),
      });
    } catch (e) {
      console.warn("audit skipped", e?.code || e);
    }
  }
  async function login() {
    const u = key($("lu")?.value),
      p = String($("lp")?.value || "").trim();
    if (!u || !p) return toast("Isi username dan PIN");
    showLoad(true);
    try {
      const snap = await getDocFromServer(doc(db, "users", u));
      if (!snap.exists()) throw new Error("User tidak ditemukan");
      const raw = snap.data() || {};
      const data = { id: snap.id, username: raw.username || snap.id, ...raw };
      if (isAdmin(data)) throw new Error("Aplikasi ini khusus staff");
      if (data.active === false || deleted(data))
        throw new Error("User nonaktif");
      if (String(data.pin || "") !== p) throw new Error("PIN salah");
      const lock = await verifyDeviceLockForLogin(data, u);
      if (!lock.ok) throw new Error(lock.msg);
      state.user = {
        username: key(data.username || u),
        name: data.name || u,
        pin: String(data.pin || ""),
        role: data.role || "staff",
        transactionBonusRate: hasBonusValue(data.transactionBonusRate)
          ? Number(data.transactionBonusRate)
          : null,
        transactionBonusPercent: hasBonusValue(data.transactionBonusPercent)
          ? Number(data.transactionBonusPercent)
          : null,
        closingBonusPerMinute: isDailyUser(data)
          ? 0
          : hasBonusValue(data.closingBonusPerMinute)
            ? Number(data.closingBonusPerMinute)
            : null,
        dailyBonusRate: hasBonusValue(data.dailyBonusRate)
          ? Number(data.dailyBonusRate)
          : null,
        dailyBonusPercent: hasBonusValue(data.dailyBonusPercent)
          ? Number(data.dailyBonusPercent)
          : null,
        active: data.active !== false,
        deviceId: lock.deviceId,
        deviceResetAtMs: Number(data.deviceResetAtMs || 0),
        ...trialSessionFields(data),
      };
      const saved = {
        username: state.user.username,
        name: state.user.name,
        pin: state.user.pin,
        role: state.user.role,
        transactionBonusRate: state.user.transactionBonusRate,
        transactionBonusPercent: state.user.transactionBonusPercent,
        closingBonusPerMinute: isDailyUser(state.user)
          ? 0
          : state.user.closingBonusPerMinute,
        dailyBonusRate: state.user.dailyBonusRate,
        dailyBonusPercent: state.user.dailyBonusPercent,
        active: true,
        deviceId: state.user.deviceId,
        deviceResetAtMs: state.user.deviceResetAtMs,
        ...trialSessionFields(state.user),
      };
      localStorage.setItem(SESSION, JSON.stringify(saved));
      localStorage.setItem(
        LEGACY_SESSION,
        JSON.stringify({ username: state.user.username, pin: state.user.pin }),
      );
      showLoad(false);
      await loadStaffData();
      toast(`Masuk: ${state.user.name}`);
    } catch (e) {
      console.error(e);
      showLoad(false);
      toast(e.message || "Login gagal");
      renderLogin();
    }
  }
  async function boot() {
    setTheme(getTheme());
    const raw = [];
    try {
      raw.push(JSON.parse(localStorage.getItem(SESSION) || "null"));
    } catch (e) {}
    try {
      raw.push(JSON.parse(localStorage.getItem(LEGACY_SESSION) || "null"));
    } catch (e) {}
    for (const s of raw.filter(Boolean)) {
      try {
        const username = key(s.username || s.user || s.id);
        const pin = String(s.pin || "");
        if (!username || !pin) continue;
        const snap = await getDocFromServer(doc(db, "users", username));
        if (!snap.exists()) continue;
        const rawData = snap.data() || {};
        const data = {
          id: snap.id,
          username: rawData.username || snap.id,
          ...rawData,
        };
        if (
          !isAdmin(data) &&
          data.active !== false &&
          !deleted(data) &&
          String(data.pin || "") === pin
        ) {
          if (
            !isDeviceFreeUser(data) &&
            Number(data.deviceResetAtMs || 0) > Number(s.deviceResetAtMs || 0)
          ) {
            const serverDeviceId = String(data.deviceId || "").trim();
            const thisDeviceId = getDeviceId();
            // Kalau reset lama sudah dipakai login ulang di device ini, jangan logout lagi.
            // Ini penting untuk sesi lama/legacy yang belum menyimpan deviceResetAtMs.
            if (serverDeviceId && serverDeviceId === thisDeviceId) {
              s.deviceResetAtMs = Number(data.deviceResetAtMs || 0);
              s.deviceId = serverDeviceId;
              try {
                localStorage.setItem(
                  SESSION,
                  JSON.stringify({
                    ...s,
                    deviceResetAtMs: s.deviceResetAtMs,
                    deviceId: s.deviceId,
                  }),
                );
              } catch (e) {}
            } else {
              localStorage.removeItem(SESSION);
              localStorage.removeItem(LEGACY_SESSION);
              toast(
                "Device akun ini sudah direset admin. Silakan login ulang.",
              );
              break;
            }
          }
          const lock = await verifyDeviceLockForLogin(data, username);
          if (!lock.ok) {
            localStorage.removeItem(SESSION);
            localStorage.removeItem(LEGACY_SESSION);
            toast(lock.msg);
            break;
          }
          state.user = {
            username: key(data.username || username),
            name: data.name || username,
            pin: String(data.pin || ""),
            role: data.role || "staff",
            transactionBonusRate: hasBonusValue(data.transactionBonusRate)
              ? Number(data.transactionBonusRate)
              : null,
            transactionBonusPercent: hasBonusValue(data.transactionBonusPercent)
              ? Number(data.transactionBonusPercent)
              : null,
            closingBonusPerMinute: isDailyUser(data)
              ? 0
              : hasBonusValue(data.closingBonusPerMinute)
                ? Number(data.closingBonusPerMinute)
                : null,
            dailyBonusRate: hasBonusValue(data.dailyBonusRate)
              ? Number(data.dailyBonusRate)
              : null,
            dailyBonusPercent: hasBonusValue(data.dailyBonusPercent)
              ? Number(data.dailyBonusPercent)
              : null,
            active: data.active !== false,
            deviceId: lock.deviceId,
            deviceResetAtMs: Number(data.deviceResetAtMs || 0),
            ...trialSessionFields(data),
          };
          const saved = {
            username: state.user.username,
            name: state.user.name,
            pin: state.user.pin,
            role: state.user.role,
            transactionBonusRate: state.user.transactionBonusRate,
            transactionBonusPercent: state.user.transactionBonusPercent,
            closingBonusPerMinute: isDailyUser(state.user)
              ? 0
              : state.user.closingBonusPerMinute,
            dailyBonusRate: state.user.dailyBonusRate,
            dailyBonusPercent: state.user.dailyBonusPercent,
            active: true,
            deviceId: state.user.deviceId,
            deviceResetAtMs: state.user.deviceResetAtMs,
            ...trialSessionFields(state.user),
          };
          localStorage.setItem(SESSION, JSON.stringify(saved));
          localStorage.setItem(
            LEGACY_SESSION,
            JSON.stringify({
              username: state.user.username,
              pin: state.user.pin,
            }),
          );
          await loadStaffData();
          return;
        }
      } catch (e) {
        console.warn(e);
      }
    }
    localStorage.removeItem(SESSION);
    localStorage.removeItem(LEGACY_SESSION);
    renderLogin();
  }
  function logout() {
    clearSessionAndRender("");
  }
  function canAppBack() {
    return !!state.user && state.page !== "home";
  }
  function syncAppBrowserHistory(p, mode = "push") {
    try {
      const url =
        location.pathname +
        location.search +
        "#" +
        encodeURIComponent(p || "home");
      const data = { rockyApp: true, page: p || "home" };
      if (mode === "replace") history.replaceState(data, "", url);
      else history.pushState(data, "", url);
    } catch (e) {}
  }
  function go(p, opts = {}) {
    p = p === "leave" ? "unlock" : p;
    p = p === "history" || p === "unlock" ? p : "home";
    if (state.page === p) {
      render();
      return;
    }
    state.page = p;
    syncAppBrowserHistory(p, opts.replace ? "replace" : "push");
    render();
  }
  function appBack(opts = {}) {
    const silentHome = !!(opts && opts.silentHome);
    const source = opts && opts.source ? String(opts.source) : "";
    try {
      closeModal();
    } catch (e) {}
    if (!state.user) return false;
    if (state.page !== "home") {
      state.page = "home";
      syncAppBrowserHistory("home", "push");
      render();
      return true;
    }
    syncAppBrowserHistory("home", "replace");
    if (source === "nativeBack") return false;
    if (!silentHome) toast("Sudah di halaman utama");
    return true;
  }
  function installSafeBackNavigation() {
    if (window.__ROCKY_SAFE_BACK_INSTALLED__) return;
    window.__ROCKY_SAFE_BACK_INSTALLED__ = true;
    syncAppBrowserHistory(state.page || "home", "replace");
    window.addEventListener("popstate", () => {
      if (document.querySelector(".modal-wrap.show")) {
        try {
          closeModal();
        } catch (e) {}
        syncAppBrowserHistory(state.page || "home", "push");
        return;
      }
      if (state.user && state.page !== "home") {
        state.page = "home";
        render();
        syncAppBrowserHistory("home", "push");
        return;
      }
      if (state.user) {
        toast("Gunakan tombol Keluar untuk logout");
        syncAppBrowserHistory(state.page || "home", "push");
      }
    });
  }
  function installSwipeBack() {
    if (window.__ROCKY_SWIPE_BACK_INSTALLED__) return;
    window.__ROCKY_SWIPE_BACK_INSTALLED__ = true;
    const hint = $("swipeBackHint");
    const ptr = {
      active: false,
      startX: 0,
      startY: 0,
      lastX: 0,
      lastY: 0,
      ready: false,
    };
    const blocked = (t) =>
      t &&
      t.closest &&
      t.closest("input,textarea,select,button,a,.modal-wrap,.nav");
    const showHint = (show) => {
      if (!hint) return;
      hint.classList.toggle("show", !!show);
    };
    const reset = () => {
      ptr.active = false;
      ptr.ready = false;
      showHint(false);
      if (page) {
        page.style.transition = "";
        page.style.transform = "";
        page.style.willChange = "";
      }
    };
    document.addEventListener(
      "touchstart",
      (e) => {
        if (!state.user || state.page === "home" || e.touches.length !== 1)
          return;
        if (document.querySelector(".modal-wrap.show")) return;
        if (blocked(e.target)) return;
        const t = e.touches[0];
        ptr.active = true;
        ptr.ready = false;
        ptr.startX = t.clientX;
        ptr.startY = t.clientY;
        ptr.lastX = t.clientX;
        ptr.lastY = t.clientY;
        if (page) page.style.willChange = "transform";
      },
      { passive: true },
    );
    document.addEventListener(
      "touchmove",
      (e) => {
        if (!ptr.active || e.touches.length !== 1) return;
        const t = e.touches[0],
          dx = t.clientX - ptr.startX,
          dy = t.clientY - ptr.startY;
        ptr.lastX = t.clientX;
        ptr.lastY = t.clientY;
        if (Math.abs(dy) > 42 && Math.abs(dy) > Math.abs(dx)) {
          reset();
          return;
        }
        if (dx < -14 && Math.abs(dx) > Math.abs(dy) * 1.25) {
          e.preventDefault();
          const move = Math.max(-64, dx * 0.28);
          ptr.ready = dx < -74;
          showHint(ptr.ready);
          if (page) {
            page.style.transition = "";
            page.style.transform = `translateX(${move}px)`;
          }
        }
      },
      { passive: false },
    );
    document.addEventListener(
      "touchend",
      () => {
        if (!ptr.active) return;
        const dx = ptr.lastX - ptr.startX,
          dy = ptr.lastY - ptr.startY,
          ok = ptr.ready && dx < -74 && Math.abs(dx) > Math.abs(dy) * 1.35;
        reset();
        if (ok) appBack({ silentHome: true, source: "swipe" });
      },
      { passive: true },
    );
    document.addEventListener("touchcancel", reset, { passive: true });
  }
  async function refresh() {
    const now = Date.now();
    if (now - lastManualRefreshAt < REFRESH_COOLDOWN_MS) {
      const wait = Math.ceil(
        (REFRESH_COOLDOWN_MS - (now - lastManualRefreshAt)) / 1000,
      );
      return toast(`Tunggu ${wait} detik sebelum refresh lagi`);
    }
    lastManualRefreshAt = now;
    const changed = await checkDateChange();
    if (!changed) {
      await flushPending();
      await loadStaffData({ skipFlush: true });
      // Reload Cash Fisik (Ops/QRIS/Tabungan) — realtime channel bisa mati diam-diam di WebView
      if (window.loadAdminTransactions) await window.loadAdminTransactions();
    }
    toast("Data diperbarui");
  }

  // === FULL SYNC: tap sekali = sync semua tanpa cooldown ===
  let _fullSyncing = false;
  async function fullSync() {
    if (_fullSyncing || !state.user) return;
    _fullSyncing = true;
    const btn = document.querySelector(".sync-header-btn");
    if (btn) btn.classList.add("syncing");
    toast("Sinkronisasi semua data...");
    try {
      // 1) Flush pending offline data ke server
      await flushPending();
      // 2) Matikan realtime lama, paksa subscribe ulang
      clearStaffRealtime();
      // 3) Reload semua data dari server (termasuk user profile, bonus, absen, dll)
      await loadStaffData({ skipFlush: true });
      // 4) Reload cash drawer & daily target
      const d = todayKey();
      await loadCashDrawerStatus(d).catch(() => null);
      await loadDrawerWithdrawals(d).catch(() => null);
      await loadDailyTargetData({ apply: true }).catch(() => null);
      // 4b) Reload Cash Fisik (Ops/QRIS/Tabungan) — ini yang sebelumnya kelewat di fullSync,
      //     jadi kalau realtime admin_tx_realtime diam-diam mati, data tetap ke-refresh manual.
      if (window.loadAdminTransactions) await window.loadAdminTransactions();
      // 5) Reload master produk jika ada
      if (typeof loadMasterProduk === "function") {
        loadMasterProduk().catch(() => {});
      }
      state.lastSyncMs = Date.now();
      state.syncError = "";
      render();
      toast("✓ Semua data berhasil disinkronkan");
    } catch (e) {
      console.error("fullSync error:", e);
      toast("Gagal sync. Coba lagi atau buka Pusat Sinkronisasi.");
    } finally {
      _fullSyncing = false;
      if (btn) btn.classList.remove("syncing");
    }
  }

  // === PUSAT SINKRONISASI MODAL ===
  function syncCenterRealtimeStatus() {
    const active = staffRealtimeUnsubs.length > 0;
    const online = navigator.onLine !== false;
    if (!online) return { dot: "offline", text: "Offline" };
    if (active) return { dot: "live", text: "Aktif" };
    return { dot: "idle", text: "Tidak Aktif" };
  }

  function showSyncCenter() {
    const pc = pendingForUser().length;
    const rt = syncCenterRealtimeStatus();
    const lastSync = state.lastSyncMs
      ? syncTimeText()
      : "Belum pernah";
    const channelCount = staffRealtimeUnsubs.length;
    const syncErr = state.syncError
      ? `<div style="margin-top:6px;padding:6px 10px;border-radius:8px;background:var(--red-light);border:1px solid var(--red-mid);color:var(--red);font-size:11px;font-weight:600">${esc(state.syncError)}</div>`
      : "";

    const body = `<div class="sync-center-body">
      <div class="sync-center-status">
        <div class="sync-status-row">
          <div class="label"><span class="sync-status-dot ${rt.dot}"></span> Realtime</div>
          <div class="value" style="color:${rt.dot === "live" ? "var(--green)" : rt.dot === "offline" ? "var(--red)" : "var(--amber)"}">${rt.text}</div>
        </div>
        <div class="sync-status-row">
          <div class="label">🔌 Channel Aktif</div>
          <div class="value">${channelCount}</div>
        </div>
        <div class="sync-status-row">
          <div class="label">📤 Data Pending</div>
          <div class="value" style="color:${pc > 0 ? "var(--amber)" : "var(--green)"}">${pc > 0 ? pc + " menunggu" : "Semua terkirim"}</div>
        </div>
        <div class="sync-status-row">
          <div class="label">🕐 Sync Terakhir</div>
          <div class="value">${esc(lastSync)}</div>
        </div>
        <div class="sync-status-row">
          <div class="label">🌐 Koneksi</div>
          <div class="value" style="color:${navigator.onLine !== false ? "var(--green)" : "var(--red)"}">${navigator.onLine !== false ? "Online" : "Offline"}</div>
        </div>
      </div>
      ${syncErr}
      <div class="sync-center-actions">
        <button class="btn sync-data" onclick="fullSync();closeModal()">
          <svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 0 1-15.2 6.5"/><path d="M3 12A9 9 0 0 1 18.2 5.5"/><path d="M18 2v4h-4"/><path d="M6 22v-4h4"/></svg>
          Sync Semua Data
        </button>
        <div class="sync-center-divider"></div>
        <button class="btn sync-reload" onclick="hardRefreshApp()">
          <svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M3 21v-5h5"/></svg>
          Reload Aplikasi
        </button>
        <button class="btn sync-force" onclick="forceUpdateApp()">
          <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/></svg>
          Force Update (Hapus Cache)
        </button>
      </div>
      <div class="sync-center-footer">
        Tap tombol <b>Sync</b> di header untuk sinkronisasi cepat.<br>
        Tahan tombol <b>Sync</b> untuk membuka panel ini.
      </div>
    </div>`;

    modal("Pusat Sinkronisasi", body);
  }

  function hardRefreshApp() {
    try {
      closeModal();
    } catch (e) {}
    toast("Memuat ulang aplikasi...");
    setTimeout(() => {
      try {
        if (window.Android && typeof window.Android.reloadApp === "function") {
          window.Android.reloadApp();
          return;
        }
      } catch (e) {}
      try {
        location.reload();
      } catch (e) {
        location.href = location.href;
      }
    }, 260);
  }

  // FORCE UPDATE: hapus cache browser lalu reload ke URL bersih (bypass cache penuh)
  async function forceUpdateApp() {
    try { closeModal(); } catch (e) {}
    toast("Menghapus cache & update aplikasi...");
    try {
      // Hapus semua Cache Storage (PWA / browser cache)
      if ("caches" in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map((k) => caches.delete(k)));
      }
      // Unregister Service Worker jika ada
      if ("serviceWorker" in navigator) {
        const regs = await navigator.serviceWorker.getRegistrations();
        await Promise.all(regs.map((r) => r.unregister()));
      }
    } catch (e) {}
    // Reload ke URL bersih (tanpa query lama) + timestamp buster
    setTimeout(() => {
      try {
        const base = location.origin + location.pathname;
        location.replace(base + "?_upd=" + Date.now());
      } catch (e) {
        location.reload(true);
      }
    }, 300);
  }

  function showForceUpdateConfirm() {
    modal(
      "Update Aplikasi",
      `<div style="padding:8px 0 4px;text-align:center">
        <div style="font-size:32px;margin-bottom:8px"></div>
        <div style="font-size:13px;color:var(--muted);line-height:1.6">
          Cache browser akan dihapus dan aplikasi dimuat ulang dari server.<br>
          <b>Gunakan ini kalau ada update dari Server</b>
        </div>
      </div>`,
      `<button class="btn" onclick="closeModal()">Batal</button>
       <button class="btn primary" onclick="forceUpdateApp()">Update Sekarang</button>`
    );
  }
  function installPullToReload() {
    if (window.__ROCKY_PULL_TO_RELOAD_INSTALLED__) return;
    window.__ROCKY_PULL_TO_RELOAD_INSTALLED__ = true;
    const indicator = document.createElement("div");
    indicator.id = "pullReloadIndicator";
    indicator.textContent = "Tarik untuk reload";
    indicator.style.cssText =
      "position:fixed;left:50%;top:10px;transform:translate(-50%,-70px);z-index:120;background:#0f172a;color:#fff;border-radius:999px;padding:8px 12px;font-size:12px;font-weight:900;box-shadow:0 10px 26px rgba(15,23,42,.25);opacity:0;transition:transform .18s ease,opacity .18s ease;pointer-events:none;white-space:nowrap";
    document.body.appendChild(indicator);
    const ptr = {
      active: false,
      startY: 0,
      ready: false,
      dist: 0,
      reloading: false,
    };
    const scrollTop = () =>
      Math.max(
        window.scrollY || 0,
        document.documentElement.scrollTop || 0,
        document.body.scrollTop || 0,
      );
    const isBlockedTarget = (target) =>
      target &&
      target.closest &&
      target.closest("input,textarea,select,button,a,.modal-wrap,.nav");
    const resetPull = () => {
      ptr.active = false;
      ptr.ready = false;
      ptr.dist = 0;
      indicator.textContent = "Tarik untuk reload";
      indicator.style.opacity = "0";
      indicator.style.transform = "translate(-50%,-70px)";
      if (page) {
        page.style.transition = "transform .18s ease";
        page.style.transform = "translateY(0)";
        setTimeout(() => {
          try {
            page.style.transition = "";
            page.style.willChange = "";
          } catch (e) {}
        }, 220);
      }
    };
    document.addEventListener(
      "touchstart",
      (e) => {
        if (ptr.reloading || state.busy || e.touches.length !== 1) return;
        if (scrollTop() > 0) return;
        if (document.querySelector(".modal-wrap.show")) return;
        if (isBlockedTarget(e.target)) return;
        ptr.active = true;
        ptr.ready = false;
        ptr.startY = e.touches[0].clientY;
        ptr.dist = 0;
        if (page) {
          page.style.willChange = "transform";
        }
      },
      { passive: true },
    );
    document.addEventListener(
      "touchmove",
      (e) => {
        if (!ptr.active || ptr.reloading || e.touches.length !== 1) return;
        const dy = e.touches[0].clientY - ptr.startY;
        if (dy <= 0) {
          resetPull();
          return;
        }
        if (scrollTop() > 0) {
          resetPull();
          return;
        }
        if (dy > 8) e.preventDefault();
        ptr.dist = Math.min(78, dy * 0.55);
        ptr.ready = dy > 96;
        indicator.textContent = ptr.ready
          ? "Lepas untuk reload"
          : "Tarik untuk reload";
        indicator.style.opacity = String(Math.min(1, dy / 75));
        indicator.style.transform = `translate(-50%,${Math.min(12, ptr.dist - 42)}px)`;
        if (page) {
          page.style.transition = "";
          page.style.transform = `translateY(${ptr.dist}px)`;
        }
      },
      { passive: false },
    );
    const endPull = () => {
      if (!ptr.active) return;
      const shouldReload = ptr.ready;
      resetPull();
      if (shouldReload) {
        ptr.reloading = true;
        indicator.textContent = "Memuat ulang...";
        indicator.style.opacity = "1";
        indicator.style.transform = "translate(-50%,12px)";
        setTimeout(() => hardRefreshApp(), 180);
      }
    };
    document.addEventListener("touchend", endPull, { passive: true });
    document.addEventListener("touchcancel", resetPull, { passive: true });
  }

  // FIX: penjaga pergantian tanggal WIB.
  // Absen dan closing dihitung per dateKey, jadi UI wajib dirender ulang saat hari berganti.
  let APP_DATE_KEY = todayKey();
  let APP_DATE_CHECKING = false;
  async function checkDateChange() {
    if (APP_DATE_CHECKING) return false;
    const nowKey = todayKey();
    if (nowKey === APP_DATE_KEY) return false;
    APP_DATE_CHECKING = true;
    APP_DATE_KEY = nowKey;
    try {
      closeModal();
      state.lastSyncMs = 0;
      clearStaffRealtime();
      if (state.user) {
        toast("Tanggal berganti. Absen & closing diperbarui.");
        await loadStaffData({ silent: true });
      } else {
        render();
      }
    } catch (e) {
      console.warn("date change refresh failed", e);
      render();
    } finally {
      APP_DATE_CHECKING = false;
    }
    return true;
  }
  function setupAutoSync() {
    // Tidak ada lagi refresh besar tiap 60 detik.
    // Realtime kecil yang menjaga transaksi/absen/closing hari ini tetap update.
    setInterval(async () => {
      await checkDateChange();
    }, 60000);
    window.addEventListener("online", () => {
      if (state.user) {
        toast("Online lagi, sync pending dicek");
        flushPending();
        startStaffRealtime();
      }
    });
    window.addEventListener("focus", async () => {
      const changed = await checkDateChange();
      if (!changed && state.user) {
        startStaffRealtime();
        render();
      }
    });
    document.addEventListener("visibilitychange", async () => {
      if (!document.hidden) {
        const changed = await checkDateChange();
        if (!changed && state.user) {
          startStaffRealtime();
          render();
        }
      }
    });
  }

  try {
    window.addEventListener("online", () => {
      syncBelanjakuBridgeQueue()
        .then((r) => {
          if (r.sent) toast("Data Belanjaku terkirim");
        })
        .catch(() => {});
    });
    window.addEventListener("focus", () => {
      syncBelanjakuBridgeQueue().catch(() => {});
    });
  } catch (e) {}
  window.requestOpenPrayerAyat = requestOpenPrayerAyat;
  window.openPrayerAyat = openPrayerAyat;
  window.togglePrayerAyat = togglePrayerAyat;
  window.stopPrayerAyat = stopPrayerAyat;
  window.openStaffNoteLink = openStaffNoteLink;
  window.login = login;
  window.logout = logout;
  window.toggleTheme = toggleTheme;
  window.openHeaderGuideDetail = openHeaderGuideDetail;
  window.dismissManualBonusNotice = dismissManualBonusNotice;
  window.dismissTargetNotice = dismissTargetNotice;
  window.refresh = refresh;
  window.fullSync = fullSync;
  window.showSyncCenter = showSyncCenter;
  window.hardRefreshApp = hardRefreshApp;
  window.forceUpdateApp = forceUpdateApp;
  window.showForceUpdateConfirm = showForceUpdateConfirm;
  window.retrySync = retrySync;
  window.go = go;
  window.appBack = appBack;
  window.openTx = openTx;
  window.requestFeatureUnlock = requestFeatureUnlock;
  window.openEmptyStock = openEmptyStock;
  window.addEmptyStockVariantRow = addEmptyStockVariantRow;
  window.removeEmptyStockVariantRow = removeEmptyStockVariantRow;
  window.submitEmptyStock = submitEmptyStock;
  window.syncBelanjakuBridgeQueue = syncBelanjakuBridgeQueue;
  window.saveTx = saveTx;
  window.confirmTxPayment = confirmTxPayment;
  window.reopenTxDraft = reopenTxDraft;
  window.cancelTxPaymentChoice = cancelTxPaymentChoice;
  window.delTx = delTx;
  window.closeModal = closeModal;
  window.closeFirstTxParty = closeFirstTxParty;
  window.closeManualBonusParty = closeManualBonusParty;
  window.dismissBonusWithdrawalNotice = dismissBonusWithdrawalNotice;
  window.updateLocation = updateLocation;
  window.clockIn = clockIn;
  window.formatRupiahInput = formatRupiahInput;
  window.printReceiptFromTx = printReceiptFromTx;
  window.printTodayTransactions = printTodayTransactions;
  window.copyReceiptText = copyReceiptText;
  window.shareReceiptText = shareReceiptText;
  window.nativePrintReceiptText = nativePrintReceiptText;
  window.directPrintReceiptText = directPrintReceiptText;
  window.browserPrintReceiptText = browserPrintReceiptText;
  window.addTxProductItem = addTxProductItem;
  window.pickTxProductSuggest = pickTxProductSuggest;
  window.deleteTxProductSuggest = deleteTxProductSuggest;
  window.showTxProductSuggest = showTxProductSuggest;
  window.hideTxProductSuggest = hideTxProductSuggest;
  window.removeTxProductItem = removeTxProductItem;
  window.handleTxProductKey = handleTxProductKey;
  window.updateTxProductAddButton = updateTxProductAddButton;
  window.openTxDetail = openTxDetail;
  statusPill = function () {
    if (isTrialUser()) return `<span class="pill amber">Mode Trial</span>`;
    if (isClosedToday()) return `<span class="pill amber">Sudah closing</span>`;
    if (isRismaSpecialUser())
      return `<span class="pill green">Risma bebas absen</span>`;
    if (isDaily()) return `<span class="pill blue">Karyawan harian</span>`;
    const a = todayAtt();
    return a
      ? `<span class="pill green">Sudah absen · ${timeID(ms(a))}</span>`
      : `<span class="pill red">Belum absen</span>`;
  };
  setupAutoSync();
  // Pull-to-refresh dimatikan supaya tidak ada read tambahan tanpa sengaja.
  // Refresh manual dan realtime tetap aktif.
  // installPullToReload();

  // === LONG-PRESS DELEGATION: sync header button ===
  // Tap = fullSync(), Long-press (550ms) = showSyncCenter()
  {
    let _syncLP = null;
    let _syncFired = false;
    const LP_MS = 550;
    const isSyncBtn = (el) => el && el.closest && el.closest(".sync-header-btn");
    document.addEventListener("pointerdown", (e) => {
      const btn = isSyncBtn(e.target);
      if (!btn) return;
      _syncFired = false;
      btn.classList.add("longpressing");
      _syncLP = setTimeout(() => {
        _syncFired = true;
        btn.classList.remove("longpressing");
        showSyncCenter();
      }, LP_MS);
    });
    const cancelLP = (e) => {
      if (_syncLP) { clearTimeout(_syncLP); _syncLP = null; }
      const btn = document.querySelector(".sync-header-btn.longpressing");
      if (btn) btn.classList.remove("longpressing");
    };
    document.addEventListener("pointerup", (e) => {
      cancelLP();
      if (!_syncFired && isSyncBtn(e.target)) {
        e.preventDefault();
        fullSync();
      }
    });
    document.addEventListener("pointerleave", cancelLP, true);
    document.addEventListener("pointercancel", cancelLP);
    // Prevent default click so tap doesn't fire twice
    document.addEventListener("click", (e) => {
      if (isSyncBtn(e.target)) e.preventDefault();
    });
  }

  boot();
